(function () {
     var k;

     function aa(a) {
          var b = 0;
          return function () {
               return b < a.length ? {
                    done: !1,
                    value: a[b++]
               } : {
                    done: !0
               }
          }
     }

     function ba(a) {
          var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
          return b ? b.call(a) : {
               next: aa(a)
          }
     }

     function ca(a) {
          if (!(a instanceof Array)) {
               a = ba(a);
               for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
               a = c
          }
          return a
     }
     var da = "function" == typeof Object.create ? Object.create : function (a) {
               function b() {}
               b.prototype = a;
               return new b
          },
          ea;
     if ("function" == typeof Object.setPrototypeOf) ea = Object.setPrototypeOf;
     else {
          var fa;
          a: {
               var ha = {
                         Ja: !0
                    },
                    ia = {};
               try {
                    ia.__proto__ = ha;
                    fa = ia.Ja;
                    break a
               } catch (a) {}
               fa = !1
          }
          ea = fa ? function (a, b) {
               a.__proto__ = b;
               if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
               return a
          } : null
     }
     var ja = ea;

     function ka(a, b) {
          a.prototype = da(b.prototype);
          a.prototype.constructor = a;
          if (ja) ja(a, b);
          else
               for (var c in b)
                    if ("prototype" != c)
                         if (Object.defineProperties) {
                              var d = Object.getOwnPropertyDescriptor(b, c);
                              d && Object.defineProperty(a, c, d)
                         } else a[c] = b[c]
     }
     var la = "function" == typeof Object.defineProperties ? Object.defineProperty : function (a, b, c) {
               a != Array.prototype && a != Object.prototype && (a[b] = c.value)
          },
          ma = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this;

     function na(a, b) {
          if (b) {
               var c = ma;
               a = a.split(".");
               for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    e in c || (c[e] = {});
                    c = c[e]
               }
               a = a[a.length - 1];
               d = c[a];
               b = b(d);
               b != d && null != b && la(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
               })
          }
     }
     na("String.prototype.endsWith", function (a) {
          return a ? a : function (b, c) {
               if (null == this) throw new TypeError("The 'this' value for String.prototype.endsWith must not be null or undefined");
               if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.endsWith must not be a regular expression");
               void 0 === c && (c = this.length);
               c = Math.max(0, Math.min(c | 0, this.length));
               for (var d = b.length; 0 < d && 0 < c;)
                    if (this[--c] != b[--d]) return !1;
               return 0 >= d
          }
     });
     na("Array.prototype.find", function (a) {
          return a ? a : function (b, c) {
               a: {
                    var d = this;d instanceof String && (d = String(d));
                    for (var e = d.length, f = 0; f < e; f++) {
                         var g = d[f];
                         if (b.call(c, g, f, d)) {
                              b = g;
                              break a
                         }
                    }
                    b = void 0
               }
               return b
          }
     });
     var pa = "function" == typeof Object.assign ? Object.assign : function (a, b) {
          for (var c = 1; c < arguments.length; c++) {
               var d = arguments[c];
               if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
          }
          return a
     };
     na("Object.assign", function (a) {
          return a || pa
     });
     var n = this || self;

     function qa() {
          if (null === ra) a: {
               var a = n.document;
               if ((a = a.querySelector && a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && sa.test(a)) {
                    ra = a;
                    break a
               }
               ra = ""
          }
          return ra
     }
     var sa = /^[\w+/_-]+[=]{0,2}$/,
          ra = null;

     function ta(a) {
          a = a.split(".");
          for (var b = n, c = 0; c < a.length; c++)
               if (b = b[a[c]], null == b) return null;
          return b
     }

     function ua() {}

     function va(a) {
          a.ja = void 0;
          a.j = function () {
               return a.ja ? a.ja : a.ja = new a
          }
     }

     function wa(a) {
          var b = typeof a;
          if ("object" == b)
               if (a) {
                    if (a instanceof Array) return "array";
                    if (a instanceof Object) return b;
                    var c = Object.prototype.toString.call(a);
                    if ("[object Window]" == c) return "object";
                    if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
                    if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
               } else return "null";
          else if ("function" == b && "undefined" == typeof a.call) return "object";
          return b
     }

     function xa(a) {
          return null === a
     }

     function ya(a) {
          return "array" == wa(a)
     }

     function za(a) {
          var b = typeof a;
          return "object" == b && null != a || "function" == b
     }

     function Aa(a) {
          return a[Ba] || (a[Ba] = ++Ca)
     }
     var Ba = "closure_uid_" + (1E9 * Math.random() >>> 0),
          Ca = 0;

     function Da(a, b, c) {
          return a.call.apply(a.bind, arguments)
     }

     function Ea(a, b, c) {
          if (!a) throw Error();
          if (2 < arguments.length) {
               var d = Array.prototype.slice.call(arguments, 2);
               return function () {
                    var e = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(e, d);
                    return a.apply(b, e)
               }
          }
          return function () {
               return a.apply(b, arguments)
          }
     }

     function Fa(a, b, c) {
          Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? Fa = Da : Fa = Ea;
          return Fa.apply(null, arguments)
     }

     function Ga(a, b) {
          var c = Array.prototype.slice.call(arguments, 1);
          return function () {
               var d = c.slice();
               d.push.apply(d, arguments);
               return a.apply(this, d)
          }
     }

     function q(a, b) {
          function c() {}
          c.prototype = b.prototype;
          a.prototype = new c;
          a.prototype.constructor = a
     };
     var Ha = (new Date).getTime();

     function Ia(a, b) {
          for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
     }

     function Ja(a, b) {
          for (var c = a.length, d = [], e = 0, f = "string" === typeof a ? a.split("") : a, g = 0; g < c; g++)
               if (g in f) {
                    var h = f[g];
                    b.call(void 0, h, g, a) && (d[e++] = h)
               } return d
     }

     function Ka(a, b) {
          for (var c = a.length, d = Array(c), e = "string" === typeof a ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
          return d
     }

     function La(a, b) {
          for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
               if (e in d && b.call(void 0, d[e], e, a)) return !0;
          return !1
     }

     function Ma(a, b) {
          a: {
               for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                    if (e in d && b.call(void 0, d[e], e, a)) {
                         b = e;
                         break a
                    } b = -1
          }
          return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
     }

     function Na(a, b) {
          a: {
               for (var c = "string" === typeof a ? a.split("") : a, d = a.length - 1; 0 <= d; d--)
                    if (d in c && b.call(void 0, c[d], d, a)) {
                         b = d;
                         break a
                    } b = -1
          }
          return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
     }

     function Oa(a, b) {
          a: if ("string" === typeof a) a = "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
               else {
                    for (var c = 0; c < a.length; c++)
                         if (c in a && a[c] === b) {
                              a = c;
                              break a
                         } a = -1
               }return 0 <= a
     };

     function Pa() {
          return function () {
               return !xa.apply(this, arguments)
          }
     }

     function Qa(a) {
          var b = !1,
               c;
          return function () {
               b || (c = a(), b = !0);
               return c
          }
     }

     function Ra(a) {
          var b = a;
          return function () {
               if (b) {
                    var c = b;
                    b = null;
                    c()
               }
          }
     };

     function Sa(a, b) {
          var c = {},
               d;
          for (d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
          return c
     }

     function Ta(a, b) {
          for (var c in a)
               if (b.call(void 0, a[c], c, a)) return !0;
          return !1
     }

     function Ua(a, b) {
          return null !== a && b in a
     }

     function Va(a, b) {
          for (var c in a)
               if (b.call(void 0, a[c], c, a)) return c
     };

     function Wa(a, b) {
          this.c = a === Xa && b || "";
          this.g = Ya
     }
     Wa.prototype.b = !0;
     Wa.prototype.a = function () {
          return this.c.toString()
     };

     function Za(a) {
          if (a instanceof Wa && a.constructor === Wa && a.g === Ya) return a.c;
          wa(a);
          return "type_error:TrustedResourceUrl"
     }
     var Ya = {},
          Xa = {};

     function $a(a) {
          return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
     }
     var ab = /&/g,
          bb = /</g,
          cb = />/g,
          db = /"/g,
          eb = /'/g,
          fb = /\x00/g;

     function gb(a, b) {
          return -1 != a.indexOf(b)
     }

     function hb(a, b) {
          var c = 0;
          a = $a(String(a)).split(".");
          b = $a(String(b)).split(".");
          for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
               var f = a[e] || "",
                    g = b[e] || "";
               do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (0 == f[0].length && 0 == g[0].length) break;
                    c = ib(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || ib(0 == f[2].length, 0 == g[2].length) || ib(f[2], g[2]);
                    f = f[3];
                    g = g[3]
               } while (0 == c)
          }
          return c
     }

     function ib(a, b) {
          return a < b ? -1 : a > b ? 1 : 0
     };

     function jb(a, b) {
          this.c = a === kb && b || "";
          this.g = lb
     }
     jb.prototype.b = !0;
     jb.prototype.a = function () {
          return this.c.toString()
     };

     function mb(a) {
          if (a instanceof jb && a.constructor === jb && a.g === lb) return a.c;
          wa(a);
          return "type_error:SafeUrl"
     }
     var nb = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
          lb = {},
          kb = {};
     var ob;
     a: {
          var pb = n.navigator;
          if (pb) {
               var qb = pb.userAgent;
               if (qb) {
                    ob = qb;
                    break a
               }
          }
          ob = ""
     }

     function r(a) {
          return gb(ob, a)
     }

     function rb(a) {
          for (var b = /(\w[\w ]+)\/([^\s]+)\s*(?:\((.*?)\))?/g, c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
          return c
     };

     function sb() {
          return (r("Chrome") || r("CriOS")) && !r("Edge")
     }

     function tb() {
          function a(e) {
               e = Ma(e, d);
               return c[e] || ""
          }
          var b = ob;
          if (r("Trident") || r("MSIE")) return ub(b);
          b = rb(b);
          var c = {};
          Ia(b, function (e) {
               c[e[0]] = e[1]
          });
          var d = Ga(Ua, c);
          return r("Opera") ? a(["Version", "Opera"]) : r("Edge") ? a(["Edge"]) : r("Edg/") ? a(["Edg"]) : sb() ? a(["Chrome", "CriOS"]) : (b = b[2]) && b[1] || ""
     }

     function ub(a) {
          var b = /rv: *([\d\.]*)/.exec(a);
          if (b && b[1]) return b[1];
          b = "";
          var c = /MSIE +([\d\.]+)/.exec(a);
          if (c && c[1])
               if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
                    if (a && a[1]) switch (a[1]) {
                         case "4.0":
                              b = "8.0";
                              break;
                         case "5.0":
                              b = "9.0";
                              break;
                         case "6.0":
                              b = "10.0";
                              break;
                         case "7.0":
                              b = "11.0"
                    } else b = "7.0";
                    else b = c[1];
          return b
     };

     function vb(a, b) {
          a.src = Za(b);
          (b = qa()) && a.setAttribute("nonce", b)
     };
     var wb = {
               "\x00": "\\0",
               "\b": "\\b",
               "\f": "\\f",
               "\n": "\\n",
               "\r": "\\r",
               "\t": "\\t",
               "\x0B": "\\x0B",
               '"': '\\"',
               "\\": "\\\\",
               "<": "\\u003C"
          },
          xb = {
               "'": "\\'"
          };

     function yb(a) {
          return String(a).replace(/\-([a-z])/g, function (b, c) {
               return c.toUpperCase()
          })
     };

     function zb(a) {
          zb[" "](a);
          return a
     }
     zb[" "] = ua;

     function w() {}
     var Ab = "function" == typeof Uint8Array;

     function x(a, b, c, d) {
          a.a = null;
          b || (b = []);
          a.F = void 0;
          a.g = -1;
          a.b = b;
          a: {
               if (b = a.b.length) {
                    --b;
                    var e = a.b[b];
                    if (!(null === e || "object" != typeof e || ya(e) || Ab && e instanceof Uint8Array)) {
                         a.i = b - a.g;
                         a.c = e;
                         break a
                    }
               }
               a.i = Number.MAX_VALUE
          }
          a.s = {};
          if (c)
               for (b = 0; b < c.length; b++) e = c[b], e < a.i ? (e += a.g, a.b[e] = a.b[e] || Bb) : (Cb(a), a.c[e] = a.c[e] || Bb);
          if (d && d.length)
               for (b = 0; b < d.length; b++) Db(a, d[b])
     }
     var Bb = [];

     function Cb(a) {
          var b = a.i + a.g;
          a.b[b] || (a.c = a.b[b] = {})
     }

     function y(a, b) {
          if (b < a.i) {
               b += a.g;
               var c = a.b[b];
               return c === Bb ? a.b[b] = [] : c
          }
          if (a.c) return c = a.c[b], c === Bb ? a.c[b] = [] : c
     }

     function Eb(a, b) {
          a = y(a, b);
          return null == a ? a : +a
     }

     function Fb(a, b) {
          a = y(a, b);
          return null == a ? a : !!a
     }

     function z(a, b, c) {
          a = y(a, b);
          return null == a ? c : a
     }

     function Gb(a, b) {
          a = Fb(a, b);
          return null == a ? !1 : a
     }

     function Hb(a, b) {
          a = Eb(a, b);
          return null == a ? 0 : a
     }

     function Ib(a, b, c) {
          b < a.i ? a.b[b + a.g] = c : (Cb(a), a.c[b] = c);
          return a
     }

     function Db(a, b) {
          for (var c, d, e = 0; e < b.length; e++) {
               var f = b[e],
                    g = y(a, f);
               null != g && (c = f, d = g, Ib(a, f, void 0))
          }
          return c ? (Ib(a, c, d), c) : 0
     }

     function A(a, b, c) {
          a.a || (a.a = {});
          if (!a.a[c]) {
               var d = y(a, c);
               d && (a.a[c] = new b(d))
          }
          return a.a[c]
     }

     function B(a, b, c) {
          a.a || (a.a = {});
          if (!a.a[c]) {
               for (var d = y(a, c), e = [], f = 0; f < d.length; f++) e[f] = new b(d[f]);
               a.a[c] = e
          }
          b = a.a[c];
          b == Bb && (b = a.a[c] = []);
          return b
     }

     function Jb(a) {
          if (a.a)
               for (var b in a.a) {
                    var c = a.a[b];
                    if (ya(c))
                         for (var d = 0; d < c.length; d++) c[d] && Jb(c[d]);
                    else c && Jb(c)
               }
          return a.b
     };

     function Kb(a) {
          x(this, a, Lb, null)
     }
     q(Kb, w);

     function Mb(a) {
          x(this, a, null, null)
     }
     q(Mb, w);
     var Lb = [2, 3];

     function Nb(a) {
          x(this, a, null, null)
     }
     q(Nb, w);

     function Ob(a) {
          var b = new Nb;
          return Ib(b, 1, a)
     }

     function Pb(a, b) {
          return Ib(a, 2, b)
     }

     function Qb(a, b) {
          return Ib(a, 3, b)
     }

     function Rb(a, b) {
          return Ib(a, 4, b)
     };
     var Sb = document,
          C = window;
     var Tb = {
          "120x90": !0,
          "160x90": !0,
          "180x90": !0,
          "200x90": !0,
          "468x15": !0,
          "728x15": !0
     };

     function Ub(a, b) {
          if (15 == b) {
               if (728 <= a) return 728;
               if (468 <= a) return 468
          } else if (90 == b) {
               if (200 <= a) return 200;
               if (180 <= a) return 180;
               if (160 <= a) return 160;
               if (120 <= a) return 120
          }
          return null
     };

     function Vb() {
          this.a = C.document || {
               cookie: ""
          }
     }
     Vb.prototype.set = function (a, b, c, d, e, f) {
          if ("object" === typeof c) {
               var g = c.c;
               f = c.g;
               e = c.domain;
               d = c.a;
               c = c.b
          }
          if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
          if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
          void 0 === c && (c = -1);
          this.a.cookie = a + "=" + b + (e ? ";domain=" + e : "") + (d ? ";path=" + d : "") + (0 > c ? "" : 0 == c ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(+new Date + 1E3 * c)).toUTCString()) + (f ? ";secure" : "") + (null != g ? ";samesite=" + g : "")
     };
     Vb.prototype.get = function (a, b) {
          for (var c = a + "=", d = (this.a.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
               f = $a(d[e]);
               if (0 == f.lastIndexOf(c, 0)) return f.substr(c.length);
               if (f == a) return ""
          }
          return b
     };

     function Wb(a, b) {
          b = String(b);
          "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
          return a.createElement(b)
     }

     function Xb(a) {
          this.a = a || n.document || document
     }
     Xb.prototype.contains = function (a, b) {
          if (!a || !b) return !1;
          if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
          if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
          for (; b && a != b;) b = b.parentNode;
          return b == a
     };

     function Yb(a) {
          Zb();
          return new Wa(Xa, a)
     }
     var Zb = ua;

     function $b() {
          return !(r("iPad") || r("Android") && !r("Mobile") || r("Silk")) && (r("iPod") || r("iPhone") || r("Android") || r("IEMobile"))
     };

     function ac(a) {
          try {
               var b;
               if (b = !!a && null != a.location.href) a: {
                    try {
                         zb(a.foo);
                         b = !0;
                         break a
                    } catch (c) {}
                    b = !1
               }
               return b
          } catch (c) {
               return !1
          }
     }

     function bc(a) {
          for (var b = n, c = 0; b && 40 > c++ && (!ac(b) || !a(b));) a: {
               try {
                    var d = b.parent;
                    if (d && d != b) {
                         b = d;
                         break a
                    }
               } catch (e) {}
               b = null
          }
     }

     function cc() {
          var a = n;
          bc(function (b) {
               a = b;
               return !1
          });
          return a
     }

     function dc(a, b) {
          var c = a.createElement("script");
          vb(c, Yb(b));
          return (a = a.getElementsByTagName("script")[0]) && a.parentNode ? (a.parentNode.insertBefore(c, a), c) : null
     }

     function ec(a, b) {
          return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle
     }

     function fc(a, b, c) {
          var d = !1;
          void 0 === c || c || (d = gc());
          return !d && !hc() && (c = Math.random(), c < b) ? (c = ic(n), a[Math.floor(c * a.length)]) : null
     }

     function ic(a) {
          if (!a.crypto) return Math.random();
          try {
               var b = new Uint32Array(1);
               a.crypto.getRandomValues(b);
               return b[0] / 65536 / 65536
          } catch (c) {
               return Math.random()
          }
     }

     function jc(a, b) {
          if (a)
               for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b.call(void 0, a[c], c, a)
     }

     function kc(a) {
          return Va(a, function (b, c) {
               return Object.prototype.hasOwnProperty.call(a, c) && !0
          })
     }

     function lc(a) {
          var b = a.length;
          if (0 == b) return 0;
          for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
          return 0 < c ? c : 4294967296 + c
     }
     var hc = Qa(function () {
          return gb(ob, "Google Web Preview") || 1E-4 > Math.random()
     });

     function mc(a, b) {
          var c = -1;
          try {
               a.localStorage && (c = parseInt(a.localStorage.getItem(b), 10))
          } catch (d) {
               return null
          }
          return 0 <= c && 1E3 > c ? c : null
     }

     function nc(a, b) {
          if (hc()) return null;
          var c = Math.floor(1E3 * ic(a));
          try {
               if (a.localStorage) return a.localStorage.setItem(b, String(c)), c
          } catch (d) {}
          return null
     }
     var gc = Qa(function () {
               return gb(ob, "MSIE")
          }),
          oc = /^([0-9.]+)px$/,
          pc = /^(-?[0-9.]{1,30})$/;

     function qc(a) {
          return pc.test(a) && (a = Number(a), !isNaN(a)) ? a : null
     }

     function rc(a, b) {
          return b ? !/^false$/.test(a) : /^true$/.test(a)
     }

     function D(a) {
          return (a = oc.exec(a)) ? +a[1] : null
     }

     function sc(a) {
          var b = {
               display: "none"
          };
          a.style.setProperty ? jc(b, function (c, d) {
               a.style.setProperty(d, c, "important")
          }) : a.style.cssText = tc(uc(vc(a.style.cssText), wc(b, function (c) {
               return c + " !important"
          })))
     }
     var uc = Object.assign || function (a, b) {
          for (var c = 1; c < arguments.length; c++) {
               var d = arguments[c];
               if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
          }
          return a
     };

     function wc(a, b) {
          var c = {},
               d;
          for (d in a) Object.prototype.hasOwnProperty.call(a, d) && (c[d] = b.call(void 0, a[d], d, a));
          return c
     }

     function tc(a) {
          var b = [];
          jc(a, function (c, d) {
               null != c && "" !== c && b.push(d + ":" + c)
          });
          return b.length ? b.join(";") + ";" : ""
     }

     function vc(a) {
          var b = {};
          if (a) {
               var c = /\s*:\s*/;
               Ia((a || "").split(/\s*;\s*/), function (d) {
                    if (d) {
                         var e = d.split(c);
                         d = e[0];
                         e = e[1];
                         d && e && (b[d.toLowerCase()] = e)
                    }
               })
          }
          return b
     }
     var xc = Qa(function () {
          var a = /Edge\/([^. ]+)/.exec(navigator.userAgent);
          return a ? 18 <= parseInt(a[1], 10) : (a = /Chrome\/([^. ]+)/.exec(navigator.userAgent)) ? 71 <= parseInt(a[1], 10) : (a = /AppleWebKit\/([^. ]+)/.exec(navigator.userAgent)) ? 605 <= parseInt(a[1], 10) : (a = /Firefox\/([^. ]+)/.exec(navigator.userAgent)) ? 64 <= parseInt(a[1], 10) : !1
     });

     function yc(a, b, c) {
          a.addEventListener && a.addEventListener(b, c, !1)
     };

     function zc(a, b) {
          n.google_image_requests || (n.google_image_requests = []);
          var c = n.document.createElement("img");
          if (b) {
               var d = function (e) {
                    b && b(e);
                    c.removeEventListener && c.removeEventListener("load", d, !1);
                    c.removeEventListener && c.removeEventListener("error", d, !1)
               };
               yc(c, "load", d);
               yc(c, "error", d)
          }
          c.src = a;
          n.google_image_requests.push(c)
     };

     function Ac(a, b) {
          a = parseInt(a, 10);
          return isNaN(a) ? b : a
     }
     var Bc = /^([\w-]+\.)*([\w-]{2,})(:[0-9]+)?$/;

     function Cc(a, b) {
          return a ? (a = a.match(Bc)) ? a[0] : b : b
     };

     function Dc() {
          return "r20191015"
     }
     var Ec = rc("false", !1),
          Fc = rc("true", !1),
          Gc = rc("false", !1),
          Hc = rc("true", !1) || !Fc;

     function Ic() {
          return Cc("", "pagead2.googlesyndication.com")
     };

     function Jc(a) {
          x(this, a, Kc, Lc)
     }
     q(Jc, w);
     var Kc = [2, 8],
          Lc = [
               [3, 4, 5],
               [6, 7]
          ];

     function Mc(a) {
          return null != a ? !a : a
     }

     function Nc(a, b) {
          for (var c = !1, d = 0; d < a.length; d++) {
               var e = a[d].call();
               if (e == b) return e;
               null == e && (c = !0)
          }
          if (!c) return !b
     }

     function Oc(a, b) {
          var c = B(a, Jc, 2);
          if (!c.length) return Pc(a, b);
          a = z(a, 1, 0);
          if (1 == a) return Mc(Oc(c[0], b));
          c = Ka(c, function (d) {
               return function () {
                    return Oc(d, b)
               }
          });
          switch (a) {
               case 2:
                    return Nc(c, !1);
               case 3:
                    return Nc(c, !0)
          }
     }

     function Pc(a, b) {
          var c = Db(a, Lc[0]);
          a: {
               switch (c) {
                    case 3:
                         var d = z(a, 3, 0);
                         break a;
                    case 4:
                         d = z(a, 4, 0);
                         break a;
                    case 5:
                         d = z(a, 5, 0);
                         break a
               }
               d = void 0
          }
          if (d && (b = (b = b[c]) && b[d])) {
               try {
                    var e = b.apply(null, y(a, 8))
               } catch (f) {
                    return
               }
               b = z(a, 1, 0);
               if (4 == b) return !!e;
               d = null != e;
               if (5 == b) return d;
               if (12 == b) a = z(a, 7, "");
               else a: {
                    switch (c) {
                         case 4:
                              a = Hb(a, 6);
                              break a;
                         case 5:
                              a = z(a, 7, "");
                              break a
                    }
                    a = void 0
               }
               if (null != a) {
                    if (6 == b) return e === a;
                    if (9 == b) return 0 == hb(e, a);
                    if (d) switch (b) {
                         case 7:
                              return e < a;
                         case 8:
                              return e > a;
                         case 12:
                              return (new RegExp(a)).test(e);
                         case 10:
                              return -1 == hb(e, a);
                         case 11:
                              return 1 == hb(e, a)
                    }
               }
          }
     }

     function Qc(a, b) {
          return !a || !(!b || !Oc(a, b))
     };

     function Rc(a) {
          x(this, a, Sc, null)
     }
     q(Rc, w);
     var Sc = [4];

     function Tc(a) {
          x(this, a, Uc, Vc)
     }
     q(Tc, w);

     function Wc(a) {
          x(this, a, null, null)
     }
     q(Wc, w);
     var Uc = [5],
          Vc = [
               [1, 2, 3, 6]
          ];

     function Xc() {
          var a = {};
          this.a = (a[3] = {}, a[4] = {}, a[5] = {}, a)
     }
     va(Xc);
     var Yc = rc("false", !1);

     function Zc(a, b) {
          switch (b) {
               case 1:
                    return z(a, 1, 0);
               case 2:
                    return z(a, 2, 0);
               case 3:
                    return z(a, 3, 0);
               case 6:
                    return z(a, 6, 0);
               default:
                    return null
          }
     }

     function $c(a, b) {
          if (!a) return null;
          switch (b) {
               case 1:
                    return Gb(a, 1);
               case 2:
                    return Hb(a, 2);
               case 3:
                    return z(a, 3, "");
               case 6:
                    return y(a, 4);
               default:
                    return null
          }
     }
     var ad = Qa(function () {
          if (!Yc) return {};
          try {
               var a = window.sessionStorage && window.sessionStorage.getItem("GGDFSSK");
               if (a) return JSON.parse(a)
          } catch (b) {}
          return {}
     });

     function bd(a, b, c) {
          var d = ad();
          if (d[a] && null != d[a][b]) return d[a][b];
          b = cd.j().a[a][b];
          if (!b) return c;
          b = new Tc(b);
          b = dd(b);
          a = $c(b, a);
          return null != a ? a : c
     }

     function dd(a) {
          var b = Xc.j().a;
          if (b) {
               var c = Na(B(a, Wc, 5), function (d) {
                    return Qc(A(d, Jc, 1), b)
               });
               if (c) return A(c, Rc, 2)
          }
          return A(a, Rc, 4)
     }

     function cd() {
          var a = {};
          this.a = (a[1] = {}, a[2] = {}, a[3] = {}, a[6] = {}, a)
     }
     va(cd);

     function ed(a, b) {
          return !!bd(1, a, void 0 === b ? !1 : b)
     }

     function fd(a, b) {
          b = void 0 === b ? 0 : b;
          a = Number(bd(2, a, b));
          return isNaN(a) ? b : a
     }

     function gd(a, b) {
          return bd(3, a, void 0 === b ? "" : b)
     }

     function hd(a, b) {
          b = void 0 === b ? [] : b;
          return bd(6, a, b)
     }

     function id(a) {
          var b = cd.j().a;
          Ia(a, function (c) {
               var d = Db(c, Vc[0]),
                    e = Zc(c, d);
               e && (b[d][e] = Jb(c))
          })
     }

     function jd(a) {
          var b = cd.j().a;
          Ia(a, function (c) {
               var d = new Tc(c),
                    e = Db(d, Vc[0]);
               (d = Zc(d, e)) && (b[e][d] || (b[e][d] = c))
          })
     };

     function E(a) {
          this.a = a
     }
     var kd = new E(1),
          ld = new E(2),
          md = new E(3),
          nd = new E(4),
          od = new E(5),
          pd = new E(6),
          qd = new E(7),
          rd = new E(8),
          sd = new E(9),
          td = new E(10),
          ud = new E(11),
          vd = new E(12),
          wd = new E(13),
          xd = new E(14);

     function F(a, b, c) {
          c.hasOwnProperty(a.a) || Object.defineProperty(c, String(a.a), {
               value: b
          })
     }

     function yd(a, b, c) {
          return b[a.a] || c || function () {}
     }

     function zd(a) {
          F(od, ed, a);
          F(pd, fd, a);
          F(qd, gd, a);
          F(rd, hd, a);
          F(wd, jd, a)
     }

     function Ad(a) {
          F(nd, function (b) {
               Xc.j().a = b
          }, a);
          F(sd, function (b, c) {
               var d = Xc.j();
               d.a[3][b] || (d.a[3][b] = c)
          }, a);
          F(td, function (b, c) {
               var d = Xc.j();
               d.a[4][b] || (d.a[4][b] = c)
          }, a);
          F(ud, function (b, c) {
               var d = Xc.j();
               d.a[5][b] || (d.a[5][b] = c)
          }, a);
          F(xd, function (b) {
               for (var c = Xc.j(), d = ba([3, 4, 5]), e = d.next(); !e.done; e = d.next()) {
                    var f = e.value;
                    e = void 0;
                    var g = c.a[f];
                    f = b[f];
                    for (e in f) g[e] = f[e]
               }
          }, a)
     }

     function Bd(a) {
          a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
               value: !0
          })
     };

     function Cd() {
          this.a = function () {
               return !1
          }
     }
     va(Cd);

     function H(a) {
          var b = void 0 === b ? !1 : b;
          return Cd.j().a(a, b)
     };

     function Dd(a) {
          a = void 0 === a ? n : a;
          var b = a.context || a.AMP_CONTEXT_DATA;
          if (!b) try {
               b = a.parent.context || a.parent.AMP_CONTEXT_DATA
          } catch (c) {}
          try {
               if (b && b.pageViewId && b.canonicalUrl) return b
          } catch (c) {}
          return null
     }

     function Ed(a) {
          return (a = a || Dd()) ? ac(a.master) ? a.master : null : null
     };

     function Fd(a, b) {
          for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b.call(void 0, a[c], c, a)
     }

     function Gd(a) {
          return !(!a || !a.call) && "function" === typeof a
     }

     function Hd(a) {
          a = Ed(Dd(a)) || a;
          a.google_unique_id ? ++a.google_unique_id : a.google_unique_id = 1
     }

     function Id(a) {
          a = Ed(Dd(a)) || a;
          a = a.google_unique_id;
          return "number" === typeof a ? a : 0
     }
     var Jd = !!window.google_async_iframe_id,
          Kd = Jd && window.parent || window;

     function Ld() {
          if (Jd && !ac(Kd)) {
               var a = "." + Sb.domain;
               try {
                    for (; 2 < a.split(".").length && !ac(Kd);) Sb.domain = a = a.substr(a.indexOf(".") + 1), Kd = window.parent
               } catch (b) {}
               ac(Kd) || (Kd = window)
          }
          return Kd
     }
     var Md = /(^| )adsbygoogle($| )/;

     function Nd(a) {
          return Ec && a.google_top_window || a.top
     }

     function Od(a) {
          a = Nd(a);
          return ac(a) ? a : null
     };

     function I(a) {
          a.google_ad_modifications || (a.google_ad_modifications = {});
          return a.google_ad_modifications
     }

     function J(a, b) {
          a: if (a = I(a).eids || [], a.indexOf) b = a.indexOf(b), b = 0 < b || 0 === b;
               else {
                    for (var c = 0; c < a.length; c++)
                         if (a[c] === b) {
                              b = !0;
                              break a
                         } b = !1
               }return b
     }

     function Pd(a, b) {
          a = I(a);
          a.tag_partners = a.tag_partners || [];
          a.tag_partners.push(b)
     }

     function Qd(a) {
          I(C).allow_second_reactive_tag = a
     }

     function Rd(a, b, c) {
          for (var d = 0; d < a.length; ++d)
               if ((a[d].ad_slot || b) == b && (a[d].ad_tag_origin || c) == c) return a[d];
          return null
     };
     var Sd = {},
          Td = (Sd.google_ad_client = !0, Sd.google_ad_host = !0, Sd.google_ad_host_channel = !0, Sd.google_adtest = !0, Sd.google_tag_for_child_directed_treatment = !0, Sd.google_tag_for_under_age_of_consent = !0, Sd.google_tag_partner = !0, Sd);

     function K(a) {
          x(this, a, Ud, null)
     }
     q(K, w);
     var Ud = [4];
     K.prototype.Y = function () {
          return y(this, 3)
     };

     function L(a) {
          x(this, a, null, null)
     }
     q(L, w);

     function Vd(a) {
          x(this, a, null, Wd)
     }
     q(Vd, w);

     function Xd(a) {
          x(this, a, null, null)
     }
     q(Xd, w);

     function Yd(a) {
          x(this, a, null, null)
     }
     q(Yd, w);

     function Zd(a) {
          x(this, a, null, null)
     }
     q(Zd, w);
     var Wd = [
          [1, 2, 3]
     ];

     function $d(a) {
          x(this, a, null, null)
     }
     q($d, w);

     function ae(a) {
          x(this, a, null, null)
     }
     q(ae, w);

     function be(a) {
          x(this, a, ce, null)
     }
     q(be, w);
     var ce = [6, 7, 9, 10, 11];

     function de(a) {
          x(this, a, ee, null)
     }
     q(de, w);

     function fe(a) {
          x(this, a, null, null)
     }
     q(fe, w);

     function ge(a) {
          x(this, a, he, null)
     }
     q(ge, w);

     function ie(a) {
          x(this, a, null, null)
     }
     q(ie, w);

     function je(a) {
          x(this, a, null, null)
     }
     q(je, w);

     function ke(a) {
          x(this, a, null, null)
     }
     q(ke, w);

     function le(a) {
          x(this, a, null, null)
     }
     q(le, w);
     var ee = [1, 2, 5, 7],
          he = [2, 5, 6];
     var me = {
          overlays: 1,
          interstitials: 2,
          vignettes: 2,
          inserts: 3,
          immersives: 4,
          list_view: 5
     };

     function ne(a, b) {
          a = a.replace(/(^\/)|(\/$)/g, "");
          var c = lc(a),
               d = oe(a);
          return b.find(function (e) {
               var f = null != y(e, 7) ? y(A(e, ie, 7), 1) : y(e, 1);
               e = null != y(e, 7) ? y(A(e, ie, 7), 2) : 2;
               if ("number" !== typeof f) return !1;
               switch (e) {
                    case 1:
                         return f == c;
                    case 2:
                         return d[f] || !1
               }
               return !1
          }) || null
     }

     function oe(a) {
          for (var b = {};;) {
               b[lc(a)] = !0;
               if (!a) return b;
               a = a.substring(0, a.lastIndexOf("/"))
          }
     };

     function pe(a, b) {
          var c = void 0 === c ? {} : c;
          this.error = a;
          this.context = b.context;
          this.msg = b.message || "";
          this.id = b.id || "jserror";
          this.meta = c
     }

     function qe(a) {
          return !!(a.error && a.meta && a.id)
     };
     var re = /^https?:\/\/(\w|-)+\.cdn\.ampproject\.(net|org)(\?|\/|$)/;

     function se(a, b) {
          this.a = a;
          this.b = b
     }

     function te(a, b, c) {
          this.url = a;
          this.a = b;
          this.ua = !!c;
          this.depth = null
     };

     function ue() {
          this.c = "&";
          this.g = !1;
          this.b = {};
          this.i = 0;
          this.a = []
     }

     function ve(a, b) {
          var c = {};
          c[a] = b;
          return [c]
     }

     function we(a, b, c, d, e) {
          var f = [];
          jc(a, function (g, h) {
               (g = xe(g, b, c, d, e)) && f.push(h + "=" + g)
          });
          return f.join(b)
     }

     function xe(a, b, c, d, e) {
          if (null == a) return "";
          b = b || "&";
          c = c || ",$";
          "string" == typeof c && (c = c.split(""));
          if (a instanceof Array) {
               if (d = d || 0, d < c.length) {
                    for (var f = [], g = 0; g < a.length; g++) f.push(xe(a[g], b, c, d + 1, e));
                    return f.join(c[d])
               }
          } else if ("object" == typeof a) return e = e || 0, 2 > e ? encodeURIComponent(we(a, b, c, d, e + 1)) : "...";
          return encodeURIComponent(String(a))
     }

     function ye(a, b, c, d) {
          a.a.push(b);
          a.b[b] = ve(c, d)
     }

     function ze(a, b, c) {
          b = b + "//pagead2.googlesyndication.com" + c;
          var d = Ae(a) - c.length;
          if (0 > d) return "";
          a.a.sort(function (m, v) {
               return m - v
          });
          c = null;
          for (var e = "", f = 0; f < a.a.length; f++)
               for (var g = a.a[f], h = a.b[g], l = 0; l < h.length; l++) {
                    if (!d) {
                         c = null == c ? g : c;
                         break
                    }
                    var p = we(h[l], a.c, ",$");
                    if (p) {
                         p = e + p;
                         if (d >= p.length) {
                              d -= p.length;
                              b += p;
                              e = a.c;
                              break
                         }
                         a.g && (e = d, p[e - 1] == a.c && --e, b += p.substr(0, e), e = a.c, d = 0);
                         c = null == c ? g : c
                    }
               }
          a = "";
          null != c && (a = e + "trn=" + c);
          return b + a
     }

     function Ae(a) {
          var b = 1,
               c;
          for (c in a.b) b = c.length > b ? c.length : b;
          return 3997 - b - a.c.length - 1
     };

     function Be() {
          var a = void 0 === a ? C : a;
          this.b = "http:" === a.location.protocol ? "http:" : "https:";
          this.a = Math.random()
     }

     function Ce() {
          var a = De,
               b = Ee.google_srt;
          0 <= b && 1 >= b && (a.a = b)
     }

     function Fe(a, b, c, d, e, f) {
          if ((d ? a.a : Math.random()) < (e || .01)) try {
               if (c instanceof ue) var g = c;
               else g = new ue, jc(c, function (l, p) {
                    var m = g,
                         v = m.i++;
                    l = ve(p, l);
                    m.a.push(v);
                    m.b[v] = l
               });
               var h = ze(g, a.b, "/pagead/gen_204?id=" + b + "&");
               h && ("undefined" === typeof f ? zc(h, null) : zc(h, void 0 === f ? null : f))
          } catch (l) {}
     };

     function Ge(a, b) {
          this.start = a < b ? a : b;
          this.a = a < b ? b : a
     };

     function He(a, b, c) {
          this.b = b >= a ? new Ge(a, b) : null;
          this.a = c
     }

     function Ie(a, b) {
          b = void 0 === b ? 0 : b;
          b = 0 != b ? "google_experiment_mod" + b : "google_experiment_mod";
          var c = mc(a, b);
          return null != c ? c : nc(a, b)
     };
     var Ke = null;

     function Le() {
          if (null === Ke) {
               Ke = "";
               try {
                    var a = "";
                    try {
                         a = n.top.location.hash
                    } catch (c) {
                         a = n.location.hash
                    }
                    if (a) {
                         var b = a.match(/\bdeid=([\d,]+)/);
                         Ke = b ? b[1] : ""
                    }
               } catch (c) {}
          }
          return Ke
     };

     function Me() {
          var a = n.performance;
          return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : +new Date
     }

     function Ne() {
          var a = void 0 === a ? n : a;
          return (a = a.performance) && a.now ? a.now() : null
     };

     function Oe(a, b, c) {
          this.label = a;
          this.type = b;
          this.value = c;
          this.duration = 0;
          this.uniqueId = Math.random();
          this.slotId = void 0
     };
     var Pe = n.performance,
          Qe = !!(Pe && Pe.mark && Pe.measure && Pe.clearMarks),
          Re = Qa(function () {
               var a;
               if (a = Qe) a = Le(), a = !!a.indexOf && 0 <= a.indexOf("1337");
               return a
          });

     function Se() {
          var a = Ee;
          this.b = [];
          this.c = a || n;
          var b = null;
          a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.b = a.google_js_reporting_queue, b = a.google_measure_js_timing);
          this.a = Re() || (null != b ? b : 1 > Math.random())
     }

     function Te(a) {
          a && Pe && Re() && (Pe.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), Pe.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
     }
     Se.prototype.start = function (a, b) {
          if (!this.a) return null;
          var c = Ne() || Me();
          a = new Oe(a, b, c);
          b = "goog_" + a.label + "_" + a.uniqueId + "_start";
          Pe && Re() && Pe.mark(b);
          return a
     };

     function Ue() {
          var a = Ve;
          this.s = De;
          this.c = !0;
          this.b = null;
          this.i = this.M;
          this.a = void 0 === a ? null : a;
          this.g = !1
     }
     k = Ue.prototype;
     k.Ba = function (a) {
          this.i = a
     };
     k.ka = function (a) {
          this.b = a
     };
     k.Ca = function (a) {
          this.c = a
     };
     k.Da = function (a) {
          this.g = a
     };
     k.da = function (a, b, c) {
          try {
               if (this.a && this.a.a) {
                    var d = this.a.start(a.toString(), 3);
                    var e = b();
                    var f = this.a;
                    b = d;
                    if (f.a && "number" === typeof b.value) {
                         var g = Ne() || Me();
                         b.duration = g - b.value;
                         var h = "goog_" + b.label + "_" + b.uniqueId + "_end";
                         Pe && Re() && Pe.mark(h);
                         !f.a || 2048 < f.b.length || f.b.push(b)
                    }
               } else e = b()
          } catch (l) {
               f = this.c;
               try {
                    Te(d), f = this.i(a, new pe(l, {
                         message: We(l)
                    }), void 0, c)
               } catch (p) {
                    this.M(217, p)
               }
               if (!f) throw l;
          }
          return e
     };
     k.xa = function (a, b, c, d) {
          var e = this;
          return function (f) {
               for (var g = [], h = 0; h < arguments.length; ++h) g[h] = arguments[h];
               return e.da(a, function () {
                    return b.apply(c, g)
               }, d)
          }
     };
     k.M = function (a, b, c, d, e) {
          e = e || "jserror";
          try {
               var f = new ue;
               f.g = !0;
               ye(f, 1, "context", a);
               qe(b) || (b = new pe(b, {
                    message: We(b)
               }));
               b.msg && ye(f, 2, "msg", b.msg.substring(0, 512));
               var g = b.meta || {};
               if (this.b) try {
                    this.b(g)
               } catch (oa) {}
               if (d) try {
                    d(g)
               } catch (oa) {}
               b = [g];
               f.a.push(3);
               f.b[3] = b;
               d = n;
               b = [];
               g = null;
               do {
                    var h = d;
                    if (ac(h)) {
                         var l = h.location.href;
                         g = h.document && h.document.referrer || null
                    } else l = g, g = null;
                    b.push(new te(l || "", h));
                    try {
                         d = h.parent
                    } catch (oa) {
                         d = null
                    }
               } while (d && h != d);
               l = 0;
               for (var p = b.length - 1; l <= p; ++l) b[l].depth = p - l;
               h = n;
               if (h.location && h.location.ancestorOrigins && h.location.ancestorOrigins.length == b.length - 1)
                    for (p = 1; p < b.length; ++p) {
                         var m = b[p];
                         m.url || (m.url = h.location.ancestorOrigins[p - 1] || "", m.ua = !0)
                    }
               var v = new te(n.location.href, n, !1);
               h = null;
               var t = b.length - 1;
               for (m = t; 0 <= m; --m) {
                    var u = b[m];
                    !h && re.test(u.url) && (h = u);
                    if (u.url && !u.ua) {
                         v = u;
                         break
                    }
               }
               u = null;
               var G = b.length && b[t].url;
               0 != v.depth && G && (u = b[t]);
               var T = new se(v, u);
               T.b && ye(f, 4, "top", T.b.url || "");
               ye(f, 5, "url", T.a.url || "");
               Fe(this.s, e, f, this.g, c)
          } catch (oa) {
               try {
                    Fe(this.s, e, {
                         context: "ecmserr",
                         rctx: a,
                         msg: We(oa),
                         url: T && T.a.url
                    }, this.g, c)
               } catch (Je) {}
          }
          return this.c
     };

     function We(a) {
          var b = a.toString();
          a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
          a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
          if (a.stack) {
               a = a.stack;
               try {
                    -1 == a.indexOf(b) && (a = b + "\n" + a);
                    for (var c; a != c;) c = a, a = a.replace(/((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/, "$1");
                    b = a.replace(/\n */g, "\n")
               } catch (d) {}
          }
          return b
     };

     function M(a) {
          a = void 0 === a ? "" : a;
          var b = Error.call(this);
          this.message = b.message;
          "stack" in b && (this.stack = b.stack);
          this.name = "TagError";
          this.message = a ? "adsbygoogle.push() error: " + a : "";
          Error.captureStackTrace ? Error.captureStackTrace(this, M) : this.stack = Error().stack || ""
     }
     ka(M, Error);

     function Xe() {
          this.b = !1;
          this.a = null;
          this.g = !1;
          this.i = Math.random();
          this.c = this.M
     }
     k = Xe.prototype;
     k.ka = function (a) {
          this.a = a
     };
     k.Ca = function (a) {
          this.b = a
     };
     k.Da = function (a) {
          this.g = a
     };
     k.Ba = function (a) {
          this.c = a
     };
     k.M = function (a, b, c, d, e) {
          if ((this.g ? this.i : Math.random()) > (void 0 === c ? .01 : c)) return this.b;
          qe(b) || (b = new pe(b, {
               context: a,
               id: void 0 === e ? "jserror" : e
          }));
          if (d || this.a) b.meta = {}, this.a && this.a(b.meta), d && d(b.meta);
          n.google_js_errors = n.google_js_errors || [];
          n.google_js_errors.push(b);
          n.error_rep_loaded || (dc(n.document, n.location.protocol + "//pagead2.googlesyndication.com/pagead/js/err_rep.js"), n.error_rep_loaded = !0);
          return this.b
     };
     k.da = function (a, b, c) {
          try {
               var d = b()
          } catch (e) {
               if (!this.c(a, e, .01, c, "jserror")) throw e;
          }
          return d
     };
     k.xa = function (a, b, c, d) {
          var e = this;
          return function (f) {
               for (var g = [], h = 0; h < arguments.length; ++h) g[h] = arguments[h];
               return e.da(a, function () {
                    return b.apply(c, g)
               }, d)
          }
     };
     var De, Ye, Ze, Ee = Ld(),
          Ve = new Se;

     function $e(a) {
          null != a && (Ee.google_measure_js_timing = a);
          Ee.google_measure_js_timing || (a = Ve, a.a = !1, a.b != a.c.google_js_reporting_queue && (Re() && Ia(a.b, Te), a.b.length = 0))
     }

     function af(a) {
          var b = C.jerExpIds;
          if (ya(b) && 0 !== b.length) {
               var c = a.eid;
               if (c) {
                    b = ca(c.split(",")).concat(ca(b));
                    c = {};
                    for (var d = 0, e = 0; e < b.length;) {
                         var f = b[e++];
                         var g = f;
                         g = za(g) ? "o" + Aa(g) : (typeof g).charAt(0) + g;
                         Object.prototype.hasOwnProperty.call(c, g) || (c[g] = !0, b[d++] = f)
                    }
                    b.length = d;
                    a.eid = b.join(",")
               } else a.eid = b.join(",")
          }
     }

     function bf(a) {
          var b = C.jerUserAgent;
          b && (a.useragent = b)
     }(function () {
          De = new Be;
          "number" !== typeof Ee.google_srt && (Ee.google_srt = Math.random());
          Ce();
          Ye = new Ue;
          Ye.ka(function (b) {
               af(b);
               Ze && (b.jc = Ze);
               bf(b)
          });
          Ye.Da(!0);
          "complete" == Ee.document.readyState ? $e() : Ve.a && yc(Ee, "load", function () {
               $e()
          });
          var a = Sb.currentScript;
          Ze = a ? a.dataset.jc : ""
     })();

     function cf() {
          var a = [df, ef];
          Ye.ka(function (b) {
               Ia(a, function (c) {
                    c(b)
               });
               af(b);
               Ze && (b.jc = Ze);
               bf(b)
          })
     }

     function ff(a, b, c) {
          return Ye.da(a, b, c)
     }

     function gf(a, b) {
          return Ye.xa(a, b, void 0, void 0)
     }

     function hf(a, b, c) {
          Fe(De, a, b, !0, c, void 0)
     }

     function jf(a, b, c, d) {
          return 0 == (qe(b) ? b.msg || We(b.error) : We(b)).indexOf("TagError") ? (c = b instanceof pe ? b.error : b, c.pbr || (c.pbr = !0, Ye.M(a, b, .1, d, "puberror")), !1) : Ye.M(a, b, c, d)
     }

     function kf(a) {
          hf("rmvasft", {
               code: "ldr",
               branch: a ? "exp" : "cntr"
          })
     };

     function lf(a, b) {
          this.ra = a;
          this.ya = b
     }

     function mf(a) {
          var b = [].slice.call(arguments).filter(Pa());
          if (!b.length) return null;
          var c = [],
               d = {};
          b.forEach(function (e) {
               c = c.concat(e.ra || []);
               d = Object.assign(d, e.ya)
          });
          return new lf(c, d)
     }

     function nf(a) {
          switch (a) {
               case 1:
                    return new lf(null, {
                         google_ad_semantic_area: "mc"
                    });
               case 2:
                    return new lf(null, {
                         google_ad_semantic_area: "h"
                    });
               case 3:
                    return new lf(null, {
                         google_ad_semantic_area: "f"
                    });
               case 4:
                    return new lf(null, {
                         google_ad_semantic_area: "s"
                    });
               default:
                    return null
          }
     };
     var of = new lf(["google-auto-placed"], {
          google_tag_origin: "qs"
     });
     var pf = {},
          qf = (pf.google_ad_channel = !0, pf.google_ad_host = !0, pf);

     function rf(a, b) {
          a.location.href && a.location.href.substring && (b.url = a.location.href.substring(0, 200));
          hf("ama", b, .01)
     }

     function sf(a) {
          var b = {};
          jc(qf, function (c, d) {
               d in a && (b[d] = a[d])
          });
          return b
     };
     var tf = Ac("2019", 2012);

     function uf(a, b, c) {
          c || (c = Hc ? "https" : "http");
          n.location && "https:" == n.location.protocol && "http" == c && (c = "https");
          return [c, "://", a, b].join("")
     }

     function vf(a, b, c) {
          a = uf(a, b, c);
          H(182) && 2012 < tf && (a = a.replace(new RegExp(".js".replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08"), "g"), ("_fy" + tf + ".js").replace(/\$/g, "$$$$")));
          H(202) && (a += (0 < a.indexOf("?") ? "&" : "?") + "cache=bust");
          return a
     };
     var wf = null;

     function xf() {
          if (!Ec) return !1;
          if (null != wf) return wf;
          wf = !1;
          try {
               var a = Od(n);
               a && -1 != a.location.hash.indexOf("google_logging") && (wf = !0);
               n.localStorage.getItem("google_logging") && (wf = !0)
          } catch (b) {}
          return wf
     }

     function yf(a, b) {
          b = void 0 === b ? [] : b;
          var c = !1;
          n.google_logging_queue || (c = !0, n.google_logging_queue = []);
          n.google_logging_queue.push([a, b]);
          c && xf() && (a = vf(Ic(), "/pagead/js/logging_library.js"), dc(n.document, a))
     };

     function zf(a, b, c) {
          this.a = a;
          this.b = b;
          this.c = c
     }

     function Af(a, b, c) {
          return {
               top: a.b - c,
               right: a.a + a.c + b,
               bottom: a.b + c,
               left: a.a - b
          }
     };

     function Bf(a) {
          x(this, a, null, null)
     }
     q(Bf, w);

     function Cf(a) {
          x(this, a, null, null)
     }
     q(Cf, w);

     function Df(a) {
          x(this, a, null, null)
     }
     q(Df, w);

     function Ef(a) {
          x(this, a, Ff, null)
     }
     q(Ef, w);
     var Ff = [5];

     function Gf(a) {
          try {
               var b = a.localStorage.getItem("google_ama_settings");
               return b ? new Ef(b ? JSON.parse(b) : null) : null
          } catch (c) {
               return null
          }
     };

     function Hf() {
          this.a = {};
          this.b = {}
     }
     Hf.prototype.set = function (a, b) {
          this.a[a] = b;
          this.b[a] = a
     };
     Hf.prototype.get = function (a, b) {
          return void 0 !== this.a[a] ? this.a[a] : b
     };
     var If = {
          rectangle: 1,
          horizontal: 2,
          vertical: 4
     };

     function Jf() {
          this.wasPlaTagProcessed = !1;
          this.wasReactiveAdConfigReceived = {};
          this.adCount = {};
          this.wasReactiveAdVisible = {};
          this.stateForType = {};
          this.reactiveTypeEnabledInAsfe = {};
          this.isReactiveTagFirstOnPage = this.wasReactiveAdConfigHandlerRegistered = this.wasReactiveTagRequestSent = !1;
          this.reactiveTypeDisabledByPublisher = {};
          this.tagSpecificState = {};
          this.adRegion = null;
          this.improveCollisionDetection = 1;
          this.messageValidationEnabled = !1;
          this.floatingAdsStacking = new Kf
     }

     function Lf(a) {
          a.google_reactive_ads_global_state ? null == a.google_reactive_ads_global_state.floatingAdsStacking && (a.google_reactive_ads_global_state.floatingAdsStacking = new Kf) : a.google_reactive_ads_global_state = new Jf;
          return a.google_reactive_ads_global_state
     }

     function Kf() {
          this.maxZIndexRestrictions = {};
          this.nextRestrictionId = 0;
          this.maxZIndexListeners = []
     };

     function Mf(a) {
          a = a.document;
          var b = {};
          a && (b = "CSS1Compat" == a.compatMode ? a.documentElement : a.body);
          return b || {}
     }

     function N(a) {
          return Mf(a).clientWidth
     };

     function Nf(a, b) {
          for (var c = ["width", "height"], d = 0; d < c.length; d++) {
               var e = "google_ad_" + c[d];
               if (!b.hasOwnProperty(e)) {
                    var f = D(a[c[d]]);
                    f = null === f ? null : Math.round(f);
                    null != f && (b[e] = f)
               }
          }
     }

     function Of(a, b) {
          return !((pc.test(b.google_ad_width) || oc.test(a.style.width)) && (pc.test(b.google_ad_height) || oc.test(a.style.height)))
     }

     function Pf(a, b) {
          return (a = Qf(a, b)) ? a.y : 0
     }

     function Qf(a, b) {
          try {
               var c = b.document.documentElement.getBoundingClientRect(),
                    d = a.getBoundingClientRect();
               return {
                    x: d.left - c.left,
                    y: d.top - c.top
               }
          } catch (e) {
               return null
          }
     }

     function Rf(a, b) {
          do {
               var c = ec(a, b);
               if (c && "fixed" == c.position) return !1
          } while (a = a.parentElement);
          return !0
     }

     function Sf(a) {
          var b = 0,
               c;
          for (c in If) - 1 != a.indexOf(c) && (b |= If[c]);
          return b
     }

     function Tf(a, b, c, d, e) {
          if (Nd(a) != a) return Od(a) ? 3 : 16;
          if (!(488 > N(a))) return 4;
          if (!(a.innerHeight >= a.innerWidth)) return 5;
          var f = N(a);
          if (!f || (f - c) / f > d) a = 6;
          else {
               if (c = "true" != e.google_full_width_responsive) a: {
                    c = N(a);
                    for (b = b.parentElement; b; b = b.parentElement)
                         if ((d = ec(b, a)) && (e = D(d.width)) && !(e >= c) && "visible" != d.overflow) {
                              c = !0;
                              break a
                         } c = !1
               }
               a = c ? 7 : !0
          }
          return a
     }

     function Uf(a, b, c, d) {
          var e = Tf(b, c, a, .3, d);
          !0 !== e ? a = e : "true" == d.google_full_width_responsive || Rf(c, b) ? Vf(b) ? a = !0 : (b = N(b), a = b - a, a = b && 0 <= a ? !0 : b ? -10 > a ? 11 : 0 > a ? 14 : 12 : 10) : a = 9;
          return a
     }

     function Wf(a, b, c) {
          "rtl" == b ? a.style.marginRight = c : a.style.marginLeft = c
     }

     function Xf(a, b) {
          if (3 == b.nodeType) return /\S/.test(b.data);
          if (1 == b.nodeType) {
               if (/^(script|style)$/i.test(b.nodeName)) return !1;
               try {
                    var c = ec(b, a)
               } catch (d) {}
               return !c || "none" != c.display && !("absolute" == c.position && ("hidden" == c.visibility || "collapse" == c.visibility))
          }
          return !1
     }

     function Yf(a, b) {
          for (var c = 0; 100 > c && b.parentElement; ++c) {
               for (var d = b.parentElement.childNodes, e = 0; e < d.length; ++e) {
                    var f = d[e];
                    if (f != b && Xf(a, f)) return
               }
               b = b.parentElement;
               b.style.width = "100%";
               b.style.height = "auto"
          }
     }

     function Zf(a, b, c) {
          a = Qf(b, a);
          return "rtl" == c ? -a.x : a.x
     }

     function $f(a, b) {
          var c;
          c = (c = b.parentElement) ? (c = ec(c, a)) ? c.direction : "" : "";
          if (c) {
               H(224) && (b.style.border = b.style.borderStyle = b.style.outline = b.style.outlineStyle = b.style.transition = "none", b.style.borderSpacing = b.style.padding = "0");
               Wf(b, c, "0px");
               b.style.width = N(a) + "px";
               if (0 !== Zf(a, b, c)) {
                    Wf(b, c, "0px");
                    var d = Zf(a, b, c);
                    Wf(b, c, -1 * d + "px");
                    a = Zf(a, b, c);
                    0 !== a && a !== d && Wf(b, c, d / (a - d) * d + "px")
               }
               b.style.zIndex = 30
          }
     }

     function Vf(a) {
          return H(233) || a.location && "#bffwroe2etoq" == a.location.hash
     };

     function O(a, b) {
          this.b = a;
          this.a = b
     }
     k = O.prototype;
     k.minWidth = function () {
          return this.b
     };
     k.height = function () {
          return this.a
     };
     k.U = function (a) {
          return 300 < a && 300 < this.a ? this.b : Math.min(1200, Math.round(a))
     };
     k.ha = function (a) {
          return this.U(a) + "x" + this.height()
     };
     k.ca = function () {};

     function P(a, b, c, d) {
          d = void 0 === d ? function (f) {
               return f
          } : d;
          var e;
          return a.style && a.style[c] && d(a.style[c]) || (e = ec(a, b)) && e[c] && d(e[c]) || null
     }

     function ag(a) {
          return function (b) {
               return b.minWidth() <= a
          }
     }

     function bg(a, b, c, d) {
          var e = a && cg(c, b),
               f = dg(b, d);
          return function (g) {
               return !(e && g.height() >= f)
          }
     }

     function eg(a) {
          return function (b) {
               return b.height() <= a
          }
     }

     function cg(a, b) {
          return Pf(a, b) < Mf(b).clientHeight - 100
     }

     function fg(a, b) {
          a = Pf(a, b);
          b = Mf(b).clientHeight;
          return 0 == b ? null : a / b
     }

     function gg(a, b) {
          var c = P(b, a, "height", D);
          if (c) return c;
          var d = b.style.height;
          b.style.height = "inherit";
          c = P(b, a, "height", D);
          b.style.height = d;
          if (c) return c;
          c = Infinity;
          do(d = b.style && D(b.style.height)) && (c = Math.min(c, d)), (d = P(b, a, "maxHeight", D)) && (c = Math.min(c, d)); while ((b = b.parentElement) && "HTML" != b.tagName);
          return c
     }

     function dg(a, b) {
          var c = a.google_unique_id;
          return b && 0 == ("number" === typeof c ? c : 0) ? Math.max(250, 2 * Mf(a).clientHeight / 3) : 250
     };

     function hg(a, b) {
          for (var c = [], d = a.length, e = 0; e < d; e++) c.push(a[e]);
          c.forEach(b, void 0)
     };

     function ig(a) {
          if (1 != a.nodeType) var b = !1;
          else if (b = "INS" == a.tagName) a: {
               b = ["adsbygoogle-placeholder"];a = a.className ? a.className.split(/\s+/) : [];
               for (var c = {}, d = 0; d < a.length; ++d) c[a[d]] = !0;
               for (d = 0; d < b.length; ++d)
                    if (!c[b[d]]) {
                         b = !1;
                         break a
                    } b = !0
          }
          return b
     };

     function jg(a, b) {
          for (var c = 0; c < b.length; c++) {
               var d = b[c],
                    e = yb(d.cb);
               a[e] = d.value
          }
     };
     var kg = null;

     function lg() {
          if (!kg) {
               for (var a = n, b = a, c = 0; a && a != a.parent;)
                    if (a = a.parent, c++, ac(a)) b = a;
                    else break;
               kg = b
          }
          return kg
     };

     function mg(a, b, c, d) {
          this.g = a;
          this.b = b;
          this.c = c;
          this.a = d
     }

     function ng(a, b) {
          var c = [];
          try {
               c = b.querySelectorAll(a.g)
          } catch (g) {}
          if (!c.length) return [];
          b = c;
          c = b.length;
          if (0 < c) {
               for (var d = Array(c), e = 0; e < c; e++) d[e] = b[e];
               b = d
          } else b = [];
          b = og(a, b);
          "number" === typeof a.b && (c = a.b, 0 > c && (c += b.length), b = 0 <= c && c < b.length ? [b[c]] : []);
          if ("number" === typeof a.c) {
               c = [];
               for (d = 0; d < b.length; d++) {
                    e = pg(b[d]);
                    var f = a.c;
                    0 > f && (f += e.length);
                    0 <= f && f < e.length && c.push(e[f])
               }
               b = c
          }
          return b
     }
     mg.prototype.toString = function () {
          return JSON.stringify({
               nativeQuery: this.g,
               occurrenceIndex: this.b,
               paragraphIndex: this.c,
               ignoreMode: this.a
          })
     };

     function og(a, b) {
          if (null == a.a) return b;
          switch (a.a) {
               case 1:
                    return b.slice(1);
               case 2:
                    return b.slice(0, b.length - 1);
               case 3:
                    return b.slice(1, b.length - 1);
               case 0:
                    return b;
               default:
                    throw Error("Unknown ignore mode: " + a.a);
          }
     }

     function pg(a) {
          var b = [];
          hg(a.getElementsByTagName("p"), function (c) {
               100 <= qg(c) && b.push(c)
          });
          return b
     }

     function qg(a) {
          if (3 == a.nodeType) return a.length;
          if (1 != a.nodeType || "SCRIPT" == a.tagName) return 0;
          var b = 0;
          hg(a.childNodes, function (c) {
               b += qg(c)
          });
          return b
     }

     function rg(a) {
          return 0 == a.length || isNaN(a[0]) ? a : "\\" + (30 + parseInt(a[0], 10)) + " " + a.substring(1)
     };

     function sg(a) {
          if (!a) return null;
          var b = y(a, 7);
          if (y(a, 1) || a.Y() || 0 < y(a, 4).length) {
               var c = a.Y(),
                    d = y(a, 1),
                    e = y(a, 4);
               b = y(a, 2);
               var f = y(a, 5);
               a = tg(y(a, 6));
               var g = "";
               d && (g += d);
               c && (g += "#" + rg(c));
               if (e)
                    for (c = 0; c < e.length; c++) g += "." + rg(e[c]);
               b = (e = g) ? new mg(e, b, f, a) : null
          } else b = b ? new mg(b, y(a, 2), y(a, 5), tg(y(a, 6))) : null;
          return b
     }
     var ug = {
          1: 1,
          2: 2,
          3: 3,
          0: 0
     };

     function tg(a) {
          return null == a ? a : ug[a]
     }
     var vg = {
          1: 0,
          2: 1,
          3: 2,
          4: 3
     };

     function wg() {
          this.a = {};
          this.b = {}
     }
     wg.prototype.add = function (a) {
          this.a[a] = !0;
          this.b[a] = a
     };
     wg.prototype.contains = function (a) {
          return !!this.a[a]
     };

     function xg() {
          this.a = new Hf
     }
     xg.prototype.set = function (a, b) {
          var c = this.a.get(a);
          c || (c = new wg, this.a.set(a, c));
          c.add(b)
     };

     function yg(a, b) {
          function c() {
               d.push({
                    anchor: e.anchor,
                    position: e.position
               });
               return e.anchor == b.anchor && e.position == b.position
          }
          for (var d = [], e = a; e;) {
               switch (e.position) {
                    case 1:
                         if (c()) return d;
                         e.position = 2;
                    case 2:
                         if (c()) return d;
                         if (e.anchor.firstChild) {
                              e = {
                                   anchor: e.anchor.firstChild,
                                   position: 1
                              };
                              continue
                         } else e.position = 3;
                    case 3:
                         if (c()) return d;
                         e.position = 4;
                    case 4:
                         if (c()) return d
               }
               for (; e && !e.anchor.nextSibling && e.anchor.parentNode != e.anchor.ownerDocument.body;) {
                    e = {
                         anchor: e.anchor.parentNode,
                         position: 3
                    };
                    if (c()) return d;
                    e.position = 4;
                    if (c()) return d
               }
               e && e.anchor.nextSibling ? e = {
                    anchor: e.anchor.nextSibling,
                    position: 1
               } : e = null
          }
          return d
     };

     function zg(a, b) {
          this.b = a;
          this.a = b
     }

     function Ag(a, b) {
          var c = new xg,
               d = new wg;
          b.forEach(function (e) {
               if (A(e, Xd, 1)) {
                    e = A(e, Xd, 1);
                    if (A(e, L, 1) && A(A(e, L, 1), K, 1) && A(e, L, 2) && A(A(e, L, 2), K, 1)) {
                         var f = Bg(a, A(A(e, L, 1), K, 1)),
                              g = Bg(a, A(A(e, L, 2), K, 1));
                         if (f && g)
                              for (f = ba(yg({
                                        anchor: f,
                                        position: y(A(e, L, 1), 2)
                                   }, {
                                        anchor: g,
                                        position: y(A(e, L, 2), 2)
                                   })), g = f.next(); !g.done; g = f.next()) g = g.value, c.set(Aa(g.anchor), g.position)
                    }
                    A(e, L, 3) && A(A(e, L, 3), K, 1) && (f = Bg(a, A(A(e, L, 3), K, 1))) && c.set(Aa(f), y(A(e, L, 3), 2))
               } else A(e, Yd, 2) ? Cg(a, A(e, Yd, 2), c) : A(e, Zd, 3) && Dg(a, A(e, Zd, 3), d)
          });
          return new zg(c, d)
     }

     function Cg(a, b, c) {
          A(b, K, 1) && (a = Eg(a, A(b, K, 1))) && a.forEach(function (d) {
               d = Aa(d);
               c.set(d, 1);
               c.set(d, 4);
               c.set(d, 2);
               c.set(d, 3)
          })
     }

     function Dg(a, b, c) {
          A(b, K, 1) && (a = Eg(a, A(b, K, 1))) && a.forEach(function (d) {
               c.add(Aa(d))
          })
     }

     function Bg(a, b) {
          return (a = Eg(a, b)) && 0 < a.length ? a[0] : null
     }

     function Eg(a, b) {
          return (b = sg(b)) ? ng(b, a) : null
     };

     function Fg(a, b, c) {
          var d = Af(c, b + 1, b + 1);
          return !La(a, function (e) {
               return e.left < d.right && d.left < e.right && e.top < d.bottom && d.top < e.bottom
          })
     };

     function Gg(a, b) {
          if (!a) return !1;
          a = ec(a, b);
          if (!a) return !1;
          a = a.cssFloat || a.styleFloat;
          return "left" == a || "right" == a
     }

     function Hg(a) {
          for (a = a.previousSibling; a && 1 != a.nodeType;) a = a.previousSibling;
          return a ? a : null
     }

     function Ig(a) {
          return !!a.nextSibling || !!a.parentNode && Ig(a.parentNode)
     };

     function Jg(a, b) {
          return a && null != y(a, 4) && b[y(A(a, ae, 4), 2)] ? !1 : !0
     }

     function Kg(a) {
          var b = {};
          a && y(a, 6).forEach(function (c) {
               b[c] = !0
          });
          return b
     }

     function Lg(a, b, c, d) {
          this.a = n;
          this.L = a;
          this.b = b;
          this.i = d || null;
          this.s = (this.F = c) ? Ag(n.document, B(c, Vd, 5)) : Ag(n.document, []);
          this.c = 0;
          this.g = !1
     }

     function Mg(a, b) {
          if (a.g) return !0;
          a.g = !0;
          var c = B(a.b, be, 1);
          a.c = 0;
          var d = Kg(a.F),
               e;
          if (e = A(a.b, le, 15) && Gb(A(a.b, le, 15), 12)) a: {
               e = Gf(a.a);e = null === e ? null : B(e, Df, 5);
               var f = Gf(a.a);
               var g = null != f ? A(f, Bf, 6) || null : null;
               if (null == e) e = !1;
               else {
                    var h = .3,
                         l = f = 4;
                    g && (h = Eb(g, 2) || h, f = y(g, 1) || f, l = y(g, 3) || l);
                    g = h;
                    h = Gf(a.a);
                    h = null !== h && null != y(h, 4) ? Eb(h, 4) : 1;
                    g -= h;
                    h = [];
                    for (var p = 0; p < e.length; p++) {
                         if (.05 > g || (Ng(a).numAutoAdsPlaced || 0) >= f) {
                              e = !0;
                              break a
                         }
                         var m = y(e[p], 1);
                         if (null == m) break;
                         var v = c[m],
                              t = A(e[p], Cf, 2);
                         null != t && null != Eb(t, 1) && null != Eb(t, 2) && null != Eb(t, 3) && (t = new zf(Eb(t, 1), Eb(t, 2), Eb(t, 3)), Fg(h, l, t) && (m = Og(a, v, m, b, d, !1), null != m && null != m.W && (m = m.W.getBoundingClientRect(), h.push(m), v = a.a, g -= m.width * m.height / (Mf(v).clientHeight * N(v)))))
                    }
                    e = 0 < (Ng(a).numAutoAdsPlaced || 0)
               }
          }
          if (e) return !0;
          e = Gf(a.a);
          if (null !== e && Gb(e, 2)) return Ng(a).eatf = !0, yf(7, [!0, 0, !1]), !0;
          for (e = 0; e < c.length; e++)
               if (Og(a, c[e], e, b, d, !0)) return !0;
          yf(7, [!1, a.c, !1]);
          return !1
     }

     function Og(a, b, c, d, e, f) {
          if (1 !== y(b, 8) || !Jg(b, e)) return null;
          var g = A(b, ae, 4);
          if (!f || g && 2 == y(g, 1)) {
               a.c++;
               if (b = Pg(a, b, d, e)) d = Ng(a), d.placement = c, d.numAutoAdsPlaced || (d.numAutoAdsPlaced = 0), d.numAutoAdsPlaced++, yf(7, [!1, a.c, !0]);
               return b
          }
          return null
     }

     function Pg(a, b, c, d) {
          if (!Jg(b, d) || 1 != y(b, 8)) return null;
          d = A(b, K, 1);
          if (!d) return null;
          d = sg(d);
          if (!d) return null;
          d = ng(d, a.a.document);
          if (0 == d.length) return null;
          d = d[0];
          var e = y(b, 2);
          e = vg[e];
          e = void 0 === e ? null : e;
          var f;
          if (!(f = null == e)) {
               a: {
                    f = a.a;
                    switch (e) {
                         case 0:
                              f = Gg(Hg(d), f);
                              break a;
                         case 3:
                              f = Gg(d, f);
                              break a;
                         case 2:
                              var g = d.lastChild;
                              f = Gg(g ? 1 == g.nodeType ? g : Hg(g) : null, f);
                              break a
                    }
                    f = !1
               }
               if (c = !f && !(!c && 2 == e && !Ig(d))) c = 1 == e || 2 == e ? d : d.parentNode,
               c = !(c && !ig(c) && 0 >= c.offsetWidth);f = !c
          }
          if (!(c = f)) {
               c = a.s;
               f = y(b, 2);
               g = Aa(d);
               g = c.b.a.get(g);
               if (!(g = g ? g.contains(f) : !1)) a: {
                    if (c.a.contains(Aa(d))) switch (f) {
                         case 2:
                         case 3:
                              g = !0;
                              break a;
                         default:
                              g = !1;
                              break a
                    }
                    for (f = d.parentElement; f;) {
                         if (c.a.contains(Aa(f))) {
                              g = !0;
                              break a
                         }
                         f = f.parentElement
                    }
                    g = !1
               }
               c = g
          }
          if (c) return null;
          f = A(b, $d, 3);
          c = {};
          f && (c.Fa = y(f, 1), c.qa = y(f, 2), c.Ma = !!Fb(f, 3));
          f = A(b, ae, 4) && y(A(b, ae, 4), 2) ? y(A(b, ae, 4), 2) : null;
          f = nf(f);
          b = null == y(b, 12) ? null : y(b, 12);
          b = mf(a.i, f, null == b ? null : new lf(null, {
               google_ml_rank: b
          }));
          f = a.a;
          a = a.L;
          var h = f.document;
          g = Wb((new Xb(h)).a, "DIV");
          var l = g.style;
          l.textAlign = "center";
          l.width = "100%";
          l.height = "auto";
          l.clear = c.Ma ? "both" : "none";
          c.Sa && jg(l, c.Sa);
          h = Wb((new Xb(h)).a, "INS");
          l = h.style;
          l.display = "block";
          l.margin = "auto";
          l.backgroundColor = "transparent";
          c.Fa && (l.marginTop = c.Fa);
          c.qa && (l.marginBottom = c.qa);
          c.Ka && jg(l, c.Ka);
          g.appendChild(h);
          c = {
               ga: g,
               W: h
          };
          c.W.setAttribute("data-ad-format", "auto");
          g = [];
          if (h = b && b.ra) c.ga.className = h.join(" ");
          h = c.W;
          h.className = "adsbygoogle";
          h.setAttribute("data-ad-client", a);
          g.length && h.setAttribute("data-ad-channel", g.join("+"));
          a: {
               try {
                    var p = c.ga;
                    switch (e) {
                         case 0:
                              d.parentNode && d.parentNode.insertBefore(p, d);
                              break;
                         case 3:
                              var m = d.parentNode;
                              if (m) {
                                   var v = d.nextSibling;
                                   if (v && v.parentNode != m)
                                        for (; v && 8 == v.nodeType;) v = v.nextSibling;
                                   m.insertBefore(p, v)
                              }
                              break;
                         case 1:
                              d.insertBefore(p, d.firstChild);
                              break;
                         case 2:
                              d.appendChild(p)
                    }
                    ig(d) && (d.setAttribute("data-init-display", d.style.display), d.style.display = "block");
                    b: {
                         var t = c.W;t.setAttribute("data-adsbygoogle-status", "reserved");t.className += " adsbygoogle-noablate";p = {
                              element: t
                         };
                         var u = b && b.ya;
                         if (t.hasAttribute("data-pub-vars")) {
                              try {
                                   u = JSON.parse(t.getAttribute("data-pub-vars"))
                              } catch (G) {
                                   break b
                              }
                              t.removeAttribute("data-pub-vars")
                         }
                         u && (p.params = u);
                         (f.adsbygoogle = f.adsbygoogle || []).push(p)
                    }
               } catch (G) {
                    (t = c.ga) && t.parentNode && (u = t.parentNode, u.removeChild(t), ig(u) && (u.style.display = u.getAttribute("data-init-display") || "none"));
                    t = !1;
                    break a
               }
               t = !0
          }
          return t ? c : null
     }

     function Ng(a) {
          return a.a.google_ama_state = a.a.google_ama_state || {}
     };

     function Qg() {
          this.b = new Rg(this);
          this.a = 0
     }

     function Sg(a) {
          if (0 != a.a) throw Error("Already resolved/rejected.");
     }

     function Rg(a) {
          this.a = a
     }

     function Tg(a) {
          switch (a.a.a) {
               case 0:
                    break;
               case 1:
                    a.b && a.b(a.a.g);
                    break;
               case 2:
                    a.c && a.c(a.a.c);
                    break;
               default:
                    throw Error("Unhandled deferred state.");
          }
     };

     function Ug(a) {
          this.exception = a
     }

     function Vg(a, b) {
          this.c = n;
          this.a = a;
          this.b = b
     }
     Vg.prototype.start = function () {
          this.g()
     };
     Vg.prototype.g = function () {
          try {
               switch (this.c.document.readyState) {
                    case "complete":
                    case "interactive":
                         Mg(this.a, !0);
                         Wg(this);
                         break;
                    default:
                         Mg(this.a, !1) ? Wg(this) : this.c.setTimeout(Fa(this.g, this), 100)
               }
          } catch (a) {
               Wg(this, a)
          }
     };

     function Wg(a, b) {
          try {
               var c = a.b,
                    d = a.a;
               Ng(d);
               B(d.b, be, 1);
               var e = new Ug(b);
               Sg(c);
               c.a = 1;
               c.g = e;
               Tg(c.b)
          } catch (f) {
               a = a.b, b = f, Sg(a), a.a = 2, a.c = b, Tg(a.b)
          }
     };

     function Xg(a) {
          rf(a, {
               atf: 1
          })
     }

     function Yg(a, b) {
          (a.google_ama_state = a.google_ama_state || {}).exception = b;
          rf(a, {
               atf: 0
          })
     };

     function Zg() {
          this.debugCard = null;
          this.debugCardRequested = !1
     };

     function $g(a, b) {
          if (!a) return !1;
          a = a.hash;
          if (!a || !a.indexOf) return !1;
          if (-1 != a.indexOf(b)) return !0;
          b = ah(b);
          return "go" != b && -1 != a.indexOf(b) ? !0 : !1
     }

     function ah(a) {
          var b = "";
          Fd(a.split("_"), function (c) {
               b += c.substr(0, 2)
          });
          return b
     };
     var bh = {
          13: "0.001",
          22: "0.01",
          24: "0.05",
          28: "0.001",
          29: "0.01",
          60: "0.03",
          66: "0.1",
          79: "1200",
          82: "3",
          98: "0.01",
          99: "600",
          100: "100",
          103: "0.01",
          118: "false",
          126: "0.001",
          128: "false",
          129: "0.02",
          135: "0.01",
          136: "0.02",
          137: "0.01",
          149: "0",
          150: "1000",
          155: "0.06",
          160: "250",
          161: "150",
          162: "0.1",
          165: "0.02",
          173: "800",
          174: "2",
          177: "0.02",
          179: "100",
          180: "20",
          185: "0.1",
          189: "400",
          190: "60",
          193: "500",
          194: "0"
     };
     var ch = null;

     function dh() {
          this.a = bh
     }

     function Q(a, b) {
          a = parseFloat(a.a[b]);
          return isNaN(a) ? 0 : a
     };

     function eh(a, b, c) {
          var d = "script";
          d = void 0 === d ? "" : d;
          var e = a.createElement("link");
          try {
               e.rel = "preload";
               if (gb("preload", "stylesheet")) var f = Za(b).toString();
               else {
                    if (b instanceof Wa) var g = Za(b).toString();
                    else {
                         if (b instanceof jb) var h = mb(b);
                         else {
                              if (b instanceof jb) var l = b;
                              else b = "object" == typeof b && b.b ? b.a() : String(b), nb.test(b) || (b = "about:invalid#zClosurez"), l = new jb(kb, b);
                              h = mb(l)
                         }
                         g = h
                    }
                    f = g
               }
               e.href = f
          } catch (p) {
               return
          }
          d && (e.as = d);
          c && e.setAttribute("nonce", c);
          if (a = a.getElementsByTagName("head")[0]) try {
               a.appendChild(e)
          } catch (p) {}
     };

     function fh(a) {
          var b = {},
               c = {};
          return c.enable_page_level_ads = (b.pltais = !0, b), c.google_ad_client = a, c
     };

     function gh() {};

     function hh(a) {
          if (!a) return "";
          (a = a.toLowerCase()) && "ca-" != a.substring(0, 3) && (a = "ca-" + a);
          return a
     };

     function ih(a, b, c) {
          return jh(a, void 0 === c ? "" : c, function (d) {
               return La(B(d, Mb, 2), function (e) {
                    return y(e, 1) === b
               })
          })
     }

     function kh(a, b, c) {
          c = void 0 === c ? "" : c;
          var d = Od(a) || a;
          return lh(d, b) ? !0 : jh(a, c, function (e) {
               return La(y(e, 3), function (f) {
                    return f === b
               })
          })
     }

     function mh(a) {
          return jh(n, void 0 === a ? "" : a, function () {
               return !0
          })
     }

     function lh(a, b) {
          a = (a = (a = a.location && a.location.hash) && a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
          return !!a && Oa(a.split(","), b.toString())
     }

     function jh(a, b, c) {
          a = Od(a) || a;
          var d = nh(a);
          b && (b = hh(String(b)));
          return Ta(d, function (e, f) {
               return Object.prototype.hasOwnProperty.call(d, f) && (!b || b === f) && c(e)
          })
     }

     function nh(a) {
          a = oh(a);
          var b = {};
          Fd(a, function (c, d) {
               try {
                    var e = new Kb(c);
                    b[d] = e
               } catch (f) {}
          });
          return b
     }

     function oh(a) {
          try {
               var b = a.localStorage.getItem("google_adsense_settings");
               if (!b) return {};
               var c = JSON.parse(b);
               return c !== Object(c) ? {} : Sa(c, function (d, e) {
                    return Object.prototype.hasOwnProperty.call(c, e) && "string" === typeof e && ya(d)
               })
          } catch (d) {
               return {}
          }
     };

     function ph() {
          this.a = function () {
               return []
          };
          this.b = function () {
               return []
          }
     }

     function qh(a, b) {
          a.a = yd(ld, b, function () {
               return []
          });
          a.b = yd(md, b, function () {
               return []
          })
     }
     va(ph);
     var rh = {
               f: "368226950",
               h: "368226951"
          },
          sh = {
               f: "368226960",
               h: "368226961"
          },
          th = {
               f: "368226470",
               V: "368226471"
          },
          uh = {
               f: "368226480",
               V: "368226481"
          },
          vh = {
               f: "332260030",
               R: "332260031",
               P: "332260032"
          },
          wh = {
               f: "332260040",
               R: "332260041",
               P: "332260042"
          },
          xh = {
               f: "368226500",
               h: "368226501"
          },
          yh = {
               f: "36998750",
               h: "36998751"
          },
          zh = {
               f: "231196899",
               h: "231196900"
          },
          Ah = {
               f: "231196901",
               h: "231196902"
          },
          Bh = {
               o: "20040067",
               f: "20040068",
               oa: "1337"
          },
          Ch = {
               f: "21060548",
               o: "21060549"
          },
          Dh = {
               f: "21060623",
               o: "21060624"
          },
          Eh = {
               f: "22324606",
               h: "22324607"
          },
          Fh = {
               f: "21062271",
               o: "21062272"
          },
          Gh = {
               f: "229739148",
               h: "229739149"
          },
          Hh = {
               f: "229739146",
               h: "229739147"
          },
          Ih = {
               f: "20040012",
               h: "20040013"
          },
          Jh = {
               f: "151527201",
               T: "151527221",
               K: "151527222",
               J: "151527223",
               H: "151527224",
               I: "151527225"
          },
          R = {
               f: "151527001",
               T: "151527021",
               K: "151527022",
               J: "151527023",
               H: "151527024",
               I: "151527025"
          };

     function Kh(a) {
          return Ec && !!a.google_disable_experiments
     }
     Ld();

     function Lh(a) {
          var b = kh(n, 12, a.google_ad_client);
          a = "google_ad_host" in a;
          var c = J(n, rh.h),
               d = $g(n.location, "google_ads_preview");
          return b && !a && c || d
     }

     function Mh(a) {
          if (n.google_apltlad || Nd(n) != n || !a.google_ad_client) return null;
          var b = Lh(a),
               c = !J(n, th.V);
          if (!b && !c) return null;
          n.google_apltlad = !0;
          var d = fh(a.google_ad_client),
               e = d.enable_page_level_ads;
          jc(a, function (f, g) {
               Td[g] && "google_ad_client" != g && (e[g] = f)
          });
          b ? e.google_ad_channel = "AutoInsertAutoAdCode" : c && (e.google_pgb_reactive = 7, "google_ad_section" in a || "google_ad_region" in a) && (e.google_ad_section = a.google_ad_section || a.google_ad_region);
          return d
     }

     function Nh(a) {
          return za(a.enable_page_level_ads) && 7 == a.enable_page_level_ads.google_pgb_reactive
     };

     function ef(a) {
          try {
               var b = I(n).eids || [];
               null != b && 0 < b.length && (a.eid = b.join(","))
          } catch (c) {}
     }

     function df(a) {
          a.shv = Dc()
     }
     Ye.Ca(!Ec);

     function Oh(a, b) {
          return Pf(b, a) + P(b, a, "height", D)
     };

     function Ph() {
          var a = {};
          this[3] = (a[23] = function (b) {
               return ih(C, parseInt(b, 10))
          }, a[24] = function (b) {
               return kh(C, parseInt(b, 10))
          }, a);
          this[4] = {};
          this[5] = {}
     }
     va(Ph);
     var Qh = new He(200, 399, 0),
          Rh = new He(600, 699, 0),
          Sh = new He(800, 899, 0),
          Th = new He(0, 999, 5),
          Uh = new He(400, 499, 6);

     function Vh(a) {
          a = void 0 === a ? n : a;
          return a.ggeac || (a.ggeac = {})
     };

     function Wh() {
          var a = {};
          this[3] = (a[8] = function (b) {
               return !!ta(b)
          }, a[9] = function (b) {
               b = ta(b);
               var c;
               if (c = "function" == wa(b)) b = b && b.toString && b.toString(), c = "string" === typeof b && gb(b, "[native code]");
               return c
          }, a[10] = function () {
               return window == window.top
          }, a[22] = function () {
               return xc()
          }, a);
          a = {};
          this[4] = (a[5] = function (b) {
               b = Ie(window, void 0 === b ? 0 : b);
               return null != b ? b : void 0
          }, a[6] = function (b) {
               b = ta(b);
               return "number" === typeof b ? b : void 0
          }, a);
          a = {};
          this[5] = (a[2] = function () {
               return window.location.href
          }, a[3] = function () {
               try {
                    return window.top.location.hash
               } catch (b) {
                    return ""
               }
          }, a[4] = function (b) {
               b = ta(b);
               return "string" === typeof b ? b : void 0
          }, a)
     }
     va(Wh);

     function Xh(a) {
          x(this, a, Yh, null)
     }
     q(Xh, w);
     var Yh = [2];
     Xh.prototype.Y = function () {
          return z(this, 1, 0)
     };
     Xh.prototype.X = function () {
          return z(this, 7, 0)
     };

     function Zh(a) {
          x(this, a, $h, null)
     }
     q(Zh, w);
     var $h = [2];
     Zh.prototype.X = function () {
          return z(this, 5, 0)
     };

     function ai(a) {
          x(this, a, bi, null)
     }
     q(ai, w);

     function ci(a) {
          x(this, a, di, null)
     }
     q(ci, w);
     var bi = [1, 2],
          di = [2];
     ci.prototype.X = function () {
          return z(this, 1, 0)
     };
     var ei = [12, 13];

     function fi(a, b) {
          var c = this,
               d = void 0 === b ? {} : b;
          b = void 0 === d.ta ? !1 : d.ta;
          var e = void 0 === d.Ra ? {} : d.Ra;
          d = void 0 === d.Ya ? [] : d.Ya;
          this.a = a;
          this.i = b;
          this.c = e;
          this.g = d;
          this.b = {};
          (a = Le()) && Ia(a.split(",") || [], function (f) {
               (f = parseInt(f, 10)) && (c.b[f] = !0)
          })
     }

     function gi(a, b) {
          var c = [],
               d = hi(a.a, b);
          d.length && (9 !== b && (a.a = ii(a.a, b)), Ia(d, function (e) {
               if (e = ji(a, e)) {
                    var f = e.Y();
                    c.push(f);
                    a.g.push(f);
                    (e = B(e, Tc, 2)) && id(e)
               }
          }));
          return c
     }

     function ki(a, b) {
          a.a.push.apply(a.a, ca(Ja(Ka(b, function (c) {
               return new ci(c)
          }), function (c) {
               return !Oa(ei, c.X())
          })))
     }

     function ji(a, b) {
          var c = Xc.j().a;
          if (!Qc(A(b, Jc, 3), c)) return null;
          var d = B(b, Xh, 2),
               e = d.length * z(b, 1, 0),
               f = z(b, 6, 0);
          if (f) {
               e = Ie(window, f);
               if (null === e) return null;
               b = li(b, e);
               return !b || c && !Qc(A(b, Jc, 3), c) ? null : mi(a, [b], 1)
          }
          d = c ? Ja(d, function (g) {
               return Qc(A(g, Jc, 3), c)
          }) : d;
          return d.length ? (b = z(b, 4, 0)) ? ni(a, b, e, d) : mi(a, d, e / 1E3) : null
     }

     function ni(a, b, c, d) {
          var e = null != a.c[b] ? a.c[b] : 1E3;
          if (0 >= e) return null;
          d = mi(a, d, c / e);
          a.c[b] = d ? 0 : e - c;
          return d
     }

     function mi(a, b, c) {
          var d = a.b,
               e = Ma(b, function (f) {
                    return !!d[f.Y()]
               });
          return e ? e : a.i ? null : fc(b, c, !1)
     }

     function oi(a, b) {
          F(kd, function (c) {
               a.b[c] = !0
          }, b);
          F(ld, function (c) {
               return gi(a, c)
          }, b);
          F(md, function () {
               return a.g
          }, b);
          F(vd, function (c) {
               return ki(a, c)
          }, b)
     }

     function hi(a, b) {
          return (a = Ma(a, function (c) {
               return c.X() == b
          })) && B(a, Zh, 2) || []
     }

     function ii(a, b) {
          return Ja(a, function (c) {
               return c.X() != b
          })
     }

     function li(a, b) {
          var c = B(a, Xh, 2),
               d = c.length,
               e = z(a, 1, 0);
          a = z(a, 8, 0);
          var f = (b - a) % d;
          return b < a || b - a - f >= d * (e - 1) ? null : c[f]
     };

     function pi() {
          this.a = function () {}
     }
     va(pi);

     function qi(a) {
          pi.j().a(a)
     };

     function ri(a, b, c, d) {
          d = void 0 === d ? Vh() : d;
          d.hasOwnProperty("init-done") ? (yd(vd, d)(Ka(B(a, ci, 2), function (e) {
               return Jb(e)
          })), yd(wd, d)(Ka(B(a, Tc, 1), function (e) {
               return Jb(e)
          })), b && yd(xd, d)(b), si(d)) : (oi(new fi(B(a, ci, 2), c), d), zd(d), Ad(d), Bd(d), si(d), id(B(a, Tc, 1)), qi(Wh.j()), b && qi(b))
     }

     function si(a) {
          var b = a = void 0 === a ? Vh() : a;
          qh(ph.j(), b);
          b = a;
          Cd.j().a = yd(od, b);
          pi.j().a = yd(xd, a)
     };

     function S(a, b) {
          b && a.push(b)
     }

     function ti(a, b) {
          for (var c = [], d = 1; d < arguments.length; ++d) c[d - 1] = arguments[d];
          d = Od(a) || a;
          d = (d = (d = d.location && d.location.hash) && (d.match(/google_plle=([\d,]+)/) || d.match(/deid=([\d,]+)/))) && d[1];
          return !!d && La(c, Ga(gb, d))
     }

     function ui(a, b, c) {
          for (var d = 0; d < c.length; d++)
               if (ti(a, c[d])) return c[d];
          return Kh(a) ? null : fc(c, b)
     }

     function vi(a, b, c, d, e, f) {
          f = void 0 === f ? 1 : f;
          for (var g = 0; g < e.length; g++)
               if (ti(a, e[g])) return e[g];
          Kh(a) ? c = null : (f = void 0 === f ? 1 : f, 0 >= d ? c = null : (g = new Ge(c, c + d - 1), (d = d % f || d / f % e.length) || (d = b.b, d = !(d.start <= g.start && d.a >= g.a)), d ? c = null : (a = Ie(a, b.a), c = null !== a && g.start <= a && g.a >= a ? e[Math.floor((a - c) / f) % e.length] : null)));
          return c
     };

     function wi(a, b, c) {
          if (ac(a.document.getElementById(b).contentWindow)) a = a.document.getElementById(b).contentWindow, b = a.document, b.body && b.body.firstChild || (/Firefox/.test(navigator.userAgent) ? b.open("text/html", "replace") : b.open(), a.google_async_iframe_close = !0, b.write(c));
          else {
               a = a.document.getElementById(b).contentWindow;
               c = String(c);
               b = ['"'];
               for (var d = 0; d < c.length; d++) {
                    var e = c.charAt(d),
                         f = e.charCodeAt(0),
                         g = d + 1,
                         h;
                    if (!(h = wb[e])) {
                         if (!(31 < f && 127 > f))
                              if (f = e, f in xb) e = xb[f];
                              else if (f in wb) e = xb[f] = wb[f];
                         else {
                              h = f.charCodeAt(0);
                              if (31 < h && 127 > h) e = f;
                              else {
                                   if (256 > h) {
                                        if (e = "\\x", 16 > h || 256 < h) e += "0"
                                   } else e = "\\u", 4096 > h && (e += "0");
                                   e += h.toString(16).toUpperCase()
                              }
                              e = xb[f] = e
                         }
                         h = e
                    }
                    b[g] = h
               }
               b.push('"');
               a.location.replace("javascript:" + b.join(""))
          }
     };
     var xi = null;

     function U(a, b, c, d) {
          d = void 0 === d ? !1 : d;
          O.call(this, a, b);
          this.aa = c;
          this.Qa = d
     }
     ka(U, O);
     U.prototype.ea = function () {
          return this.aa
     };
     U.prototype.ca = function (a, b, c) {
          if (!b.google_ad_resize) {
               c.style.height = this.height() + "px";
               c = J(a, R.f);
               a = J(a, R.T) || J(a, R.K) || J(a, R.J) || J(a, R.H) || J(a, R.I);
               if (c || a) b.ovlp = !0;
               b.rpe = !0
          }
     };

     function yi(a) {
          return function (b) {
               return !!(b.aa & a)
          }
     };
     var zi = zb("script");

     function Ai(a, b, c, d, e, f, g, h, l, p, m, v, t, u) {
          this.Z = a;
          this.a = b;
          this.aa = void 0 === c ? null : c;
          this.c = void 0 === d ? null : d;
          this.ma = void 0 === e ? null : e;
          this.b = void 0 === f ? null : f;
          this.g = void 0 === g ? null : g;
          this.F = void 0 === h ? !1 : h;
          this.L = void 0 === l ? !1 : l;
          this.Ga = void 0 === p ? null : p;
          this.Ha = void 0 === m ? null : m;
          this.i = void 0 === v ? null : v;
          this.s = void 0 === t ? null : t;
          this.Ia = void 0 === u ? null : u;
          this.na = this.ba = this.$ = null
     }

     function Bi(a, b, c) {
          null != a.aa && (c.google_responsive_formats = a.aa);
          null != a.ma && (c.google_safe_for_responsive_override = a.ma);
          null != a.b && (!0 === a.b ? c.google_full_width_responsive_allowed = !0 : (c.google_full_width_responsive_allowed = !1, c.gfwrnwer = a.b));
          null != a.g && !0 !== a.g && (c.gfwrnher = a.g);
          a.F && (c.google_bfa = a.F);
          a.L && (c.ebfa = a.L);
          var d = a.s || c.google_ad_width;
          null != d && (c.google_resizing_width = d);
          d = a.i || c.google_ad_height;
          null != d && (c.google_resizing_height = d);
          d = a.a.U(b);
          var e = a.a.height();
          c.google_ad_resize || (c.google_ad_width = d, c.google_ad_height = e, c.google_ad_format = a.a.ha(b), c.google_responsive_auto_format = a.Z, null != a.c && (c.armr = a.c), c.google_ad_resizable = !0, c.google_override_format = 1, c.google_loader_features_used = 128, !0 === a.b && (c.gfwrnh = a.a.height() + "px"));
          null != a.Ga && (c.gfwroml = a.Ga);
          null != a.Ha && (c.gfwromr = a.Ha);
          null != a.i && (c.gfwroh = a.i);
          null != a.s && (c.gfwrow = a.s);
          null != a.Ia && (c.gfwroz = a.Ia);
          null != a.$ && (c.gml = a.$);
          null != a.ba && (c.gmr = a.ba);
          null != a.na && (c.gzi = a.na);
          b = Ld();
          b = Od(b) || b;
          $g(b.location, "google_responsive_slot_debug") && (c.ds = "outline:thick dashed " + (d && e ? !0 !== a.b || !0 !== a.g ? "#ffa500" : "#0f0" : "#f00") + " !important;");
          !$g(b.location, "google_responsive_dummy_ad") || !Oa([1, 2, 3, 4, 5, 6, 7, 8], a.Z) && 1 !== a.c || c.google_ad_resize || 2 === a.c || (a = JSON.stringify({
               googMsgType: "adpnt",
               key_value: [{
                    key: "qid",
                    value: "DUMMY_AD"
               }]
          }), c.dash = "<" + zi + ">window.top.postMessage('" + a + "', '*');\n          </" + zi + '>\n          <div id="dummyAd" style="width:' + d + "px;height:" + e + 'px;\n            background:#ddd;border:3px solid #f00;box-sizing:border-box;\n            color:#000;">\n            <p>Requested size:' + d + "x" + e + "</p>\n            <p>Rendered size:" + d + "x" + e + "</p>\n          </div>")
     };
     /*

      Copyright 2019 The AMP HTML Authors. All Rights Reserved.

      Licensed under the Apache License, Version 2.0 (the "License");
      you may not use this file except in compliance with the License.
      You may obtain a copy of the License at

           http://www.apache.org/licenses/LICENSE-2.0

      Unless required by applicable law or agreed to in writing, software
      distributed under the License is distributed on an "AS-IS" BASIS,
      WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
      See the License for the specific language governing permissions and
      limitations under the License.
     */
     var Ci = {},
          Di = (Ci.image_stacked = 1 / 1.91, Ci.image_sidebyside = 1 / 3.82, Ci.mobile_banner_image_sidebyside = 1 / 3.82, Ci.pub_control_image_stacked = 1 / 1.91, Ci.pub_control_image_sidebyside = 1 / 3.82, Ci.pub_control_image_card_stacked = 1 / 1.91, Ci.pub_control_image_card_sidebyside = 1 / 3.74, Ci.pub_control_text = 0, Ci.pub_control_text_card = 0, Ci),
          Ei = {},
          Fi = (Ei.image_stacked = 80, Ei.image_sidebyside = 0, Ei.mobile_banner_image_sidebyside = 0, Ei.pub_control_image_stacked = 80, Ei.pub_control_image_sidebyside = 0, Ei.pub_control_image_card_stacked = 85, Ei.pub_control_image_card_sidebyside = 0, Ei.pub_control_text = 80, Ei.pub_control_text_card = 80, Ei),
          Gi = {},
          Hi = (Gi.pub_control_image_stacked = 100, Gi.pub_control_image_sidebyside = 200, Gi.pub_control_image_card_stacked = 150, Gi.pub_control_image_card_sidebyside = 250, Gi.pub_control_text = 100, Gi.pub_control_text_card = 150, Gi);

     function Ii(a) {
          var b = 0;
          a.A && b++;
          a.u && b++;
          a.v && b++;
          if (3 > b) return {
               w: "Tags data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num should be set together."
          };
          b = a.A.split(",");
          var c = a.v.split(",");
          a = a.u.split(",");
          if (b.length !== c.length || b.length !== a.length) return {
               w: 'Lengths of parameters data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num must match. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside"'
          };
          if (2 < b.length) return {
               w: "The parameter length of attribute data-matched-content-ui-type, data-matched-content-columns-num and data-matched-content-rows-num is too long. At most 2 parameters for each attribute are needed: one for mobile and one for desktop, while you are providing " + (b.length + ' parameters. Example: \n data-matched-content-rows-num="4,2"\ndata-matched-content-columns-num="1,6"\ndata-matched-content-ui-type="image_stacked,image_card_sidebyside".')
          };
          for (var d = [], e = [], f = 0; f < b.length; f++) {
               var g = Number(c[f]);
               if (isNaN(g) || 0 === g) return {
                    w: "Wrong value '" + c[f] + "' for data-matched-content-rows-num."
               };
               d.push(g);
               g = Number(a[f]);
               if (isNaN(g) || 0 === g) return {
                    w: "Wrong value '" + a[f] + "' for data-matched-content-columns-num."
               };
               e.push(g)
          }
          return {
               v: d,
               u: e,
               wa: b
          }
     }

     function Ji(a) {
          return 1200 <= a ? {
               width: 1200,
               height: 600
          } : 850 <= a ? {
               width: a,
               height: Math.floor(.5 * a)
          } : 550 <= a ? {
               width: a,
               height: Math.floor(.6 * a)
          } : 468 <= a ? {
               width: a,
               height: Math.floor(.7 * a)
          } : {
               width: a,
               height: Math.floor(3.44 * a)
          }
     };
     var Ki = ["google_content_recommendation_ui_type", "google_content_recommendation_columns_num", "google_content_recommendation_rows_num"];

     function Li(a, b) {
          O.call(this, a, b)
     }
     ka(Li, O);
     Li.prototype.U = function (a) {
          return Math.min(1200, Math.max(this.minWidth(), Math.round(a)))
     };

     function Mi(a, b) {
          Ni(a, b);
          if ("pedestal" == b.google_content_recommendation_ui_type) return new Ai(9, new Li(a, Math.floor(a * b.google_phwr)));
          var c = $b();
          468 > a ? c ? (c = a - 8 - 8, c = Math.floor(c / 1.91 + 70) + Math.floor(11 * (c * Di.mobile_banner_image_sidebyside + Fi.mobile_banner_image_sidebyside) + 96), a = {
               O: a,
               N: c,
               u: 1,
               v: 12,
               A: "mobile_banner_image_sidebyside"
          }) : (a = Ji(a), a = {
               O: a.width,
               N: a.height,
               u: 1,
               v: 13,
               A: "image_sidebyside"
          }) : (a = Ji(a), a = {
               O: a.width,
               N: a.height,
               u: 4,
               v: 2,
               A: "image_stacked"
          });
          Oi(b, a);
          return new Ai(9, new Li(a.O, a.N))
     }

     function Pi(a, b) {
          Ni(a, b);
          var c = Ii({
               v: b.google_content_recommendation_rows_num,
               u: b.google_content_recommendation_columns_num,
               A: b.google_content_recommendation_ui_type
          });
          if (c.w) a = {
               O: 0,
               N: 0,
               u: 0,
               v: 0,
               A: "image_stacked",
               w: c.w
          };
          else {
               var d = 2 === c.wa.length && 468 <= a ? 1 : 0;
               var e = c.wa[d];
               e = 0 === e.indexOf("pub_control_") ? e : "pub_control_" + e;
               var f = Hi[e];
               for (var g = c.u[d]; a / g < f && 1 < g;) g--;
               f = g;
               c = c.v[d];
               d = Math.floor(((a - 8 * f - 8) / f * Di[e] + Fi[e]) * c + 8 * c + 8);
               a = 1500 < a ? {
                    width: 0,
                    height: 0,
                    la: "Calculated slot width is too large: " + a
               } : 1500 < d ? {
                    width: 0,
                    height: 0,
                    la: "Calculated slot height is too large: " + d
               } : {
                    width: a,
                    height: d
               };
               a = a.la ? {
                    O: 0,
                    N: 0,
                    u: 0,
                    v: 0,
                    A: e,
                    w: a.la
               } : {
                    O: a.width,
                    N: a.height,
                    u: f,
                    v: c,
                    A: e
               }
          }
          if (a.w) throw new M(a.w);
          Oi(b, a);
          return new Ai(9, new Li(a.O, a.N))
     }

     function Ni(a, b) {
          if (0 >= a) throw new M("Invalid responsive width from Matched Content slot " + b.google_ad_slot + ": " + a + ". Please ensure to put this Matched Content slot into a non-zero width div container.");
     }

     function Oi(a, b) {
          a.google_content_recommendation_ui_type = b.A;
          a.google_content_recommendation_columns_num = b.u;
          a.google_content_recommendation_rows_num = b.v
     };

     function Qi(a, b) {
          O.call(this, a, b)
     }
     ka(Qi, O);
     Qi.prototype.U = function () {
          return this.minWidth()
     };
     Qi.prototype.ca = function (a, b, c) {
          $f(a, c);
          if (!b.google_ad_resize) {
               c.style.height = this.height() + "px";
               c = J(a, R.f);
               var d = J(a, R.T) || J(a, R.K) || J(a, R.J) || J(a, R.H) || J(a, R.I);
               if (c || d) b.ovlp = !0;
               b.rpe = !0;
               if (J(a, wh.f) || J(a, wh.R) || J(a, wh.P)) b.ovlp = !0
          }
     };
     var Ri = {
          "image-top": function (a) {
               return 600 >= a ? 284 + .414 * (a - 250) : 429
          },
          "image-middle": function (a) {
               return 500 >= a ? 196 - .13 * (a - 250) : 164 + .2 * (a - 500)
          },
          "image-side": function (a) {
               return 500 >= a ? 205 - .28 * (a - 250) : 134 + .21 * (a - 500)
          },
          "text-only": function (a) {
               return 500 >= a ? 187 - .228 * (a - 250) : 130
          },
          "in-article": function (a) {
               return 420 >= a ? a / 1.2 : 460 >= a ? a / 1.91 + 130 : 800 >= a ? a / 4 : 200
          }
     };

     function Si(a, b) {
          O.call(this, a, b)
     }
     ka(Si, O);
     Si.prototype.U = function () {
          return Math.min(1200, this.minWidth())
     };

     function Ti(a, b, c, d, e) {
          var f = e.google_ad_layout || "image-top";
          if ("in-article" == f && "false" != e.google_full_width_responsive) {
               var g = Tf(b, c, a, .2, e);
               if (!0 !== g) e.gfwrnwer = g;
               else if (g = N(b)) e.google_full_width_responsive_allowed = !0, c.parentElement && (Yf(b, c), $f(b, c), a = g)
          }
          if (250 > a) throw new M("Fluid responsive ads must be at least 250px wide: availableWidth=" + a);
          a = Math.min(1200, Math.floor(a));
          if (d && "in-article" != f) {
               f = Math.ceil(d);
               if (50 > f) throw new M("Fluid responsive ads must be at least 50px tall: height=" + f);
               return new Ai(11, new O(a, f))
          }
          if ("in-article" != f && (d = e.google_ad_layout_key)) {
               f = "" + d;
               b = Math.pow(10, 3);
               if (d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length) {
                    e = [];
                    for (g = 0; g < d; g++) e.push(parseInt(c[g], 36) / b);
                    b = e
               } else b = null;
               if (!b) throw new M("Invalid data-ad-layout-key value: " + f);
               f = (a + -725) / 1E3;
               c = 0;
               d = 1;
               e = b.length;
               for (g = 0; g < e; g++) c += b[g] * d, d *= f;
               f = Math.ceil(1E3 * c - -725 + 10);
               if (isNaN(f)) throw new M("Invalid height: height=" + f);
               if (50 > f) throw new M("Fluid responsive ads must be at least 50px tall: height=" + f);
               if (1200 < f) throw new M("Fluid responsive ads must be at most 1200px tall: height=" + f);
               return new Ai(11, new O(a, f))
          }
          d = Ri[f];
          if (!d) throw new M("Invalid data-ad-layout value: " + f);
          c = cg(c, b);
          b = N(b);
          b = "in-article" !== f || c || a !== b ? Math.ceil(d(a)) : Math.ceil(1.25 * d(a));
          return new Ai(11, "in-article" == f ? new Si(a, b) : new O(a, b))
     };

     function Ui(a) {
          return function (b) {
               for (var c = a.length - 1; 0 <= c; --c)
                    if (!a[c](b)) return !1;
               return !0
          }
     }

     function Vi(a, b, c) {
          for (var d = a.length, e = null, f = 0; f < d; ++f) {
               var g = a[f];
               if (b(g)) {
                    if (!c || c(g)) return g;
                    null === e && (e = g)
               }
          }
          return e
     };
     var V = [new U(970, 90, 2), new U(728, 90, 2), new U(468, 60, 2), new U(336, 280, 1), new U(320, 100, 2), new U(320, 50, 2), new U(300, 600, 4), new U(300, 250, 1), new U(250, 250, 1), new U(234, 60, 2), new U(200, 200, 1), new U(180, 150, 1), new U(160, 600, 4), new U(125, 125, 1), new U(120, 600, 4), new U(120, 240, 4), new U(120, 120, 1, !0)],
          Wi = [V[6], V[12], V[3], V[0], V[7], V[14], V[1], V[8], V[10], V[4], V[15], V[2], V[11], V[5], V[13], V[9], V[16]];

     function Xi(a, b, c, d, e) {
          "false" != e.google_full_width_responsive || c.location && "#gfwrffwaifhp" == c.location.hash ? "autorelaxed" == b && (e.google_full_width_responsive || J(c, Gh.h)) || Yi(b) || e.google_ad_resize ? (Vf(c) && Yf(c, d), b = Uf(a, c, d, e), c = !0 !== b ? {
               l: a,
               m: b
          } : {
               l: N(c) || a,
               m: !0
          }) : c = {
               l: a,
               m: 2
          } : c = {
               l: a,
               m: 1
          };
          b = c.m;
          return !0 !== b ? {
               l: a,
               m: b
          } : d.parentElement ? {
               l: c.l,
               m: b
          } : {
               l: a,
               m: b
          }
     }

     function Zi(a, b, c, d, e) {
          var f = ff(247, function () {
                    return Xi(a, b, c, d, e)
               }),
               g = f.l;
          f = f.m;
          var h = !0 === f,
               l = D(d.style.width),
               p = D(d.style.height),
               m = $i(g, b, c, d, e, h);
          g = m.G;
          h = m.D;
          var v = m.B,
               t = m.C,
               u = m.ea;
          m = m.va;
          var G = aj(b, u),
               T, oa = (T = P(d, c, "marginLeft", D)) ? T + "px" : "",
               Je = (T = P(d, c, "marginRight", D)) ? T + "px" : "";
          T = P(d, c, "zIndex") || "";
          return new Ai(G, g, u, null, m, f, h, v, t, oa, Je, p, l, T)
     }

     function Yi(a) {
          return "auto" == a || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
     }

     function $i(a, b, c, d, e, f) {
          b = "auto" == b ? .25 >= a / Math.min(1200, N(c)) ? 4 : 3 : Sf(b);
          var g = !1,
               h = !1;
          if (488 > N(c)) {
               var l = Rf(d, c);
               var p = cg(d, c);
               g = !p && l;
               h = p && l
          }
          var m = 488 > N(c);
          p = [ag(a), yi(b)];
          Vf(c) || p.push(bg(m, c, d, h));
          null != e.google_max_responsive_height && p.push(eg(e.google_max_responsive_height));
          m = [function (t) {
               return !t.Qa
          }];
          !g && !h || Vf(c) || (g = gg(c, d), m.push(eg(g)));
          var v = !f && 3 === b && bj(c) ? new U(a, Math.floor(a / 1.2), 1) : Vi(Wi.slice(0), Ui(p), Ui(m));
          if (!v) throw new M("No slot size for availableWidth=" + a);
          m = ff(248, function () {
               var t;
               a: if (f) {
                    if (e.gfwrnh && (t = D(e.gfwrnh))) {
                         t = {
                              G: new Qi(a, t),
                              D: !0,
                              B: !1,
                              C: !1
                         };
                         break a
                    }
                    t = !1;
                    var u = Mf(c).clientHeight,
                         G = Pf(d, c),
                         T = c.google_lpabyc,
                         oa = fg(d, c);
                    if (oa && 2 < oa && !c.google_bfabyc && (!T || G - T > u) && (u = .9 * Mf(c).clientHeight, G = Math.min(u, cj(c, d, e)), u && G == u)) {
                         G = c.google_pbfabyc;
                         t = !G;
                         if (J(c, wh.R) || J(c, wh.P)) {
                              c.google_bfabyc = Pf(d, c) + u;
                              t = {
                                   G: new Qi(a, Math.floor(u)),
                                   D: !0,
                                   B: !0,
                                   C: !0
                              };
                              break a
                         }
                         G || (c.google_pbfabyc = Pf(d, c) + u)
                    }
                    u = a / 1.2;
                    if (Vf(c)) G = u;
                    else if (G = Math.min(u, cj(c, d, e)), G < .5 * u || 100 > G) G = u;
                    if (J(c, R.K) || J(c, R.J) || J(c, R.H) || J(c, R.I)) G *= 1.3;
                    t = {
                         G: new Qi(a, Math.floor(G)),
                         D: G < u ? 102 : !0,
                         B: !1,
                         C: t
                    }
               } else t = {
                    G: v,
                    D: 100,
                    B: !1,
                    C: !1
               };
               return t
          });
          g = m.G;
          p = m.D;
          h = m.B;
          m = m.C;
          return dj(c) ? {
               G: ej(a, c, d, g, e),
               D: !1,
               B: !1,
               C: !1,
               ea: b,
               va: l
          } : {
               G: g,
               D: p,
               B: h,
               C: m,
               ea: b,
               va: l
          }
     }

     function cj(a, b, c) {
          if (c.google_resizing_allowed || "true" == c.google_full_width_responsive) a = Infinity;
          else {
               c = Infinity;
               do {
                    var d = P(b, a, "height", D);
                    d && (c = Math.min(c, d));
                    (d = P(b, a, "maxHeight", D)) && (c = Math.min(c, d))
               } while ((b = b.parentElement) && "HTML" != b.tagName);
               a = c
          }
          return a
     }

     function aj(a, b) {
          if ("auto" == a) return 1;
          switch (b) {
               case 2:
                    return 2;
               case 1:
                    return 3;
               case 4:
                    return 4;
               case 3:
                    return 5;
               case 6:
                    return 6;
               case 5:
                    return 7;
               case 7:
                    return 8
          }
          throw Error("bad mask");
     }

     function ej(a, b, c, d, e) {
          var f = e.google_ad_height || P(c, b, "height", D);
          a = Ti(a, b, c, f, e).a;
          return a.minWidth() * a.height() > d.minWidth() * d.height() ? a : d
     }

     function dj(a) {
          return H(227) || a.location && "#hffwroe2etoq" == a.location.hash
     }

     function bj(a) {
          return H(232) || a.location && "#affwroe2etoq" == a.location.hash
     };

     function fj(a, b) {
          O.call(this, a, b)
     }
     ka(fj, O);
     fj.prototype.U = function () {
          return this.minWidth()
     };
     fj.prototype.ha = function (a) {
          return O.prototype.ha.call(this, a) + "_0ads_al"
     };
     var gj = [new fj(728, 15), new fj(468, 15), new fj(200, 90), new fj(180, 90), new fj(160, 90), new fj(120, 90)];

     function hj(a, b, c) {
          var d = 250,
               e = 90;
          d = void 0 === d ? 130 : d;
          e = void 0 === e ? 30 : e;
          var f = Vi(gj, ag(a));
          if (!f) throw new M("No link unit size for width=" + a + "px");
          a = Math.min(a, 1200);
          f = f.height();
          b = Math.max(f, b);
          d = (new Ai(10, new fj(a, Math.min(b, 15 == f ? e : d)))).a;
          b = d.minWidth();
          d = d.height();
          15 <= c && (d = c);
          return new Ai(10, new fj(b, d))
     }

     function ij(a, b, c, d) {
          if ("false" == d.google_full_width_responsive) return d.google_full_width_responsive_allowed = !1, d.gfwrnwer = 1, a;
          var e = Uf(a, b, c, d);
          if (!0 !== e) return d.google_full_width_responsive_allowed = !1, d.gfwrnwer = e, a;
          e = N(b);
          if (!e) return a;
          d.google_full_width_responsive_allowed = !0;
          $f(b, c);
          return e
     };

     function jj(a, b, c, d, e) {
          var f;
          (f = N(b)) ? 488 > N(b) ? b.innerHeight >= b.innerWidth ? (e.google_full_width_responsive_allowed = !0, $f(b, c), f = {
               l: f,
               m: !0
          }) : f = {
               l: a,
               m: 5
          } : f = {
               l: a,
               m: 4
          }: f = {
               l: a,
               m: 10
          };
          var g = f;
          f = g.l;
          g = g.m;
          if (!0 !== g || a == f) return new Ai(12, new O(a, d), null, null, !0, g, 100);
          a = $i(f, "auto", b, c, e, !0);
          return new Ai(1, a.G, a.ea, 2, !0, g, a.D, a.B, a.C)
     };

     function kj(a, b) {
          var c = b.google_ad_format;
          if ("autorelaxed" == c) {
               a: {
                    if ("pedestal" != b.google_content_recommendation_ui_type)
                         for (a = ba(Ki), c = a.next(); !c.done; c = a.next())
                              if (null != b[c.value]) {
                                   b = !0;
                                   break a
                              } b = !1
               }
               return b ? 9 : 5
          }
          if (Yi(c)) return 1;
          if ("link" == c) return 4;
          if ("fluid" == c) return "in-article" === b.google_ad_layout && (H(208) || H(227) || a.location && ("#hffwroe2etop" == a.location.hash || "#hffwroe2etoq" == a.location.hash)) ? (b.google_ad_format = "auto", b.armr = 3, 1) : 8
     }

     function lj(a, b, c, d, e) {
          e = b.offsetWidth || (c.google_ad_resize || (void 0 === e ? !1 : e)) && P(b, d, "width", D) || c.google_ad_width || 0;
          !J(d, zh.h) || 5 !== a && 9 !== a || (c.google_ad_format = "auto", c.google_ad_slot = "", a = 1);
          var f = (f = mj(a, e, b, c, d)) ? f : Zi(e, c.google_ad_format, d, b, c);
          f.a.ca(d, c, b);
          Bi(f, e, c);
          1 != a && (a = f.a.height(), b.style.height = a + "px")
     }

     function mj(a, b, c, d, e) {
          var f = d.google_ad_height || P(c, e, "height", D);
          switch (a) {
               case 5:
                    return a = ff(247, function () {
                         return Xi(b, d.google_ad_format, e, c, d)
                    }), f = a.l, a = a.m, !0 === a && b != f && $f(e, c), !0 === a ? d.google_full_width_responsive_allowed = !0 : (d.google_full_width_responsive_allowed = !1, d.gfwrnwer = a), nj(e) && (d.ovlp = !0), Mi(f, d);
               case 9:
                    return Pi(b, d);
               case 4:
                    return a = ij(b, e, c, d), hj(a, gg(e, c), f);
               case 8:
                    return Ti(b, e, c, f, d);
               case 10:
                    return jj(b, e, c, f, d)
          }
     }

     function nj(a) {
          return J(a, Gh.f) || J(a, Gh.h)
     };

     function W(a) {
          this.g = [];
          this.b = a || window;
          this.a = 0;
          this.c = null;
          this.i = 0
     }
     var oj;
     k = W.prototype;
     k.Na = function (a, b) {
          0 != this.a || 0 != this.g.length || b && b != window ? this.sa(a, b) : (this.a = 2, this.Aa(new pj(a, window)))
     };
     k.sa = function (a, b) {
          this.g.push(new pj(a, b || this.b));
          qj(this)
     };
     k.Ta = function (a) {
          this.a = 1;
          if (a) {
               var b = gf(188, Fa(this.za, this, !0));
               this.c = this.b.setTimeout(b, a)
          }
     };
     k.za = function (a) {
          a && ++this.i;
          1 == this.a && (null != this.c && (this.b.clearTimeout(this.c), this.c = null), this.a = 0);
          qj(this)
     };
     k.Za = function () {
          return !(!window || !Array)
     };
     k.Pa = function () {
          return this.i
     };

     function qj(a) {
          var b = gf(189, Fa(a.$a, a));
          a.b.setTimeout(b, 0)
     }
     k.$a = function () {
          if (0 == this.a && this.g.length) {
               var a = this.g.shift();
               this.a = 2;
               var b = gf(190, Fa(this.Aa, this, a));
               a.a.setTimeout(b, 0);
               qj(this)
          }
     };
     k.Aa = function (a) {
          this.a = 0;
          a.b()
     };

     function rj(a) {
          try {
               return a.sz()
          } catch (b) {
               return !1
          }
     }

     function sj(a) {
          return !!a && ("object" === typeof a || "function" === typeof a) && rj(a) && Gd(a.nq) && Gd(a.nqa) && Gd(a.al) && Gd(a.rl)
     }

     function tj() {
          if (oj && rj(oj)) return oj;
          var a = lg(),
               b = a.google_jobrunner;
          return sj(b) ? oj = b : a.google_jobrunner = oj = new W(a)
     }

     function uj(a, b) {
          tj().nq(a, b)
     }

     function vj(a, b) {
          tj().nqa(a, b)
     }
     W.prototype.nq = W.prototype.Na;
     W.prototype.nqa = W.prototype.sa;
     W.prototype.al = W.prototype.Ta;
     W.prototype.rl = W.prototype.za;
     W.prototype.sz = W.prototype.Za;
     W.prototype.tc = W.prototype.Pa;

     function pj(a, b) {
          this.b = a;
          this.a = b
     };

     function wj(a, b) {
          var c = Od(b);
          if (c) {
               c = N(c);
               var d = ec(a, b) || {},
                    e = d.direction;
               if ("0px" === d.width && "none" != d.cssFloat) return -1;
               if ("ltr" === e && c) return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
               if ("rtl" === e && c) return a = b.document.body.getBoundingClientRect().right - a.getBoundingClientRect().right, Math.floor(Math.min(1200, c - a - Math.floor((c - b.document.body.clientWidth) / 2)))
          }
          return -1
     };

     function xj(a) {
          var b = this;
          this.a = a;
          a.google_iframe_oncopy || (a.google_iframe_oncopy = {
               handlers: {},
               upd: function (c, d) {
                    var e = yj("rx", c),
                         f = Number;
                    a: {
                         if (c && (c = c.match("dt=([^&]+)")) && 2 == c.length) {
                              c = c[1];
                              break a
                         }
                         c = ""
                    }
                    f = f(c);
                    f = (new Date).getTime() - f;
                    e = e.replace(/&dtd=(\d+|-?M)/, "&dtd=" + (1E5 <= f ? "M" : 0 <= f ? f : "-M"));
                    b.set(d, e);
                    return e
               }
          });
          this.b = a.google_iframe_oncopy
     }
     xj.prototype.set = function (a, b) {
          var c = this;
          this.b.handlers[a] = b;
          this.a.addEventListener && this.a.addEventListener("load", function () {
               var d = c.a.document.getElementById(a);
               try {
                    var e = d.contentWindow.document;
                    if (d.onload && e && (!e.body || !e.body.firstChild)) d.onload()
               } catch (f) {}
          }, !1)
     };

     function yj(a, b) {
          var c = new RegExp("\\b" + a + "=(\\d+)"),
               d = c.exec(b);
          d && (b = b.replace(c, a + "=" + (+d[1] + 1 || 1)));
          return b
     }
     var zj, Aj = "var i=this.id,s=window.google_iframe_oncopy,H=s&&s.handlers,h=H&&H[i],w=this.contentWindow,d;try{d=w.document}catch(e){}if(h&&d&&(!d.body||!d.body.firstChild)){if(h.call){setTimeout(h,0)}else if(h.match){try{h=s.upd(h,i)}catch(e){}w.location.replace(h)}}";
     var X = Aj;
     /[\x00&<>"']/.test(X) && (-1 != X.indexOf("&") && (X = X.replace(ab, "&amp;")), -1 != X.indexOf("<") && (X = X.replace(bb, "&lt;")), -1 != X.indexOf(">") && (X = X.replace(cb, "&gt;")), -1 != X.indexOf('"') && (X = X.replace(db, "&quot;")), -1 != X.indexOf("'") && (X = X.replace(eb, "&#39;")), -1 != X.indexOf("\x00") && (X = X.replace(fb, "&#0;")));
     Aj = X;
     zj = Aj;
     var Bj = {},
          Cj = (Bj.google_ad_modifications = !0, Bj.google_analytics_domain_name = !0, Bj.google_analytics_uacct = !0, Bj.google_pause_ad_requests = !0, Bj);

     function Dj(a) {
          switch (a) {
               case "":
               case "Test":
               case "Real":
                    return !0;
               default:
                    return !1
          }
     }

     function Ej(a) {
          this.c = C;
          this.b = void 0 === a ? !1 : a;
          this.a = new Vb
     }

     function Fj(a) {
          var b = a.a.get("__gads", "");
          return a.b && !Dj(b) ? "Real" : b
     }
     Ej.prototype.write = function (a) {
          var b = y(a, 1);
          if (this.b) {
               if (!Dj(this.a.get("__gads", ""))) return;
               Dj(b) || (b = "Real")
          }
          this.a.set("__gads", b, y(a, 2) - this.c.Date.now() / 1E3, y(a, 3), y(a, 4), !1)
     };
     var Gj = /^\.google\.(com?\.)?[a-z]{2,3}$/,
          Hj = /\.(cn|com\.bi|do|sl|ba|by|ma|am)$/;

     function Ij(a) {
          return Gj.test(a) && !Hj.test(a)
     }
     var Jj = n;

     function Kj(a) {
          a = "https://adservice" + (a + "/adsid/integrator.js");
          var b = ["domain=" + encodeURIComponent(n.location.hostname)];
          Y[3] >= +new Date && b.push("adsid=" + encodeURIComponent(Y[1]));
          return a + "?" + b.join("&")
     }
     var Y, Z;

     function Lj() {
          Jj = n;
          Y = Jj.googleToken = Jj.googleToken || {};
          var a = +new Date;
          Y[1] && Y[3] > a && 0 < Y[2] || (Y[1] = "", Y[2] = -1, Y[3] = -1, Y[4] = "", Y[6] = "");
          Z = Jj.googleIMState = Jj.googleIMState || {};
          Ij(Z[1]) || (Z[1] = ".google.com");
          ya(Z[5]) || (Z[5] = []);
          "boolean" !== typeof Z[6] && (Z[6] = !1);
          ya(Z[7]) || (Z[7] = []);
          "number" !== typeof Z[8] && (Z[8] = 0)
     }
     var Mj = {
          ia: function () {
               return 0 < Z[8]
          },
          Va: function () {
               Z[8]++
          },
          Wa: function () {
               0 < Z[8] && Z[8]--
          },
          Xa: function () {
               Z[8] = 0
          },
          eb: function () {
               return !1
          },
          Oa: function () {
               return Z[5]
          },
          La: function (a) {
               try {
                    a()
               } catch (b) {
                    n.setTimeout(function () {
                         throw b;
                    }, 0)
               }
          },
          Ua: function () {
               if (!Mj.ia()) {
                    var a = n.document,
                         b = function (e) {
                              e = Kj(e);
                              a: {
                                   try {
                                        var f = qa();
                                        break a
                                   } catch (g) {}
                                   f = void 0
                              }
                              eh(a, e, f);
                              f = a.createElement("script");
                              f.type = "text/javascript";
                              f.onerror = function () {
                                   return n.processGoogleToken({}, 2)
                              };
                              e = Yb(e);
                              vb(f, e);
                              try {
                                   (a.head || a.body || a.documentElement).appendChild(f), Mj.Va()
                              } catch (g) {}
                         },
                         c = Z[1];
                    b(c);
                    ".google.com" != c && b(".google.com");
                    b = {};
                    var d = (b.newToken = "FBT", b);
                    n.setTimeout(function () {
                         return n.processGoogleToken(d, 1)
                    }, 1E3)
               }
          }
     };

     function Nj() {
          n.processGoogleToken = n.processGoogleToken || function (a, b) {
               var c = a;
               c = void 0 === c ? {} : c;
               b = void 0 === b ? 0 : b;
               a = c.newToken || "";
               var d = "NT" == a,
                    e = parseInt(c.freshLifetimeSecs || "", 10),
                    f = parseInt(c.validLifetimeSecs || "", 10),
                    g = c["1p_jar"] || "";
               c = c.pucrd || "";
               Lj();
               1 == b ? Mj.Xa() : Mj.Wa();
               var h = Jj.googleToken = Jj.googleToken || {},
                    l = 0 == b && a && "string" === typeof a && !d && "number" === typeof e && 0 < e && "number" === typeof f && 0 < f && "string" === typeof g;
               d = d && !Mj.ia() && (!(Y[3] >= +new Date) || "NT" == Y[1]);
               var p = !(Y[3] >= +new Date) && 0 != b;
               if (l || d || p) d = +new Date, e = d + 1E3 * e, f = d + 1E3 * f, 1E-5 > Math.random() && zc("https://pagead2.googlesyndication.com/pagead/gen_204?id=imerr&err=" + b, null), h[5] = b, h[1] = a, h[2] = e, h[3] = f, h[4] = g, h[6] = c, Lj();
               if (l || !Mj.ia()) {
                    b = Mj.Oa();
                    for (a = 0; a < b.length; a++) Mj.La(b[a]);
                    b.length = 0
               }
          };
          Lj();
          Y[3] >= +new Date && Y[2] >= +new Date || Mj.Ua()
     };
     var Oj = zb("script");

     function Pj() {
          C.google_sa_impl && !C.document.getElementById("google_shimpl") && (C.google_sa_queue = null, C.google_sl_win = null, C.google_sa_impl = null);
          if (!C.google_sa_queue) {
               C.google_sa_queue = [];
               C.google_sl_win = C;
               C.google_process_slots = function () {
                    return Qj(C)
               };
               var a = Rj();
               eh(C.document, a);
               !J(C, "20199337") || !sb() || r("iPhone") && !r("iPod") && !r("iPad") || r("iPad") || r("iPod") ? dc(C.document, a).id = "google_shimpl" : (a = Wb(document, "IFRAME"), a.id = "google_shimpl", a.style.display = "none", C.document.documentElement.appendChild(a), wi(C, "google_shimpl", "<!doctype html><html><body><" + (Oj + ">google_sl_win=window.parent;google_async_iframe_id='google_shimpl';</") + (Oj + ">") + Sj() + "</body></html>"), a.contentWindow.document.close())
          }
     }
     var Qj = gf(215, function (a) {
          var b = a.google_sa_queue,
               c = b.shift();
          a.google_sa_impl || hf("shimpl", {
               t: "no_fn"
          });
          "function" == wa(c) && ff(216, c);
          b.length && a.setTimeout(function () {
               return Qj(a)
          }, 0)
     });

     function Tj(a, b, c) {
          a.google_sa_queue = a.google_sa_queue || [];
          a.google_sa_impl ? c(b) : a.google_sa_queue.push(b)
     }

     function Sj() {
          var a = Rj();
          return "<" + Oj + ' src="' + a + '"></' + Oj + ">"
     }

     function Rj() {
          var a = "/show_ads_impl.js";
          a = void 0 === a ? "/show_ads_impl.js" : a;
          a: {
               if (Ec) try {
                    var b = C.google_cafe_host || C.top.google_cafe_host;
                    if (b) {
                         var c = b;
                         break a
                    }
               } catch (d) {}
               c = Ic()
          }
          return vf(c, ["/pagead/js/", Dc(), "/r20190131", a, ""].join(""), "https")
     }

     function Uj(a, b, c, d) {
          return function () {
               var e = !1;
               d && tj().al(3E4);
               try {
                    wi(a, b, c), e = !0
               } catch (g) {
                    var f = lg().google_jobrunner;
                    sj(f) && f.rl()
               }
               e && (e = yj("google_async_rrc", c), (new xj(a)).set(b, Uj(a, b, e, !1)))
          }
     }

     function Vj(a) {
          if (!xi) a: {
               for (var b = [n.top], c = [], d = 0, e; e = b[d++];) {
                    c.push(e);
                    try {
                         if (e.frames)
                              for (var f = e.frames.length, g = 0; g < f && 1024 > b.length; ++g) b.push(e.frames[g])
                    } catch (l) {}
               }
               for (b = 0; b < c.length; b++) try {
                    var h = c[b].frames.google_esf;
                    if (h) {
                         xi = h;
                         break a
                    }
               } catch (l) {}
               xi = null
          }
          if (!xi) {
               if (/[^a-z0-9-]/.test(a)) return null;
               c = Wb(document, "IFRAME");
               c.id = "google_esf";
               c.name = "google_esf";
               h = uf(Cc("", "googleads.g.doubleclick.net"), ["/pagead/html/", Dc(), "/r20190131/zrt_lookup.html#", encodeURIComponent("")].join(""));
               c.src = h;
               c.style.display = "none";
               c.setAttribute("data-ad-client", hh(a));
               return c
          }
          return null
     }

     function Wj(a, b, c) {
          Xj(a, b, c, function (d, e, f) {
               d = d.document;
               for (var g = e.id, h = 0; !g || d.getElementById(g + "_anchor");) g = "aswift_" + h++;
               e.id = g;
               e.name = g;
               g = Number(f.google_ad_width || 0);
               h = Number(f.google_ad_height || 0);
               var l = f.ds || "";
               l && (l += l.endsWith(";") ? "" : ";");
               var p = "";
               if (!f.google_enable_single_iframe) {
                    p = ["<iframe"];
                    for (m in e) e.hasOwnProperty(m) && p.push(m + "=" + e[m]);
                    p.push('style="left:0;position:absolute;top:0;border:0px;width:' + (g + "px;height:" + (h + 'px;"')));
                    p.push("></iframe>");
                    p = p.join(" ")
               }
               var m = e.id;
               var v = "";
               v = void 0 === v ? "" : v;
               g = "border:none;height:" + h + "px;margin:0;padding:0;position:relative;visibility:visible;width:" + (g + "px;background-color:transparent;");
               m = ['<ins id="' + (m + '_expand"'), ' style="display:inline-table;' + g + (void 0 === l ? "" : l) + '"', v ? ' data-ad-slot="' + v + '">' : ">", '<ins id="' + (m + '_anchor" style="display:block;') + g + '">', p, "</ins></ins>"].join("");
               16 == f.google_reactive_ad_format ? (f = d.createElement("div"), f.innerHTML = m, c.appendChild(f.firstChild)) : c.innerHTML = m;
               return e.id
          })
     }

     function Xj(a, b, c, d) {
          var e = b.google_ad_width,
               f = b.google_ad_height;
          J(a, Ih.h) ? (kf(!0), b.google_enable_single_iframe = !0) : J(a, Ih.f) && kf(!1);
          var g = {};
          null != e && (g.width = e && '"' + e + '"');
          null != f && (g.height = f && '"' + f + '"');
          g.frameborder = '"0"';
          g.marginwidth = '"0"';
          g.marginheight = '"0"';
          g.vspace = '"0"';
          g.hspace = '"0"';
          g.allowtransparency = '"true"';
          g.scrolling = '"no"';
          g.allowfullscreen = '"true"';
          g.onload = '"' + zj + '"';
          d = d(a, g, b);
          Yj(a, c, b);
          (c = Vj(b.google_ad_client)) && a.document.documentElement.appendChild(c);
          c = Ha;
          e = (new Date).getTime();
          b.google_lrv = Dc();
          b.google_async_iframe_id = d;
          b.google_unique_id = Id(a);
          b.google_start_time = c;
          b.google_bpp = e > c ? e - c : 1;
          b.google_async_rrc = 0;
          a.google_sv_map = a.google_sv_map || {};
          a.google_sv_map[d] = b;
          a.google_t12n_vars = bh;
          if (b.google_enable_single_iframe) {
               var h = {
                    pubWin: a,
                    iframeWin: null,
                    vars: b
               };
               Tj(a, function () {
                    a.google_sa_impl(h)
               }, a.document.getElementById(d + "_anchor") ? uj : vj)
          } else Tj(a, Uj(a, d, ["<!doctype html><html><body>", "<" + Oj + ">", "google_sl_win=window.parent;google_iframe_start_time=new Date().getTime();", 'google_async_iframe_id="' + d + '";', "</" + Oj + ">", "<" + Oj + ">window.parent.google_sa_impl({iframeWin: window, pubWin: window.parent, vars: window.parent['google_sv_map']['" + (d + "']});</") + Oj + ">", "</body></html>"].join(""), !0), a.document.getElementById(d) ? uj : vj)
     }

     function Yj(a, b, c) {
          var d = c.google_ad_output,
               e = c.google_ad_format,
               f = c.google_ad_width || 0,
               g = c.google_ad_height || 0;
          e || "html" != d && null != d || (e = f + "x" + g);
          d = !c.google_ad_slot || c.google_override_format || !Tb[c.google_ad_width + "x" + c.google_ad_height] && "aa" == c.google_loader_used;
          e && d ? e = e.toLowerCase() : e = "";
          c.google_ad_format = e;
          if ("number" !== typeof c.google_reactive_sra_index || !c.google_ad_unit_key) {
               e = [c.google_ad_slot, c.google_orig_ad_format || c.google_ad_format, c.google_ad_type, c.google_orig_ad_width || c.google_ad_width, c.google_orig_ad_height || c.google_ad_height];
               d = [];
               f = 0;
               for (g = b; g && 25 > f; g = g.parentNode, ++f) 9 === g.nodeType ? d.push("") : d.push(g.id);
               (d = d.join()) && e.push(d);
               c.google_ad_unit_key = lc(e.join(":")).toString();
               var h = void 0 === h ? !1 : h;
               e = [];
               for (d = 0; b && 25 > d; ++d) {
                    f = "";
                    void 0 !== h && h || (f = (f = 9 !== b.nodeType && b.id) ? "/" + f : "");
                    a: {
                         if (b && b.nodeName && b.parentElement) {
                              g = b.nodeName.toString().toLowerCase();
                              for (var l = b.parentElement.childNodes, p = 0, m = 0; m < l.length; ++m) {
                                   var v = l[m];
                                   if (v.nodeName && v.nodeName.toString().toLowerCase() === g) {
                                        if (b === v) {
                                             g = "." + p;
                                             break a
                                        }++p
                                   }
                              }
                         }
                         g = ""
                    }
                    e.push((b.nodeName && b.nodeName.toString().toLowerCase()) + f + g);
                    b = b.parentElement
               }
               h = e.join() + ":";
               b = [];
               if (a) try {
                    var t = a.parent;
                    for (e = 0; t && t !== a && 25 > e; ++e) {
                         var u = t.frames;
                         for (d = 0; d < u.length; ++d)
                              if (a === u[d]) {
                                   b.push(d);
                                   break
                              } a = t;
                         t = a.parent
                    }
               } catch (G) {}
               c.google_ad_dom_fingerprint = lc(h + b.join()).toString()
          }
     }
     var Zj = !Gc;

     function ak(a) {
          var b = a.value,
               c = "https://partner.googleadservices.com/gampad/cookie.js?domain=" + a.domain + "&callback=_gfp_s_&client=" + a.bb;
          a.ab && (c += "&test=1");
          b && (c += "&cookie=" + encodeURIComponent(b) + "&crv=" + Number("Test" !== b));
          return c
     }

     function bk(a) {
          var b = void 0 === b ? ak : b;
          var c = C._gfp_a_;
          if ("boolean" !== typeof c) throw Error("Illegal value of _gfp_a_: " + c);
          if (c) {
               c = C._gfp_p_;
               if ("boolean" !== typeof c) throw Error("Illegal value of _gfp_p_: " + c);
               if (!c) {
                    if (H(225)) {
                         c = H(226);
                         var d = new Ej(c);
                         navigator.cookieEnabled && (C._gfp_s_ = gf(629, function (e) {
                              delete C._gfp_s_;
                              if (!e) throw Error("Invalid JSONP response");
                              if (e = e._cookies_) {
                                   var f = e[0];
                                   if (!f) throw Error("Invalid JSONP response");
                                   e = f._value_;
                                   var g = f._expires_,
                                        h = f._path_;
                                   f = f._domain_;
                                   if ("string" !== typeof e || "number" !== typeof g || "string" !== typeof h || "string" !== typeof f) throw Error("Invalid JSONP response");
                                   d.write(Rb(Qb(Pb(Ob(e), g), h), f))
                              }
                         }), dc(C.document, b({
                              domain: C.location.hostname,
                              bb: a,
                              ab: c,
                              value: Fj(d)
                         })))
                    }
                    C._gfp_p_ = !0
               }
          }
     };

     function ck(a, b) {
          a = a.attributes;
          for (var c = a.length, d = 0; d < c; d++) {
               var e = a[d];
               if (/data-/.test(e.name)) {
                    var f = $a(e.name.replace("data-matched-content", "google_content_recommendation").replace("data", "google").replace(/-/g, "_"));
                    if (!b.hasOwnProperty(f)) {
                         e = e.value;
                         var g = {};
                         g = (g.google_reactive_ad_format = Ac, g.google_allow_expandable_ads = rc, g);
                         e = g.hasOwnProperty(f) ? g[f](e, null) : e;
                         null !== e && (b[f] = e)
                    }
               }
          }
     }

     function dk(a) {
          if (a = Dd(a)) switch (a.data && a.data.autoFormat) {
               case "rspv":
                    return 13;
               case "mcrspv":
                    return 15;
               default:
                    return 14
          } else return 12
     }

     function ek(a, b, c) {
          ck(a, b);
          if (c.document && c.document.body && !kj(c, b) && !b.google_reactive_ad_format) {
               var d = parseInt(a.style.width, 10),
                    e = wj(a, c);
               if (0 < e && d > e) {
                    var f = parseInt(a.style.height, 10);
                    d = !!Tb[d + "x" + f];
                    var g = e;
                    if (d) {
                         var h = Ub(e, f);
                         if (h) g = h, b.google_ad_format = h + "x" + f + "_0ads_al";
                         else throw new M("No slot size for availableWidth=" + e);
                    }
                    b.google_ad_resize = !0;
                    b.google_ad_width = g;
                    d || (b.google_ad_format = null, b.google_override_format = !0);
                    e = g;
                    a.style.width = e + "px";
                    f = Zi(e, "auto", c, a, b);
                    g = e;
                    f.a.ca(c, b, a);
                    Bi(f, g, b);
                    f = f.a;
                    b.google_responsive_formats = null;
                    f.minWidth() > e && !d && (b.google_ad_width = f.minWidth(), a.style.width = f.minWidth() + "px")
               }
          }
          d = a.offsetWidth || P(a, c, "width", D) || b.google_ad_width || 0;
          e = Ga(Zi, d, "auto", c, a, b, !1, !0);
          f = Od(c) || c;
          g = b.google_ad_client;
          f = f.location && "#ftptohbh" === f.location.hash ? 2 : $g(f.location, "google_responsive_slot_debug") || $g(f.location, "google_responsive_slot_preview") || H(217) ? 1 : H(218) ? 2 : ih(f, 1, g) ? 1 : kh(f, 11, g) ? H(219) ? 2 : 1 : 0;
          if (g = 0 !== f) b: if (!$b() && !H(216) || b.google_reactive_ad_format || kj(c, b) || Of(a, b) || b.google_ad_resize || Nd(c) != c) g = !1;
               else {
                    for (g = a; g; g = g.parentElement)
                         if (h = ec(g, c), !h || !Oa(["static", "relative"], h.position)) {
                              g = !1;
                              break b
                         } g = H(216) || !0 === Tf(c, a, d, .3, b) ? !0 : !1
               } g ? (b.google_resizing_allowed = !0, b.ovlp = !0, 2 === f ? (f = {}, Bi(e(), d, f), b.google_resizing_width = f.google_ad_width, b.google_resizing_height = f.google_ad_height, f.ds && (b.ds = f.ds), b.iaaso = !1) : (b.google_ad_format = "auto", b.iaaso = !0, b.armr = 1), kh(c, 11, b.google_ad_client) && (d = H(219) ? "AutoOptimizeAdSizeOriginal" : "AutoOptimizeAdSizeVariant", b.google_ad_channel = b.google_ad_channel ? [b.google_ad_channel, d].join("+") : d), d = !0) : d = !1;
          if (e = kj(c, b)) lj(e, a, b, c, d);
          else {
               if (Of(a, b)) {
                    if (d = ec(a, c)) a.style.width = d.width, a.style.height = d.height, Nf(d, b);
                    b.google_ad_width || (b.google_ad_width = a.offsetWidth);
                    b.google_ad_height || (b.google_ad_height = a.offsetHeight);
                    b.google_loader_features_used = 256;
                    b.google_responsive_auto_format = dk(c)
               } else Nf(a.style, b), 300 == b.google_ad_width && 250 == b.google_ad_height && (d = a.style.width, a.style.width = "100%", e = a.offsetWidth, a.style.width = d, b.google_available_width = e);
               c.location && "#gfwmrp" == c.location.hash || 12 == b.google_responsive_auto_format && "true" == b.google_full_width_responsive && !J(c, xh.h) ? lj(10, a, b, c, !1) : J(c, yh.h) && 12 == b.google_responsive_auto_format && (a = Uf(a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width, c, a, b), !0 !== a ? (b.efwr = !1, b.gfwrnwer = a) : b.efwr = !0)
          }
     };

     function fk(a, b, c) {
          var d = window;
          return function () {
               var e = Ne(),
                    f = 3;
               try {
                    var g = b.apply(this, arguments)
               } catch (h) {
                    f = 13;
                    if (c) return c(a, h), g;
                    throw h;
               } finally {
                    d.google_measure_js_timing && e && (e = {
                         label: a.toString(),
                         value: e,
                         duration: (Ne() || 0) - e,
                         type: f
                    }, f = d.google_js_reporting_queue = d.google_js_reporting_queue || [], 2048 > f.length && f.push(e))
               }
               return g
          }
     }

     function gk(a, b) {
          return fk(a, b, function (c, d) {
               (new Xe).M(c, d)
          })
     };

     function hk() {
          var a = this;
          this.i = this.L = this.c = this.b = this.a = 0;
          this.s = !1;
          if ("number" !== typeof n.goog_pvsid) try {
               Object.defineProperty(n, "goog_pvsid", {
                    value: Math.floor(Math.random() * Math.pow(2, 52))
               })
          } catch (b) {}
          this.$ = Number(n.goog_pvsid) || -1;
          (this.F = .1 > Math.random()) && ik("https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics&pvsid=" + this.$ + "&test=1");
          this.Z = new PerformanceObserver(gk(640, function (b) {
               b = ba(b.getEntries());
               for (var c = b.next(); !c.done; c = b.next()) {
                    c = c.value;
                    if ("layout-shift" === c.entryType) {
                         var d = c;
                         d.hadRecentInput || (a.a += Number(d.value), Number(d.value) > a.b && (a.b = Number(d.value)), a.c += 1)
                    }
                    "largest-contentful-paint" === c.entryType && (d = c, a.L = Math.floor(d.renderTime || d.loadTime));
                    "first-input" === c.entryType && (a.i = Number((c.processingStart - c.startTime).toFixed(3)), a.s = !0)
               }
          }));
          this.ba = !1;
          this.g = gk(641, this.g.bind(this))
     }
     ka(hk, gh);
     hk.prototype.g = function () {
          var a = document;
          if (2 === ({
                    visible: 1,
                    hidden: 2,
                    prerender: 3,
                    preview: 4,
                    unloaded: 5
               } [a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""] || 0) && !this.ba) {
               this.ba = !0;
               this.Z.takeRecords();
               a = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
               window.LayoutShift && (a += "&cls=" + this.a.toFixed(3), a += "&mls=" + this.b.toFixed(3), a += "&nls=" + this.c);
               window.LargestContentfulPaint && (a += "&lcp=" + Math.floor(this.L));
               window.PerformanceEventTiming && this.s && (a += "&fid=" + this.i);
               var b = ph.j().b();
               a += "&eid=" + b.join();
               a += "&pvsid=" + this.$;
               this.F && (a += "&test=1");
               ik(a)
          }
     };

     function ik(a) {
          window.fetch(a, {
               keepalive: !0,
               credentials: "include",
               redirect: "follow",
               method: "get",
               mode: "no-cors"
          })
     };

     function jk(a) {
          return Md.test(a.className) && "done" != a.getAttribute("data-adsbygoogle-status")
     }

     function kk(a, b) {
          a.setAttribute("data-adsbygoogle-status", "done");
          lk(a, b)
     }

     function lk(a, b) {
          var c = window,
               d = Ld();
          d.google_spfd || (d.google_spfd = ek);
          (d = b.google_reactive_ads_config) || ek(a, b, c);
          if (!mk(a, b, c)) {
               d || (c.google_lpabyc = Oh(c, a));
               if (d) {
                    d = d.page_level_pubvars || {};
                    if (I(C).page_contains_reactive_tag && !I(C).allow_second_reactive_tag) {
                         if (d.pltais) {
                              Qd(!1);
                              return
                         }
                         throw new M("Only one 'enable_page_level_ads' allowed per page.");
                    }
                    I(C).page_contains_reactive_tag = !0;
                    Qd(7 === d.google_pgb_reactive)
               } else Hd(c);
               Fd(Cj, function (e, f) {
                    b[f] = b[f] || c[f]
               });
               b.google_loader_used = "aa";
               b.google_reactive_tag_first = 1 === (I(C).first_tag_on_page || 0);
               ff(164, function () {
                    Wj(c, b, a)
               })
          }
     }

     function mk(a, b, c) {
          var d = b.google_reactive_ads_config;
          if (d) {
               var e = d.page_level_pubvars;
               var f = (za(e) ? e : {}).google_tag_origin
          }
          e = "string" === typeof a.className && /(\W|^)adsbygoogle-noablate(\W|$)/.test(a.className);
          var g = b.google_ad_slot;
          var h = f || b.google_tag_origin;
          f = I(c);
          Rd(f.ad_whitelist || [], g, h) ? g = null : (h = f.space_collapsing || "none", g = (g = Rd(f.ad_blacklist || [], g)) ? {
               pa: !0,
               Ea: g.space_collapsing || h
          } : f.remove_ads_by_default ? {
               pa: !0,
               Ea: h,
               fa: f.ablation_viewport_offset
          } : null);
          if (g && g.pa && "on" != b.google_adtest && !e && (e = fg(a, c), !g.fa || g.fa && (e || 0) >= g.fa)) return a.className += " adsbygoogle-ablated-ad-slot", c = c.google_sv_map = c.google_sv_map || {}, d = Aa(a), c[b.google_element_uid] = b, a.setAttribute("google_element_uid", d), "slot" == g.Ea && (null !== qc(a.getAttribute("width")) && a.setAttribute("width", 0), null !== qc(a.getAttribute("height")) && a.setAttribute("height", 0), a.style.width = "0px", a.style.height = "0px"), !0;
          if ((e = ec(a, c)) && "none" == e.display && !("on" == b.google_adtest || 0 < b.google_reactive_ad_format || d)) return c.document.createComment && a.appendChild(c.document.createComment("No ad requested because of display:none on the adsbygoogle tag")), !0;
          a = null == b.google_pgb_reactive || 3 === b.google_pgb_reactive;
          return 1 !== b.google_reactive_ad_format && 8 !== b.google_reactive_ad_format || !a ? !1 : (n.console && n.console.warn("Adsbygoogle tag with data-reactive-ad-format=" + b.google_reactive_ad_format + " is deprecated. Check out page-level ads at https://www.google.com/adsense"), !0)
     }

     function nk(a) {
          var b = document.getElementsByTagName("INS");
          for (var c = 0, d = b[c]; c < b.length; d = b[++c]) {
               var e = d;
               if (jk(e) && "reserved" != e.getAttribute("data-adsbygoogle-status") && (!a || d.id == a)) return d
          }
          return null
     }

     function ok() {
          var a = Wb(document, "INS");
          a.className = "adsbygoogle";
          a.className += " adsbygoogle-noablate";
          sc(a);
          return a
     }

     function pk(a) {
          var b = {};
          Fd(me, function (e, f) {
               !1 === a.enable_page_level_ads ? b[f] = !1 : a.hasOwnProperty(f) && (b[f] = a[f])
          });
          za(a.enable_page_level_ads) && (b.page_level_pubvars = a.enable_page_level_ads);
          var c = ok();
          Sb.body.appendChild(c);
          var d = {};
          d = (d.google_reactive_ads_config = b, d.google_ad_client = a.google_ad_client, d);
          d.google_pause_ad_requests = I(C).pause_ad_requests || !1;
          kk(c, d)
     }

     function qk(a) {
          return "complete" == a.readyState || "interactive" == a.readyState
     }

     function rk(a) {
          function b() {
               return pk(a)
          }
          var c = void 0 === c ? Sb : c;
          var d = Od(window);
          if (!d) throw new M("Page-level tag does not work inside iframes.");
          Lf(d).wasPlaTagProcessed = !0;
          if (c.body || qk(c)) b();
          else {
               var e = Ra(gf(191, b));
               yc(c, "DOMContentLoaded", e);
               (new n.MutationObserver(function (f, g) {
                    c.body && (e(), g.disconnect())
               })).observe(c, {
                    childList: !0,
                    subtree: !0
               })
          }
     }

     function sk(a) {
          var b = {};
          ff(165, function () {
               tk(a, b)
          }, function (c) {
               c.client = c.client || b.google_ad_client || a.google_ad_client;
               c.slotname = c.slotname || b.google_ad_slot;
               c.tag_origin = c.tag_origin || b.google_tag_origin
          })
     }

     function uk(a) {
          delete a.google_checked_head;
          jc(a, function (b, c) {
               Td[c] || (delete a[c], b = c.replace("google", "data").replace(/_/g, "-"), n.console.warn("AdSense head tag doesn't support " + b + " attribute."))
          })
     }

     function tk(a, b) {
          if (null == a) throw new M("push() called with no parameters.");
          Ha = (new Date).getTime();
          Pj();
          a: {
               if (void 0 != a.enable_page_level_ads) {
                    if ("string" === typeof a.google_ad_client) {
                         var c = !0;
                         break a
                    }
                    throw new M("'google_ad_client' is missing from the tag config.");
               }
               c = !1
          }
          if (c) vk(a, b);
          else if ((c = a.params) && Fd(c, function (e, f) {
                    b[f] = e
               }), "js" === b.google_ad_output) console.warn("Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads.");
          else {
               a = wk(a.element);
               ck(a, b);
               c = I(n).head_tag_slot_vars || {};
               jc(c, function (e, f) {
                    b.hasOwnProperty(f) || (b[f] = e)
               });
               if (a.hasAttribute("data-require-head") && !I(n).head_tag_slot_vars) throw new M("AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com.");
               if (!b.google_ad_client) throw new M("Ad client is missing from the slot.");
               H(210) && (b.google_apsail = mh(b.google_ad_client));
               var d = (c = 0 === (I(C).first_tag_on_page || 0) && Mh(b)) && Nh(c);
               c && !d && (vk(c), I(C).skip_next_reactive_tag = !0);
               0 === (I(C).first_tag_on_page || 0) && (I(C).first_tag_on_page = 2);
               "_gfp_p_" in C || (C._gfp_p_ = !1);
               bk(b.google_ad_client);
               b.google_pause_ad_requests = I(C).pause_ad_requests || !1;
               kk(a, b);
               c && d && xk(c)
          }
     }

     function xk(a) {
          function b() {
               Lf(n).wasPlaTagProcessed || n.adsbygoogle && n.adsbygoogle.push(a)
          }
          qk(Sb) ? b() : yc(Sb, "DOMContentLoaded", Ra(b))
     }

     function vk(a, b) {
          if (I(C).skip_next_reactive_tag) I(C).skip_next_reactive_tag = !1;
          else {
               0 === (I(C).first_tag_on_page || 0) && (I(C).first_tag_on_page = 1);
               b && a.tag_partner && (Pd(n, a.tag_partner), Pd(b, a.tag_partner));
               a: if (!I(C).ama_ran_on_page) {
                    try {
                         var c = n.localStorage.getItem("google_ama_config")
                    } catch (u) {
                         c = null
                    }
                    try {
                         var d = c ? new de(c ? JSON.parse(c) : null) : null
                    } catch (u) {
                         d = null
                    }
                    if (b = d)
                         if (c = A(b, fe, 3), !c || y(c, 1) <= +new Date) try {
                              n.localStorage.removeItem("google_ama_config")
                         } catch (u) {
                              rf(n, {
                                   lserr: 1
                              })
                         } else {
                              if (Nh(a) && (c = ne(n.location.pathname, B(b, ge, 7)), !c || !Fb(c, 8))) break a;
                              I(C).ama_ran_on_page = !0;
                              A(b, je, 13) && 1 === y(A(b, je, 13), 1) && (c = 0, A(A(b, je, 13), ke, 6) && y(A(A(b, je, 13), ke, 6), 3) && (c = y(A(A(b, je, 13), ke, 6), 3) || 0), d = I(n), d.remove_ads_by_default = !0, d.space_collapsing = "slot", d.ablation_viewport_offset = c);
                              yf(3, [Jb(b)]);
                              c = a.google_ad_client;
                              d = mf( of , new lf(null, sf(za(a.enable_page_level_ads) ? a.enable_page_level_ads : {})));
                              try {
                                   var e = ne(n.location.pathname, B(b, ge, 7)),
                                        f;
                                   if (f = e) b: {
                                        var g = y(e, 2);
                                        if (g)
                                             for (var h = 0; h < g.length; h++)
                                                  if (1 == g[h]) {
                                                       f = !0;
                                                       break b
                                                  } f = !1
                                   }
                                   if (f) {
                                        if (y(e, 4)) {
                                             f = {};
                                             var l = new lf(null, (f.google_package = y(e, 4), f));
                                             d = mf(d, l)
                                        }
                                        var p = new Lg(c, b, e, d),
                                             m = new Qg;
                                        (new Vg(p, m)).start();
                                        var v = m.b;
                                        var t = Ga(Yg, n);
                                        if (v.b) throw Error("Then functions already set.");
                                        v.b = Ga(Xg, n);
                                        v.c = t;
                                        Tg(v)
                                   }
                              } catch (u) {
                                   rf(n, {
                                        atf: -1
                                   })
                              }
                         }
               } rk(a)
          }
     }

     function wk(a) {
          if (a) {
               if (!jk(a) && (a.id ? a = nk(a.id) : a = null, !a)) throw new M("'element' has already been filled.");
               if (!("innerHTML" in a)) throw new M("'element' is not a good DOM element.");
          } else if (a = nk(), !a) throw new M("All ins elements in the DOM with class=adsbygoogle already have ads in them.");
          return a
     }

     function yk() {
          cf();
          Ye.Ba(jf);
          ff(166, zk)
     }

     function zk() {
          var a = Ed(Dd(C)) || C,
               b = I(a);
          if (!b.plle) {
               b.plle = !0;
               null == mc(a, "google_pem_mod") && nc(a, "google_pem_mod");
               var c = [null, null];
               try {
                    var d = JSON.parse("[[[186,null,null,[1]],[189,null,null,[1]],[null,30,null,[null,4]],[196,null,null,[1]],[207,null,null,[1]]],[[12,[[1,[[21064123],[21064124]]],[10,[[21064522],[21064523,[[203,null,null,[1]]]]],[4,null,9,null,null,null,null,[\x22LayoutShift\x22]]]]],[13,[[1,[[21064708],[21064709,[[215,null,null,[1]]]]]]]],[10,[[50,[[20040030,[[202,null,null,[1]]]],[20040031,[[202,null,null,[1]],[182,null,null,[1]]]],[20040032,[[202,null,null,[1]],[182,null,null,[],[[[2,[[4,null,8,null,null,null,null,[\x22IntersectionObserver\x22]],[4,null,8,null,null,null,null,[\x22Proxy\x22]]]],[1]]]]]]]],[1,[[21062810],[21062811]]],[null,[[21063914],[21063915,[[225,null,null,[1]]]]]],[1,[[21063996],[21063997,[[160,null,null,[1]]]]]],[5,[[21064530],[21064531,[[205,null,null,[1]]]],[21064532,[[null,30,null,[null,3]]]],[21064533,[[205,null,null,[1]],[null,30,null,[null,3]]]],[21064534,[[null,29,null,[null,2]]]],[21064535,[[205,null,null,[1]],[null,29,null,[null,2]]]],[21064536,[[null,29,null,[null,2]],[null,30,null,[null,3]]]],[21064537,[[205,null,null,[1]],[null,29,null,[null,2]],[null,30,null,[null,3]]]]]],[50,[[21064602],[21064603,[[226,null,null,[1]],[225,null,null,[1]]]]]],[50,[[21064784],[21064785,[[207,null,null,[]]]]]],[1,[[21064801],[21064802,[[236,null,null,[1]]]]]],[1000,[[182982000,[[218,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x227\x22]],[7,null,null,5,null,40,null,[\x227\x22]]]]],[182982100,[[217,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x227\x22]],[7,null,null,5,null,40,null,[\x227\x22]]]]]]],[1000,[[182982200,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x227\x22]],[7,null,null,5,null,40,null,[\x227\x22]]]]],[182982300,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x227\x22]],[7,null,null,5,null,40,null,[\x227\x22]]]]]]],[1000,[[182983000,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2215\x22]],[7,null,null,5,null,1000,null,[\x2215\x22]],[4,null,24,null,null,null,null,[\x2211\x22]]]]],[182983100,[[219,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2215\x22]],[7,null,null,5,null,1000,null,[\x2215\x22]],[4,null,24,null,null,null,null,[\x2211\x22]]]]]]],[1000,[[182983200,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2215\x22]],[7,null,null,5,null,1000,null,[\x2215\x22]],[4,null,24,null,null,null,null,[\x2211\x22]]]]],[182983300,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2215\x22]],[7,null,null,5,null,1000,null,[\x2215\x22]],[4,null,24,null,null,null,null,[\x2211\x22]]]]]]],[1000,[[182984000,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2212\x22]],[7,null,null,5,null,20,null,[\x2212\x22]],[4,null,23,null,null,null,null,[\x221\x22]]]]],[182984100,[[218,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2212\x22]],[7,null,null,5,null,20,null,[\x2212\x22]],[4,null,23,null,null,null,null,[\x221\x22]]]]]]],[1000,[[182984200,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2212\x22]],[7,null,null,5,null,20,null,[\x2212\x22]],[4,null,23,null,null,null,null,[\x221\x22]]]]],[182984300,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2212\x22]],[7,null,null,5,null,20,null,[\x2212\x22]],[4,null,23,null,null,null,null,[\x221\x22]]]]]]],[50,[[368226410,[[190,null,null,[1]]]],[368226411,[[224,null,null,[1]],[190,null,null,[1]]]]],null,null,null,19,2],[50,[[368226420],[368226421]],null,null,null,19,2],[50,[[368226430],[368226431]],null,null,null,19,2],[1000,[[368226570,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2216\x22]],[7,null,null,5,null,20,null,[\x2216\x22]]]]],[368226571,[[210,null,null,[1]],[211,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2216\x22]],[7,null,null,5,null,20,null,[\x2216\x22]]]]]]],[1000,[[368226580,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2217\x22]],[7,null,null,5,null,20,null,[\x2217\x22]]]]],[368226581,[[222,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2217\x22]],[7,null,null,5,null,20,null,[\x2217\x22]]]]]]],[1000,[[368226590,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2217\x22]],[7,null,null,5,null,20,null,[\x2217\x22]]]]],[368226591,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2217\x22]],[7,null,null,5,null,20,null,[\x2217\x22]]]]]]],[10,[[368226600,null,[7,null,null,3,null,2]],[368226601,null,[7,null,null,3,null,2]]],null,null,null,14,5],[10,[[368226610,[[218,null,null,[1]],[216,null,null,[1]],[190,null,null,[1]]],[7,null,null,3,null,2]],[368226611,[[216,null,null,[1]],[217,null,null,[1]],[190,null,null,[1]]],[7,null,null,3,null,2]]],null,null,null,14,5],[1000,[[368885003,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x224\x22]],[7,null,null,5,null,100,null,[\x224\x22]]]]],[368885004,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x224\x22]],[7,null,null,5,null,100,null,[\x224\x22]]]]]]],[1000,[[519641231,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2213\x22]],[7,null,null,5,null,2,null,[\x2213\x22]]]]],[519641232,[[191,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2213\x22]],[7,null,null,5,null,2,null,[\x2213\x22]]]]]]],[10,[[633794021,[[190,null,null,[1]]]],[633794022,[[208,null,null,[1]],[190,null,null,[1]]]],[633794023,[[227,null,null,[1]],[190,null,null,[1]]]],[633794024,[[190,null,null,[1]]]]],null,null,null,18],[1,[[633794031,[[190,null,null,[1]]]],[633794032,[[232,null,null,[1]],[190,null,null,[1]]]],[633794033,[[233,null,null,[1]],[190,null,null,[1]]]],[633794034,[[233,null,null,[1]],[232,null,null,[1]],[190,null,null,[1]]]]],null,null,null,21]]],[11,[[1000,[[368226300,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]],[368226301,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]]]],[1000,[[368226305,null,[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]],[368226306,null,[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]]]],[1000,[[368226310,[[190,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[02468]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]],[368226311,[[209,null,null,[1]],[190,null,null,[1]]],[2,[[12,null,null,5,null,null,\x22[13579]$\x22,[\x2211\x22]],[7,null,null,5,null,100,null,[\x2211\x22]]]]]]]]]]]")
               } catch (m) {
                    d = c
               }
               yf(13, [d]);
               ri(new ai(d), Ph.j(), {
                    ta: Kh(a)
               }, Vh(a));
               ph.j().a(12);
               ph.j().a(10);
               b.eids = Ka(ph.j().b(), String).concat(b.eids || []);
               b = b.eids;
               ch || (ch = new dh);
               var e = ch;
               Hc = !0;
               var f;
               d = xh;
               var g = ui(a, Q(e, 136), [d.f, d.h]);
               S(b, g);
               kh(a, 12) && (d = sh, c = rh, g = vi(a, new He(0, 999, 0), Q(e, 149), Q(e, 150), [d.f, d.h], 4), S(b, g), g == d.f ? f = c.f : g == d.h ? f = c.h : f = "", S(b, f));
               d = wh;
               g = vi(a, Qh, Q(e, 160), Q(e, 161), [d.f, d.R, d.P]);
               S(b, g);
               c = vh;
               g == d.f ? f = c.f : g == d.R ? f = c.R : g == d.P ? f = c.P : f = "";
               S(b, f);
               d = uh;
               g = vi(a, Th, Q(e, 179), Q(e, 180), [d.f, d.V]);
               S(b, g);
               c = th;
               g == d.f ? f = c.f : g == d.V ? f = c.V : f = "";
               S(b, f);
               $a("") && S(b, "");
               d = Bh;
               g = ui(a, Q(e, 13), [d.o, d.f]);
               S(b, g);
               g = ui(a, 0, [d.oa]);
               S(b, g);
               d = Ch;
               g = ui(a, Q(e, 60), [d.o, d.f]);
               S(b, g);
               g == Ch.o && (d = Dh, g = ui(a, Q(e, 66), [d.o, d.f]), S(b, g), d = Fh, g = ui(a, Q(e, 137), [d.o, d.f]), S(b, g), g == Dh.o && (d = Eh, g = ui(a, Q(e, 135), [d.o, d.f]), S(b, g)));
               d = yh;
               g = ui(a, Q(e, 98), [d.f, d.h]);
               S(b, g);
               d = zh;
               g = vi(a, Sh, Q(e, 173), Q(e, 174), [d.f, d.h]);
               S(b, g);
               c = Ah;
               g == d.f ? f = c.f : g == d.h ? f = c.h : f = "";
               S(b, f);
               d = Gh;
               g = vi(a, Rh, Q(e, 99), Q(e, 100), [d.f, d.h]);
               S(b, g);
               c = Hh;
               g == d.f ? f = c.f : g == d.h ? f = c.h : f = "";
               S(b, f);
               d = Ih;
               g = ui(a, Q(e, 165), [d.f, d.h]);
               S(b, g);
               d = R;
               g = vi(a, Uh, Q(e, 189), Q(e, 190), [d.f, d.T, d.K, d.J, d.H, d.I]);
               S(b, g);
               c = Jh;
               g == d.f ? f = c.f : g == d.T ? f = c.T : g == d.K ? f = c.K : g == d.J ? f = c.J : g == d.H ? f = c.H : g == d.I ? f = c.I : f = "";
               S(b, f);
               g = ui(a, Q(e, 185), ["20199337", "20199338"]);
               S(b, g);
               a = Od(a) || a;
               $g(a.location, "google_mc_lab") && S(b, "242104166")
          }
          if (!r("Trident") && !r("MSIE") || 0 <= hb(tb(), 11)) {
               a = J(C, Dh.o) || J(C, Bh.o) || J(C, Bh.oa);
               $e(a);
               Lj();
               Ij(".google.cn") && (Z[1] = ".google.cn");
               Nj();
               try {
                    if (C.PerformanceObserver && H(203)) {
                         var h = new hk;
                         h.Z.observe({
                              entryTypes: ["layout-shift", "largest-contentful-paint", "first-input"],
                              buffered: !0
                         });
                         document.addEventListener("visibilitychange", h.g)
                    }
               } catch (m) {}
               if (h = Od(n)) h = Lf(h), h.tagSpecificState[1] || (h.tagSpecificState[1] = new Zg);
               if (f = C.document.querySelector('script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])')) {
                    f.setAttribute("data-checked-head", "true");
                    a = I(window);
                    if (a.head_tag_slot_vars) throw new M("Only one AdSense head tag supported per page. The second tag is ignored.");
                    h = {};
                    ck(f, h);
                    uk(h);
                    f = {};
                    for (var l in h) f[l] = h[l];
                    a.head_tag_slot_vars = f;
                    l = {};
                    l = (l.google_ad_client = h.google_ad_client, l.enable_page_level_ads = h, l);
                    C.adsbygoogle || (C.adsbygoogle = []);
                    h = C.adsbygoogle;
                    h.loaded ? h.push(l) : h.splice(0, 0, l)
               }
               l = window.adsbygoogle;
               if (!l || !l.loaded) {
                    h = {
                         push: sk,
                         loaded: !0
                    };
                    try {
                         Object.defineProperty(h, "requestNonPersonalizedAds", {
                              set: Ak
                         }), Object.defineProperty(h, "pauseAdRequests", {
                              set: Bk
                         }), Object.defineProperty(h, "cookieOptions", {
                              set: Ck
                         }), Object.defineProperty(h, "onload", {
                              set: Dk
                         })
                    } catch (m) {}
                    if (l)
                         for (a = ba(["requestNonPersonalizedAds", "pauseAdRequests", "cookieOptions"]), f = a.next(); !f.done; f = a.next()) f = f.value, void 0 !== l[f] && (h[f] = l[f]);
                    "_gfp_a_" in window || (window._gfp_a_ = Zj);
                    if (l && l.shift) try {
                         var p;
                         for (a = 20; 0 < l.length && (p = l.shift()) && 0 < a;) sk(p), --a
                    } catch (m) {
                         throw window.setTimeout(yk, 0), m;
                    }
                    window.adsbygoogle = h;
                    l && (h.onload = l.onload)
               }
          }
     }

     function Ak(a) {
          if (+a) {
               if ((a = cc()) && a.frames && !a.frames.GoogleSetNPA) try {
                    var b = a.document,
                         c = new Xb(b),
                         d = b.body || b.head && b.head.parentElement;
                    if (d) {
                         var e = Wb(c.a, "IFRAME");
                         e.name = "GoogleSetNPA";
                         e.id = "GoogleSetNPA";
                         e.setAttribute("style", "display:none;position:fixed;left:-999px;top:-999px;width:0px;height:0px;");
                         d.appendChild(e)
                    }
               } catch (f) {}
          } else(b = cc().document.getElementById("GoogleSetNPA")) && b.parentNode && b.parentNode.removeChild(b)
     }

     function Bk(a) {
          +a ? I(C).pause_ad_requests = !0 : (I(C).pause_ad_requests = !1, a = function () {
               if (!I(C).pause_ad_requests) {
                    var b = Ld(),
                         c = Ld();
                    try {
                         if (Sb.createEvent) {
                              var d = Sb.createEvent("CustomEvent");
                              d.initCustomEvent("adsbygoogle-pub-unpause-ad-requests-event", !1, !1, "");
                              b.dispatchEvent(d)
                         } else if (Gd(c.CustomEvent)) {
                              var e = new c.CustomEvent("adsbygoogle-pub-unpause-ad-requests-event", {
                                   bubbles: !1,
                                   cancelable: !1,
                                   detail: ""
                              });
                              b.dispatchEvent(e)
                         } else if (Gd(c.Event)) {
                              var f = new Event("adsbygoogle-pub-unpause-ad-requests-event", {
                                   bubbles: !1,
                                   cancelable: !1
                              });
                              b.dispatchEvent(f)
                         }
                    } catch (g) {}
               }
          }, n.setTimeout(a, 0), n.setTimeout(a, 1E3))
     }

     function Ck(a) {
          switch (a) {
               case 0:
                    a = !0;
                    break;
               case 1:
                    a = !1;
                    break;
               case 2:
                    a = Zj;
                    break;
               default:
                    throw Error("Illegal value of cookieOptions: " + a);
          }
          C._gfp_a_ = a;
          "_gfp_p_" in C && (a = C.google_sv_map, bk(a[kc(a)].google_ad_client))
     }

     function Dk(a) {
          Gd(a) && window.setTimeout(a, 0)
     };
     yk();
}).call(this);