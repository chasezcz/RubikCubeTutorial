var _0xd590 = ["ok", "keydown", "addEventListener", "keyCode", "<table><tbody>", "html", "#langMessage", "<tr><td>", " &nbsp;&nbsp;&nbsp;</td><td>", "</td></tr>", "</tbody></table>", "#hiddenLanguageBits", "length", "#scrambler", "setInterval", "cube", "0111111111222222222333333333444444444555555555666666666", "<br />", "<a href=\"/", "\">", "</a>", "href", "attr", "solution.php?cube=", "each", ".selectlanguage a", "", "split", "generateTables", "postMessage", "%", "width", "#loadingBar", "random", "floor", "removeClass", "#currentRot", "playBack", "#playButton", "round", "orient", "U", "U'", "L", "L'", "F", "F'", "R", "R'", "B", 
"B'", "D", "D'", "U2", "L2", "F2", "R2", "B2", "D2", "innerHTML", "rotacioSzoveg", "getElementById", ".<span>", "</span>", "&nbsp;", "show", "#vigyazzKetszer", "hide", "active", "#algoritmusHanyadik", "addClass", "thisRotIs", "offsetHeight", "wrapSidebarItems", "fadeOut", "#sidebarStuff", "bw", "body", "<div class=\"greenWarning\"><h4>", "</h4><div id=\"wrapHowTo\"><div id=\"howTo\"><div id=\"frame1\"><p id=\"paragraph1\">", " AdBlock</p><a class=\"redOctagon\" id=\"handab\" href=\"#\" target=\"_blank\" rel=\"nofollow\"><div class=\"octagonOuter\"><div class=\"octagonInner\"></div><div class=\"stopHand\"><div class=\"pinkyF\"></div><div class=\"ringF\"></div><div class=\"middleF\"></div><div class=\"indexF\"></div><div class=\"thumbF\"></div><div class=\"palmF\"></div></div></div></a><div class=\"abDropdown\"><span>AdBlock</span><ul><li class=\"highlightedLi\">Don't run on this domain</li></ul></div><div class=\"mouseCursor\"><div class=\"mouse1\"></div><div class=\"mouse2\"></div><div class=\"mouse3\"></div><div class=\"mouse4\"></div></div><p id=\"paragraph2\"><a href=\"#\" target=\"_blank\" rel=\"nofollow\">Disable AdBlock.com</a></p></div></div></div><p>",
 "</p></div>", "segedvaltozo", "<div class='hanysztep'>", " ", ":</div> <span id='algoritmusHanyadik0' onclick='playingBackTheSolution = 0;eddigkiir(0);'> &raquo; </span>", "A", "e-so", "indexOf", "domain", "U&#39;", "L&#39;", "F&#39;", "R&#39;", "B&#39;", "D&#39;", " <span id='algoritmusHanyadik", "' onclick='playingBackTheSolution = 0;eddigkiir(", ");'>", "<span></span>", "#clearCube", "#resetCube", "#scrambleCube", "#solveCube", "placeholder", " (F R2 U')", "#scrambleAlg", "#callToLikeShare", "<span>&swarr;</span>", "#floatingTutorialAlert", "a#floatingTutorialAlert, a#tutorialLink", "title", "#mess28", "#mess29", "/", "a#mess11", "<div class=\"sbsStep\"><div class=\"sbsLabel\"><span class=\"sbsLabelID", ": </span>", "</div><div class=\"sbsKocka\">", "<div class=\"topFace field", " color", "</div>", "<div class=\"frontFace field", "<div class=\"rightFace field", "2x", "<div class=\"sbsRotArr sbsRot", "</div></div>", "stepByStep", "val", "#cube", "hiba", "<h2>", "</h2>", "fadeIn", "#hibaUzenet", "#pleasewait", "replace", "location", "preventDefault", "top", "offset", "animate", "html, body", "click", "a.scrollLink", "focusin", "focusout", "fadeToggle", ".selectlanguage", "#languageToggle", "#hiba", "#speedSlider", "#currentSpeedDisplay", "stop", " s/rot", " rot/s", "change", "#wrapPaletta", "data-color", "color", "#wrapCube > div > div > div", "#wrapPaletta a", "data-field", "class", "substr", "on", "#scrambler #wrapCube > div > div", "#", "data-arrow", "visible", "mouseover", "#cubeRotations a", "mouseleave", "color0", "#wrapCube > div > div", "transparent", "toggleClass", "#wrapCube", "#transparency", "cubeOrient13", "#floatingBacks", "floatingBacks", "#switchView a", "threeDView", "#wrapCubeSettings", "#tothreeDView", "flatView", "#toflatView", "rotateX(0deg) rotateY(0deg) rotateZ(0deg) translateX(0) translateY(0) translateZ(0)", "css", "kociembaView", "#tokociembaView", "#turnLeft", "#turnRight", "#turnUp", "#rotateF", "#rotateR", "#rotateU", "#rotateB", "#rotateL", "#rotateD", "#rotateFi", "#rotateRi", "#rotateUi", "#rotateBi", "#rotateLi", "#rotateDi", "#closeHibauzenet", "#prevButton", "#pauseButton", "#stopButton", "#nextButton", "#submitScrambleAlg", "#executeScrambleAlg", "which", "keyup", "ready", ":<br /> ", "(", ") &nbsp; ", ".<br />", " - ", "<br /> ", " (", ").", "solution.php?cube=0", "target", "_blank", "_self", "cubey", "cubeOrient", "cubez", "color1", "#wrapCube > div#face1 > div", "color2", "#wrapCube > div#face2 > div", "color3", "#wrapCube > div#face3 > div", "color4", "#wrapCube > div#face4 > div", "color5", "#wrapCube > div#face5 > div", "color6", "#wrapCube > div#face6 > div", "rotateX(", "deg) rotateY(", "deg) rotateZ(", "deg) translateX(0) translateY(0) translateZ(0)", "#inputScrambleError", "\u2019", "'", "toLowerCase", "2", "toUpperCase", "M", "E", "S", "X", "Y", "Z", "Error in position ", ": ", "<span id=\"compiledAlg", "#compiledScramble", "#scrambleAlg, #submitScrambleAlg, #executeScrambleAlg", "Add a scramble algorithm", "#compiledScramble span", "#compiledAlg", "charAt", "#sticker", "object", "Cube", "/RubikWorker.js", "move", "push", "face", "substring", "direction", "U1", "U3", "U4", "U5", "U6", "U7", "U8", "U9", "R1", "R3", "R4", "R5", "R6", "R7", "R8", "R9", "F1", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "D1", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "L1", "L3", "L4", "L5", "L6", "L7", "L8", "L9", "B1", "B3", "B4", "B5", "B6", "B7", "B8", "B9", "URF", "UFL", "ULB", "URB", "RFD", "FDL", "DLB", "RDB", "UR", "UF", "UL", "UB", "RD", "FD", "DL", "DB", "RF", "FL", "LB", "RB", "faceletToCubelet", "join", "colorIndexes", "sort", "call", "slice", "prototype", "cubeToArr", "autocompleteArray", "arrToCube", "autocompleteEdge", "autocompleteCorner", "_", "getAdjacentFacelets", "orderColors", "colors", "edges", "corners", "reverse", "arrayToMoveset", "movesetToArray", "text", "match", "reverseArray", "type", "data", "result", "message", "removeEventListener", "worker", "verify", "abs", "tablesGenerated", "First the tables need to be generated!", "solution", "Error", "solve", "progress", "line", "time", "CoordCube", "defineProperty", "toString", "FFFF00FFFFFFFF0000FF80400000FF00FF00", "&", "=", "shift", "true", "false", "#FFFF0F", "#1D16DB", "#F7A000", "#299E05", "#FFFFFF", "#EB0000", "#BBBBBB", "msg", "outerHTML", "bar", "Done in ", "ms", "disabled", "value", "cc", "Slice", ". <br />", "apply", "li", "createElement", " Completed, Took ", "appendChild", "details", "No solution in ", " moves", "No solution within ", " seconds", "This is unusual...", "Sorry but I couldn't find the optimal solution in 2 minutes.<br />Please make a few random moves on your cube and retry to solve it or use another computer.", "error", "moveset", "span", "className", "current move", "el", "#puzzleNav", "?", "hasOwnProperty", "state", "clean", "clear", "validateMoveset", "popstate", "checked", "autocomplete", "autocompleteCube", "backgroundColor", "style", "____U________R________F________D________L________B____", "center", "contains", "classList", "UUUUUUUUURRRRRRRRRFFFFFFFFFDDDDDDDDDLLLLLLLLLBBBBBBBBB", "currentColor", "y", "x", "z", "faceMoves", "from", "to", "colorNames", "stringify", "parse", "#FFFF00", "#008000", "#FF0000", "#0000FF", "#FFA500", "#808080", "Color", "HTMLEvents", "createEvent", "input", "initEvent", "dispatchEvent", "data-side", "getAttribute", "DOMContentLoaded", "hidden", "generate", "generateButton", "randomButton", "valueAsNumber", "maxmoves", "maxtime", "colorInput", "getElementsByClassName", "entry", "div", "side", "id", "5", "facelet center", "9", "facelet right", "facelet", "search", "mousemove", "clientX", "clientY", "#alertBox", "#alertShadow", "alertBoxContent", "<iframe src=\"/likebox.html\" width=\"300\" height=\"300\" scrolling=\"no\">Iframes not supported</iframe>", "callToAddThis2", "callToAddThis", "#alertBoxClose,#alertShadow"], activeView = 1, urlkocka, a = [], s = [], orig = [], center = [], kics = [], step = [], sbs = [], mess = [], activeColor = 0, listenToKeyboardRotations = 1;
cubeplaybackspeed = 3e3,
    playingBackTheSolution = 0,
    osszlepesszam = 0,
    i = 0,
    loadingPercent = 1,
    aktstep = 0,
    elozorot = 0,
    megprobalKirakniEnnyiLepesben = 20,
    facingFront = 3,
    facingUp = 1,
    error = _0xd590[0],
    cubex = -22,
    cubey = -38,
    cubez = 0,
    lastClickedFiled = 0,
    scrambler = 0,
    document[_0xd590[2]](_0xd590[1], keyDownTextField, !1);
function keyDownTextField(e) {
    1 == scrambler && 1 == listenToKeyboardRotations && (70 == e[_0xd590[3]] && (updateA(),
        ff(), updateCube()),
        82 == e[_0xd590[3]] && (updateA(), rr(), updateCube()),
        85 == e[_0xd590[3]] && (updateA(), uu(), updateCube()),
        66 == e[_0xd590[3]] && (updateA(), bb(), updateCube()),
        76 == e[_0xd590[3]] && (updateA(), ll(), updateCube()),
        68 == e[_0xd590[3]] && (updateA(), dd(), updateCube()),
        37 == e[_0xd590[3]] && turnLeft(),
        39 == e[_0xd590[3]] && turnRight())
}
function initVariables() {
    var e = _0xd590[4];
    for (i = 0; 40 >= i; i++)
        mess[i] = $(_0xd590[6] + i)[_0xd590[5]](),
            e = e + _0xd590[7] + i + _0xd590[8] + mess[i] + _0xd590[9];
    if (e += _0xd590[10],
        $(_0xd590[11])[_0xd590[5]](e),
        setLanguagePack(),
        0 != $(_0xd590[13])[_0xd590[12]])
        a[0] = 0,
            scrambler = 1,
            window[_0xd590[14]](function () {
                refreshSolveLink()
            }, 300);
    else if (urlkocka = getUrlVars()[_0xd590[15]],
        void 0 == urlkocka) {
        urlkocka = _0xd590[16];
        var x = mess[15] + _0xd590[17] + _0xd590[18] + mess[0] + _0xd590[19] + mess[11] + _0xd590[20];
        warning(mess[22], x)
    } else {
        for ($(_0xd590[25])[_0xd590[24]](function () {
            $(this)[_0xd590[22]](_0xd590[21], $(this)[_0xd590[22]](_0xd590[21]) + _0xd590[23] + urlkocka)
        }),
            a = urlkocka[_0xd590[27]](_0xd590[26]),
            i = 1; 54 >= i; i++)
            orig[i] = a[i];
        center[0] = 0,
            center[1] = a[5],
            center[2] = a[14],
            center[3] = a[23],
            center[4] = a[32],
            center[5] = a[41],
            center[6] = a[50],
            loadingPercentage(),
            updateCube();
        var c = 0;
        for (i = 1; 54 >= i; i++)
            c = a[i],
                c == center[1] && (a[i] = 1),
                c == center[2] && (a[i] = 2),
                c == center[3] && (a[i] = 3),
                c == center[4] && (a[i] = 4),
                c == center[5] && (a[i] = 5),
                c == center[6] && (a[i] = 6);
        worker[_0xd590[29]]({
            type: _0xd590[28]
        }),
            kociembaFieldsTransform()
    }
}
function loadingPercentage() {
    setTimeout(function () {
        loadingPercent++ ,
            99 > loadingPercent && loadingPercentage();
        $(_0xd590[32])[_0xd590[31]](loadingPercent + _0xd590[30]),
            $(_0xd590[32])[_0xd590[5]](loadingPercent + _0xd590[30])
    }, Math[_0xd590[34]](30 * Math[_0xd590[33]]()) + 10 * loadingPercent)
}
function rekurzivSolutionPlayback() {
    aktstep < osszlepesszam ? eddigkiir(aktstep + 1) : ($(_0xd590[36])[_0xd590[35]](),
        $(_0xd590[38])[_0xd590[35]](_0xd590[37]));
    setTimeout(function () {
        1 == playingBackTheSolution && rekurzivSolutionPlayback()
    }, Math[_0xd590[39]](cubeplaybackspeed))
}
function eddigkiir(e) {
    0 == playingBackTheSolution && $(_0xd590[38])[_0xd590[35]](_0xd590[37]),
        aktstep = e;
    var x = _0xd590[40];
    for (1 == step[e] && (x = _0xd590[41]),
        2 == step[e] && (x = _0xd590[42]),
        3 == step[e] && (x = _0xd590[43]),
        4 == step[e] && (x = _0xd590[44]),
        5 == step[e] && (x = _0xd590[45]),
        6 == step[e] && (x = _0xd590[46]),
        7 == step[e] && (x = _0xd590[47]),
        8 == step[e] && (x = _0xd590[48]),
        9 == step[e] && (x = _0xd590[49]),
        10 == step[e] && (x = _0xd590[50]),
        11 == step[e] && (x = _0xd590[51]),
        12 == step[e] && (x = _0xd590[52]),
        13 == step[e] && (x = _0xd590[53]),
        14 == step[e] && (x = _0xd590[54]),
        15 == step[e] && (x = _0xd590[55]),
        16 == step[e] && (x = _0xd590[56]),
        17 == step[e] && (x = _0xd590[57]),
        18 == step[e] && (x = _0xd590[58]),
        document[_0xd590[61]](_0xd590[60])[_0xd590[59]] = e + _0xd590[62] + x + _0xd590[63],
        0 == e && (document[_0xd590[61]](_0xd590[60])[_0xd590[59]] = _0xd590[64]),
        12 < step[e] ? 0 < e && $(_0xd590[66])[_0xd590[65]]() : $(_0xd590[66])[_0xd590[67]](),
        ($(_0xd590[69] + elozorot)[_0xd590[35]](_0xd590[68]),
            $(_0xd590[69] + e)[_0xd590[70]](_0xd590[68]),
            elozorot = e,
            step[0] = 0,
            i = 1); 54 >= i; i++)
        kics[i] = orig[i];
    for (ij = 0; ij <= e; ij++)
        1 == step[ij] && kicsiuu(),
            2 == step[ij] && kicsiui(),
            3 == step[ij] && kicsill(),
            4 == step[ij] && kicsili(),
            5 == step[ij] && kicsiff(),
            6 == step[ij] && kicsifi(),
            7 == step[ij] && kicsirr(),
            8 == step[ij] && kicsiri(),
            9 == step[ij] && kicsibb(),
            10 == step[ij] && kicsibi(),
            11 == step[ij] && kicsidd(),
            12 == step[ij] && kicsidi(),
            13 == step[ij] && (kicsiuu(),
                kicsiuu()),
            14 == step[ij] && (kicsill(),
                kicsill()),
            15 == step[ij] && (kicsiff(),
                kicsiff()),
            16 == step[ij] && (kicsirr(),
                kicsirr()),
            17 == step[ij] && (kicsibb(),
                kicsibb()),
            18 == step[ij] && (kicsidd(),
                kicsidd());
    for (i = 1; 54 >= i; i++)
        a[i] = kics[i];
    if ($(_0xd590[36])[_0xd590[35]](),
        $(_0xd590[36])[_0xd590[70]](_0xd590[71] + step[e]),
        1 == playingBackTheSolution)
        setTimeout(function () {
            for (updateCube(),
                i = 1; 54 >= i; i++)
                a[i] = orig[i]
        }, Math[_0xd590[39]](cubeplaybackspeed / 5)),
            setTimeout(function () {
                1 == playingBackTheSolution && ($(_0xd590[36])[_0xd590[35]](),
                    $(_0xd590[66])[_0xd590[67]]())
            }, Math[_0xd590[39]](4 * cubeplaybackspeed / 5));
    else
        for (updateCube(),
            i = 1; 54 >= i; i++)
            a[i] = orig[i]
}
function kiirarrayt() {
    setTimeout(function () {
        document[_0xd590[61]](_0xd590[73])[_0xd590[72]] ? $(_0xd590[75])[_0xd590[74]](500) : ($(_0xd590[77])[_0xd590[70]](_0xd590[76]),
            document[_0xd590[61]](_0xd590[73])[_0xd590[59]] = _0xd590[78] + mess[30] + _0xd590[79] + mess[27] + _0xd590[80] + mess[39] + _0xd590[81])
    }, 3e3),
        document[_0xd590[61]](_0xd590[82])[_0xd590[59]] = _0xd590[83] + stp + _0xd590[84] + mess[7] + _0xd590[85],
        osszlepesszam = stp;
    var e = _0xd590[86];
    for (i = 1; i <= stp; i++)
        -1 == (document[_0xd590[89]] + "")[_0xd590[88]](_0xd590[87]) && 16 > step[i] && ++step[i],
            1 == step[i] && (e = _0xd590[41]),
            2 == step[i] && (e = _0xd590[90]),
            3 == step[i] && (e = _0xd590[43]),
            4 == step[i] && (e = _0xd590[91]),
            5 == step[i] && (e = _0xd590[45]),
            6 == step[i] && (e = _0xd590[92]),
            7 == step[i] && (e = _0xd590[47]),
            8 == step[i] && (e = _0xd590[93]),
            9 == step[i] && (e = _0xd590[49]),
            10 == step[i] && (e = _0xd590[94]),
            11 == step[i] && (e = _0xd590[51]),
            12 == step[i] && (e = _0xd590[95]),
            13 == step[i] && (e = _0xd590[53]),
            14 == step[i] && (e = _0xd590[54]),
            15 == step[i] && (e = _0xd590[55]),
            16 == step[i] && (e = _0xd590[56]),
            17 == step[i] && (e = _0xd590[57]),
            18 == step[i] && (e = _0xd590[58]),
            document[_0xd590[61]](_0xd590[82])[_0xd590[59]] = document[_0xd590[61]](_0xd590[82])[_0xd590[59]] + _0xd590[96] + i + _0xd590[97] + i + _0xd590[98] + e + _0xd590[63];
    kiirStepByStep()
}
function kiirStepByStep() {
    for (var e, x = 1; 54 >= x; x++)
        sbs[x] = orig[x];
    kiirSbs(0, 0, mess[37]);
    for (var c = 1; c <= osszlepesszam; c++)
        1 == step[c] && (e = _0xd590[41]),
            2 == step[c] && (e = _0xd590[90]),
            3 == step[c] && (e = _0xd590[43]),
            4 == step[c] && (e = _0xd590[91]),
            5 == step[c] && (e = _0xd590[45]),
            6 == step[c] && (e = _0xd590[92]),
            7 == step[c] && (e = _0xd590[47]),
            8 == step[c] && (e = _0xd590[93]),
            9 == step[c] && (e = _0xd590[49]),
            10 == step[c] && (e = _0xd590[94]),
            11 == step[c] && (e = _0xd590[51]),
            12 == step[c] && (e = _0xd590[95]),
            13 == step[c] && (e = _0xd590[53]),
            14 == step[c] && (e = _0xd590[54]),
            15 == step[c] && (e = _0xd590[55]),
            16 == step[c] && (e = _0xd590[56]),
            17 == step[c] && (e = _0xd590[57]),
            18 == step[c] && (e = _0xd590[58]),
            kiirSbs(c, step[c], e),
            1 == step[c] && sbsuu(),
            2 == step[c] && sbsui(),
            3 == step[c] && sbsll(),
            4 == step[c] && sbsli(),
            5 == step[c] && sbsff(),
            6 == step[c] && sbsfi(),
            7 == step[c] && sbsrr(),
            8 == step[c] && sbsri(),
            9 == step[c] && sbsbb(),
            10 == step[c] && sbsbi(),
            11 == step[c] && sbsdd(),
            12 == step[c] && sbsdi(),
            13 == step[c] && (sbsuu(),
                sbsuu()),
            14 == step[c] && (sbsll(),
                sbsll()),
            15 == step[c] && (sbsff(),
                sbsff()),
            16 == step[c] && (sbsrr(),
                sbsrr()),
            17 == step[c] && (sbsbb(),
                sbsbb()),
            18 == step[c] && (sbsdd(),
                sbsdd());
    kiirSbs(0, 0, mess[38])
}
function setLanguagePack() {
    // $(_0xd590[100])[_0xd590[5]](mess[19] + _0xd590[99]),
    //     $(_0xd590[101])[_0xd590[5]](mess[20] + _0xd590[99]),
    //     $(_0xd590[102])[_0xd590[5]](mess[21] + _0xd590[99]),
    //     $(_0xd590[103])[_0xd590[5]](mess[16] + _0xd590[99]),
    //     $(_0xd590[106])[_0xd590[22]](_0xd590[104], mess[21] + _0xd590[105]),
    //     $(_0xd590[107])[_0xd590[5]](mess[23]),
    //     $(_0xd590[109])[_0xd590[5]](_0xd590[108] + mess[25]),
    //     $(_0xd590[110])[_0xd590[22]](_0xd590[21], mess[24]),
    //     $(_0xd590[110])[_0xd590[22]](_0xd590[111], mess[25]),
    //     $(_0xd590[112])[_0xd590[5]](mess[28]),
    //     $(_0xd590[113])[_0xd590[5]](mess[29]),
    //     0 < mess[0][_0xd590[12]] && ($(_0xd590[115])[_0xd590[22]](_0xd590[21], _0xd590[114] + mess[0] + _0xd590[114]),
    //         $(_0xd590[115])[_0xd590[5]](_0xd590[99] + mess[11]))
}
function kiirSbs(e, x, c) {
    var t, o, r = _0xd590[116] + e + _0xd590[19] + e + _0xd590[117] + c + _0xd590[118];
    for (t = 1; 9 >= t; t++)
        r = r + _0xd590[119] + t + _0xd590[120] + sbs[t] + _0xd590[19] + t + _0xd590[121];
    for (t = 19; 27 >= t; t++)
        r = r + _0xd590[122] + t + _0xd590[120] + sbs[t] + _0xd590[19] + t + _0xd590[121];
    for (t = 28; 36 >= t; t++)
        r = r + _0xd590[123] + t + _0xd590[120] + sbs[t] + _0xd590[19] + t + _0xd590[121];
    r += _0xd590[121],
        o = _0xd590[64],
        12 < x && (o = _0xd590[124]);
    r = r + _0xd590[125] + x + _0xd590[19] + o + _0xd590[126],
        document[_0xd590[61]](_0xd590[127])[_0xd590[59]] = document[_0xd590[61]](_0xd590[127])[_0xd590[59]] + r
}
function kociembaFieldsTransform() {
    var e = _0xd590[26]
        , c = []
        , t = []
        , o = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 37, 38, 39, 40, 41, 42, 43, 44, 45, 19, 20, 21, 22, 23, 24, 25, 26, 27, 10, 11, 12, 13, 14, 15, 16, 17, 18, 46, 47, 48, 49, 50, 51, 52, 53, 54, 28, 29, 30, 31, 32, 33, 34, 35, 36];
    for (kind = 1; 54 >= kind; kind++)
        c[kind] = 0,
            1 == a[kind] && (c[kind] = _0xd590[41]),
            2 == a[kind] && (c[kind] = _0xd590[43]),
            3 == a[kind] && (c[kind] = _0xd590[45]),
            4 == a[kind] && (c[kind] = _0xd590[47]),
            5 == a[kind] && (c[kind] = _0xd590[49]),
            6 == a[kind] && (c[kind] = _0xd590[51]);
    for (kind = 1; 54 >= kind; kind++)
        t[o[kind]] = c[kind];
    for (kind = 1; 54 >= kind; kind++)
        e += c[kind];
    for (e = _0xd590[26],
        kind = 1; 54 >= kind; kind++)
        e += t[kind];
    $(_0xd590[129])[_0xd590[128]](e)
}
function warning(e, x) {
    document[_0xd590[61]](_0xd590[130])[_0xd590[59]] = _0xd590[131] + e + _0xd590[132],
        document[_0xd590[61]](_0xd590[130])[_0xd590[59]] += x,
        $(_0xd590[134])[_0xd590[133]](300),
        $(_0xd590[135])[_0xd590[67]]()
}
function getUrlVars() {
    var e = {}
        , x = window[_0xd590[137]][_0xd590[21]][_0xd590[136]](/[?&]+([^=&]+)=([^&]*)/gi, function (c, t, o) {
            e[t] = o
        });
    return e
}
$(document)[_0xd590[216]](function () {
    $(_0xd590[144])[_0xd590[143]](function (e) {
        e[_0xd590[138]](),
            $(_0xd590[142])[_0xd590[141]]({
                scrollTop: $($(this)[_0xd590[22]](_0xd590[21]))[_0xd590[140]]()[_0xd590[139]] - 20
            }, 500)
    }),
        $(_0xd590[106])[_0xd590[145]](function () {
            listenToKeyboardRotations = 0
        }),
        $(_0xd590[106])[_0xd590[146]](function () {
            listenToKeyboardRotations = 1
        }),
        initVariables(),
        $(_0xd590[149])[_0xd590[143]](function () {
            $(_0xd590[148])[_0xd590[147]](220)
        }),
        $(_0xd590[103])[_0xd590[143]](function () {
            error != _0xd590[0] && ($(_0xd590[150])[_0xd590[5]](error),
                $(_0xd590[134])[_0xd590[133]](300))
        }),
        $(_0xd590[151])[_0xd590[156]](function () {
            cubeplaybackspeed = $(_0xd590[151])[_0xd590[128]](),
                $(_0xd590[152])[_0xd590[65]](),
                setTimeout(function () {
                    $(_0xd590[152])[_0xd590[153]]()[_0xd590[74]](300)
                }, 1e3),
                1e3 <= cubeplaybackspeed ? $(_0xd590[152])[_0xd590[5]](Math[_0xd590[39]](10 * (cubeplaybackspeed / 1e3)) / 10 + _0xd590[154]) : $(_0xd590[152])[_0xd590[5]](Math[_0xd590[39]](10 * (1e3 / cubeplaybackspeed)) / 10 + _0xd590[155])
        }),
        $(_0xd590[161])[_0xd590[143]](function () {
            $(_0xd590[157])[_0xd590[35]](),
                activeColor = $(this)[_0xd590[22]](_0xd590[158]),
                $(_0xd590[157])[_0xd590[70]](_0xd590[159] + activeColor),
                $(_0xd590[160])[_0xd590[35]](),
                $(_0xd590[160])[_0xd590[70]](_0xd590[159] + activeColor)
        }),
        $(_0xd590[166])[_0xd590[165]](_0xd590[143], function () {
            var e = $(this)[_0xd590[22]](_0xd590[162]);
            if (lastClickedFiled == e && (activeColor = 0,
                $(_0xd590[157])[_0xd590[35]](),
                $(_0xd590[157])[_0xd590[70]](_0xd590[159] + activeColor)),
                0 < activeColor)
                $(this)[_0xd590[35]](),
                    $(this)[_0xd590[70]](_0xd590[159] + activeColor);
            else {
                $(_0xd590[160])[_0xd590[35]]();
                var x = $(this)[_0xd590[22]](_0xd590[163])
                    , c = x[_0xd590[164]](x[_0xd590[12]] - 1);
                c = +c + 1,
                    6 < c && (c = 1),
                    $(this)[_0xd590[35]](),
                    $(this)[_0xd590[70]](_0xd590[159] + c)
            }
            lastClickedFiled = e
        }),
        $(_0xd590[171])[_0xd590[170]](function () {
            var x = _0xd590[167] + $(this)[_0xd590[22]](_0xd590[168]);
            $(x)[_0xd590[70]](_0xd590[169])
        }),
        $(_0xd590[171])[_0xd590[172]](function () {
            var x = _0xd590[167] + $(this)[_0xd590[22]](_0xd590[168]);
            $(x)[_0xd590[35]](_0xd590[169])
        }),
        $(_0xd590[100])[_0xd590[143]](function () {
            $(_0xd590[174])[_0xd590[24]](function () {
                $(this)[_0xd590[35]](),
                    $(this)[_0xd590[70]](_0xd590[173])
            })
        }),
        $(_0xd590[101])[_0xd590[143]](function () {
            resetCube()
        }),
        $(_0xd590[178])[_0xd590[143]](function () {
            $(_0xd590[177])[_0xd590[176]](_0xd590[175]),
                $(_0xd590[178])[_0xd590[176]](_0xd590[68])
        }),
        $(_0xd590[180])[_0xd590[143]](function () {
            $(_0xd590[13])[_0xd590[35]](),
                $(_0xd590[13])[_0xd590[70]](_0xd590[179]),
                facingFront = 3,
                facingUp = 1,
                $(_0xd590[180])[_0xd590[176]](_0xd590[68]),
                cubex = -22,
                cubey = -38,
                cubez = 0,
                rotCube(cubex, cubey, cubez),
                setTimeout(function () {
                    $(_0xd590[177])[_0xd590[176]](_0xd590[181])
                }, 200)
        }),
        $(_0xd590[185])[_0xd590[143]](function () {
            activeView = 1,
                $(_0xd590[13])[_0xd590[70]](_0xd590[179]),
                facingFront = 3,
                facingUp = 1,
                rotCube(cubex, cubey, cubez),
                $(_0xd590[182])[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[68]),
                $(_0xd590[177])[_0xd590[35]](),
                $(_0xd590[178])[_0xd590[35]](),
                $(_0xd590[180])[_0xd590[35]](),
                setTimeout(function () {
                    $(_0xd590[177])[_0xd590[70]](_0xd590[183])
                }, 400),
                setTimeout(function () {
                    $(_0xd590[184])[_0xd590[133]](300)
                }, 1e3)
        }),
        $(_0xd590[187])[_0xd590[143]](function () {
            activeView = 2,
                cubex = -22,
                cubey = -38,
                cubez = 0,
                rotCube(0, 0, 0),
                $(_0xd590[182])[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[68]),
                $(_0xd590[177])[_0xd590[35]](),
                $(_0xd590[178])[_0xd590[35]](),
                $(_0xd590[180])[_0xd590[35]](),
                setTimeout(function () {
                    $(_0xd590[177])[_0xd590[70]](_0xd590[186])
                }, 400),
                $(_0xd590[13])[_0xd590[35]](),
                $(_0xd590[184])[_0xd590[67]](0)
        }),
        $(_0xd590[191])[_0xd590[143]](function () {
            cubex = -22,
                cubey = -38,
                cubez = 0,
                rotCube(0, 0, 0),
                $(_0xd590[177])[_0xd590[189]]({
                    transform: _0xd590[188]
                }),
                $(_0xd590[182])[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[68]),
                $(_0xd590[177])[_0xd590[35]](),
                $(_0xd590[178])[_0xd590[35]](),
                $(_0xd590[180])[_0xd590[35]](),
                1 == activeView ? setTimeout(function () {
                    $(_0xd590[177])[_0xd590[70]](_0xd590[190])
                }, 400) : $(_0xd590[177])[_0xd590[70]](_0xd590[190]);
            activeView = 3,
                $(_0xd590[13])[_0xd590[35]](),
                $(_0xd590[184])[_0xd590[74]](300)
        }),
        $(_0xd590[192])[_0xd590[143]](function () {
            turnLeft()
        }),
        $(_0xd590[193])[_0xd590[143]](function () {
            turnRight()
        }),
        $(_0xd590[194])[_0xd590[143]](function () {
            flipCube()
        }),
        $(_0xd590[195])[_0xd590[143]](function () {
            updateA(),
                ff(),
                updateCube()
        }),
        $(_0xd590[196])[_0xd590[143]](function () {
            updateA(),
                rr(),
                updateCube()
        }),
        $(_0xd590[197])[_0xd590[143]](function () {
            updateA(),
                uu(),
                updateCube()
        }),
        $(_0xd590[198])[_0xd590[143]](function () {
            updateA(),
                bb(),
                updateCube()
        }),
        $(_0xd590[199])[_0xd590[143]](function () {
            updateA(),
                ll(),
                updateCube()
        }),
        $(_0xd590[200])[_0xd590[143]](function () {
            updateA(),
                dd(),
                updateCube()
        }),
        $(_0xd590[201])[_0xd590[143]](function () {
            updateA(),
                fi(),
                updateCube()
        }),
        $(_0xd590[202])[_0xd590[143]](function () {
            updateA(),
                ri(),
                updateCube()
        }),
        $(_0xd590[203])[_0xd590[143]](function () {
            updateA(),
                ui(),
                updateCube()
        }),
        $(_0xd590[204])[_0xd590[143]](function () {
            updateA(),
                bi(),
                updateCube()
        }),
        $(_0xd590[205])[_0xd590[143]](function () {
            updateA(),
                li(),
                updateCube()
        }),
        $(_0xd590[206])[_0xd590[143]](function () {
            updateA(),
                di(),
                updateCube()
        }),
        $(_0xd590[102])[_0xd590[143]](function () {
            resetCube(),
                updateA(),
                jumbleCube(),
                setTimeout(function () {
                    jumbleCube(),
                        updateCube()
                }, 300),
                setTimeout(function () {
                    jumbleCube(),
                        updateCube()
                }, 600),
                setTimeout(function () {
                    jumbleCube(),
                        updateCube()
                }, 900),
                updateCube()
        }),
        $(_0xd590[207])[_0xd590[143]](function () {
            $(_0xd590[134])[_0xd590[74]](200)
        }),
        $(_0xd590[208])[_0xd590[143]](function () {
            playingBackTheSolution = 0,
                $(_0xd590[38])[_0xd590[35]](_0xd590[37]),
                0 < aktstep && eddigkiir(aktstep - 1)
        }),
        $(_0xd590[209])[_0xd590[143]](function () {
            playingBackTheSolution = 0,
                $(_0xd590[38])[_0xd590[35]](_0xd590[37])
        }),
        $(_0xd590[38])[_0xd590[143]](function () {
            playingBackTheSolution = 1,
                $(_0xd590[38])[_0xd590[70]](_0xd590[37]),
                rekurzivSolutionPlayback()
        }),
        $(_0xd590[210])[_0xd590[143]](function () {
            playingBackTheSolution = 0,
                $(_0xd590[38])[_0xd590[35]](_0xd590[37]),
                aktstep = 0,
                eddigkiir(0)
        }),
        $(_0xd590[211])[_0xd590[143]](function () {
            playingBackTheSolution = 0,
                $(_0xd590[38])[_0xd590[35]](_0xd590[37]),
                aktstep < osszlepesszam && eddigkiir(aktstep + 1)
        }),
        $(_0xd590[212])[_0xd590[143]](function () {
            doInputScramble(800)
        }),
        $(_0xd590[213])[_0xd590[143]](function () {
            doInputScramble(0)
        }),
        $(_0xd590[106])[_0xd590[215]](function (e) {
            13 === e[_0xd590[214]] && doInputScramble(800)
        })
});
function refreshSolveLink() {
    updateA(),
        error = _0xd590[0];
    var e = 1;
    for (d = 1; 9 >= d; d++)
        (1 != a[d] || 2 != a[d + 9] || 3 != a[d + 18] || 4 != a[d + 27] || 5 != a[d + 36] || 6 != a[d + 45]) && (e = 0);
    1 == e && (error = mess[15]);
    var x = 0
        , c = 0
        , t = 0
        , o = 0
        , r = 0
        , l = 0;
    for (d = 1; 54 >= d; d++)
        1 == a[d] && x++ ,
            2 == a[d] && c++ ,
            3 == a[d] && t++ ,
            4 == a[d] && o++ ,
            5 == a[d] && r++ ,
            6 == a[d] && l++;
    (9 != x || 9 != c || 9 != t || 9 != o || 9 != r || 9 != l) && (error = mess[1] + _0xd590[217],
        9 != x && (error += mess[31] + _0xd590[218] + x + _0xd590[219]),
        9 != c && (error += mess[32] + _0xd590[218] + c + _0xd590[219]),
        9 != t && (error += mess[33] + _0xd590[218] + t + _0xd590[219]),
        9 != o && (error += mess[34] + _0xd590[218] + o + _0xd590[219]),
        9 != r && (error += mess[35] + _0xd590[218] + r + _0xd590[219]),
        9 != l && (error += mess[36] + _0xd590[218] + l + _0xd590[219]));
    for (x = 0,
        c = 0,
        t = 0,
        o = 0,
        r = 0,
        l = 0,
        d = 1; 9 >= d; d++)
        1 == a[9 * d - 4] && x++ ,
            2 == a[9 * d - 4] && c++ ,
            3 == a[9 * d - 4] && t++ ,
            4 == a[9 * d - 4] && o++ ,
            5 == a[9 * d - 4] && r++ ,
            6 == a[9 * d - 4] && l++;
    1 != x * c * t * o * r * l && (error = mess[18] + _0xd590[220],
        1 < x && (error += mess[31] + _0xd590[221] + x + _0xd590[222]),
        2 < c && (error += mess[32] + _0xd590[221] + c + _0xd590[222]),
        3 < t && (error += mess[33] + _0xd590[221] + t + _0xd590[222]),
        4 < o && (error += mess[34] + _0xd590[221] + o + _0xd590[222]),
        5 < r && (error += mess[35] + _0xd590[221] + r + _0xd590[222]),
        6 < l && (error += mess[36] + _0xd590[221] + l + _0xd590[222]));
    var e = 0;
    for (d = 1; 54 >= d; d++)
        0 == a[d] && e++;
    1 <= e && (error = mess[26] + _0xd590[223] + e + _0xd590[224]);
    var _ = window[_0xd590[137]][_0xd590[21]][_0xd590[136]](_0xd590[167], _0xd590[26]) + _0xd590[225];
    if (error == _0xd590[0]) {
        for (var d = 1; 55 > d; d++)
            _ += a[d];
        $(_0xd590[103])[_0xd590[22]](_0xd590[226], _0xd590[227])
    } else
        _ = _0xd590[167],
            $(_0xd590[103])[_0xd590[22]](_0xd590[226], _0xd590[228]);
    $(_0xd590[103])[_0xd590[22]](_0xd590[21], _)
}
function jumbleCube() {
    for (i = 0; 200 > i; i++) {
        var e = Math[_0xd590[34]](12 * Math[_0xd590[33]]());
        0 == e && (bor(),
            uu());
        1 == e && (fd(),
            ui());
        2 == e && ff();
        3 == e && fi();
        4 == e && dd();
        5 == e && di();
        6 == e && (bor(),
            bb());
        7 == e && (fd(),
            bi());
        8 == e && rr();
        9 == e && ri();
        10 == e && ll();
        11 == e && li()
    }
}
function turnRight() {
    rotal(_0xd590[229], 90),
        6 == facingUp ? (facingFront++ ,
            5 < facingFront && (facingFront = 2)) : (facingFront-- ,
                2 > facingFront && (facingFront = 5));
    $(_0xd590[13])[_0xd590[35]](),
        $(_0xd590[13])[_0xd590[70]](_0xd590[230] + facingUp + facingFront)
}
function turnLeft() {
    rotal(_0xd590[229], -90),
        1 == facingUp ? (facingFront++ ,
            5 < facingFront && (facingFront = 2)) : (facingFront-- ,
                2 > facingFront && (facingFront = 5));
    $(_0xd590[13])[_0xd590[35]](),
        $(_0xd590[13])[_0xd590[70]](_0xd590[230] + facingUp + facingFront)
}
function flipCube() {
    1 == facingUp ? rotal(_0xd590[231], -180) : rotal(_0xd590[231], 180);
    2 == facingFront ? facingFront = 4 : 3 == facingFront ? facingFront = 3 : 4 == facingFront ? facingFront = 2 : 5 == facingFront && (facingFront = 5);
    facingUp = 1 == facingUp ? 6 : 1;
    $(_0xd590[13])[_0xd590[35]](),
        $(_0xd590[13])[_0xd590[70]](_0xd590[230] + facingUp + facingFront)
}
function resetCube() {
    $(_0xd590[233])[_0xd590[24]](function () {
        $(this)[_0xd590[35]](),
            $(this)[_0xd590[70]](_0xd590[232])
    }),
        $(_0xd590[235])[_0xd590[24]](function () {
            $(this)[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[234])
        }),
        $(_0xd590[237])[_0xd590[24]](function () {
            $(this)[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[236])
        }),
        $(_0xd590[239])[_0xd590[24]](function () {
            $(this)[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[238])
        }),
        $(_0xd590[241])[_0xd590[24]](function () {
            $(this)[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[240])
        }),
        $(_0xd590[243])[_0xd590[24]](function () {
            $(this)[_0xd590[35]](),
                $(this)[_0xd590[70]](_0xd590[242])
        })
}
function rotCube(e, x, c) {
    segs = _0xd590[244] + e + _0xd590[245] + x + _0xd590[246] + c + _0xd590[247],
        $(_0xd590[177])[_0xd590[189]]({
            transform: segs
        })
}
function rotal(e, x) {
    window[e] += x,
        rotCube(cubex, cubey, cubez)
}
var turn = []
    , type = []
    , inputerror = 0;
function doInputScramble(e) {
    inputerror = 0;
    var x = $(_0xd590[106])[_0xd590[128]]()
        , c = _0xd590[26];
    turn = x[_0xd590[27]](_0xd590[84]),
        $(_0xd590[248])[_0xd590[5]](_0xd590[26]);
    for (var t = 0; t < turn[_0xd590[12]]; t++)
        if (type[t] = 0,
            -1 != turn[t][_0xd590[88]](_0xd590[249]) && (type[t] = 1),
            -1 != turn[t][_0xd590[88]](_0xd590[250]) && (type[t] = 1),
            turn[t] == turn[t][_0xd590[251]]() && (type[t] = 1),
            -1 != turn[t][_0xd590[88]](_0xd590[252]) && (type[t] = 2),
            (turn[t] = turn[t][_0xd590[253]](),
                -1 != turn[t][_0xd590[88]](_0xd590[41])))
            turn[t] = 1;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[43]))
            turn[t] = 3;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[45]))
            turn[t] = 5;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[47]))
            turn[t] = 7;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[49]))
            turn[t] = 9;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[51]))
            turn[t] = 11;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[254]))
            turn[t] = 13;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[255]))
            turn[t] = 15;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[256]))
            turn[t] = 17;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[257]))
            turn[t] = 19;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[258]))
            turn[t] = 21;
        else if (-1 != turn[t][_0xd590[88]](_0xd590[259]))
            turn[t] = 23;
        else {
            inputerror = 1,
                $(_0xd590[248])[_0xd590[5]](_0xd590[260] + (t + 1) + _0xd590[261] + turn[t]);
            break
        }
    if (0 == inputerror) {
        for (t = 0; t < turn[_0xd590[12]]; t++)
            c += _0xd590[262] + t + _0xd590[19],
                1 == turn[t] && (c += _0xd590[41]),
                3 == turn[t] && (c += _0xd590[43]),
                5 == turn[t] && (c += _0xd590[45]),
                7 == turn[t] && (c += _0xd590[47]),
                9 == turn[t] && (c += _0xd590[49]),
                11 == turn[t] && (c += _0xd590[51]),
                13 == turn[t] && (c += _0xd590[254]),
                15 == turn[t] && (c += _0xd590[255]),
                17 == turn[t] && (c += _0xd590[256]),
                19 == turn[t] && (c += _0xd590[257]),
                21 == turn[t] && (c += _0xd590[258]),
                23 == turn[t] && (c += _0xd590[259]),
                1 == type[t] && (c += _0xd590[250]),
                2 == type[t] && (c += _0xd590[252]),
                c += _0xd590[63];
        $(_0xd590[263])[_0xd590[5]](c),
            $(_0xd590[264])[_0xd590[67]](),
            executeInputScramble(0, e)
    }
    1 > x[_0xd590[12]] && $(_0xd590[248])[_0xd590[5]](_0xd590[265])
}
function executeInputScramble(e, x) {
    updateA(),
        $(_0xd590[266])[_0xd590[35]](_0xd590[68]),
        $(_0xd590[267] + e)[_0xd590[70]](_0xd590[68]);
    var c = 0;
    turn[_0xd590[12]] > e ? (c = turn[e],
        1 == type[e] && c++ ,
        1 == c && uu(),
        2 == c && ui(),
        3 == c && ll(),
        4 == c && li(),
        5 == c && ff(),
        6 == c && fi(),
        7 == c && rr(),
        8 == c && ri(),
        9 == c && bb(),
        10 == c && bi(),
        11 == c && dd(),
        12 == c && di(),
        13 == c && (li(),
            rr(),
            bor()),
        14 == c && (ll(),
            ri(),
            bor(),
            bor(),
            bor()),
        15 == c && (uu(),
            di(),
            fd(),
            fd(),
            fd()),
        16 == c && (ui(),
            dd(),
            fd()),
        17 == c && (fi(),
            bb(),
            fd(),
            bor(),
            fd(),
            fd(),
            fd()),
        18 == c && (ff(),
            bi(),
            bor(),
            fd(),
            fd(),
            fd(),
            bor(),
            fd(),
            fd()),
        19 == c && (bor(),
            bor(),
            bor()),
        20 == c && bor(),
        21 == c && fd(),
        22 == c && (fd(),
            fd(),
            fd()),
        23 == c && (fd(),
            bor(),
            fd(),
            fd(),
            fd()),
        24 == c && (fd(),
            fd(),
            fd(),
            bor(),
            fd()),
        setTimeout(function () {
            updateCube()
        }, x / 2),
        2 == type[e] ? type[e] = 0 : e++ ,
        setTimeout(function () {
            executeInputScramble(e, x)
        }, x)) : ($(_0xd590[263])[_0xd590[5]](_0xd590[26]),
            $(_0xd590[264])[_0xd590[65]]());
    updateCube()
}
function updateA() {
    for (i = 1; 55 > i; i++)
        a[i] = $(_0xd590[269] + i)[_0xd590[22]](_0xd590[163])[_0xd590[268]](5)
}
function updateCube() {
    for (i = 1; 55 > i; i++)
        $(_0xd590[269] + i)[_0xd590[35]](),
            $(_0xd590[269] + i)[_0xd590[70]](_0xd590[159] + a[i])
}
function bor() {
    s[1] = a[1],
        s[2] = a[4],
        s[3] = a[7],
        a[1] = a[45],
        a[4] = a[42],
        a[7] = a[39],
        a[45] = a[46],
        a[42] = a[49],
        a[39] = a[52],
        a[46] = a[19],
        a[49] = a[22],
        a[52] = a[25],
        a[19] = s[1],
        a[22] = s[2],
        a[25] = s[3],
        s[1] = a[2],
        s[2] = a[5],
        s[3] = a[8],
        a[2] = a[44],
        a[5] = a[41],
        a[8] = a[38],
        a[44] = a[47],
        a[41] = a[50],
        a[38] = a[53],
        a[47] = a[20],
        a[50] = a[23],
        a[53] = a[26],
        a[20] = s[1],
        a[23] = s[2],
        a[26] = s[3],
        s[1] = a[3],
        s[2] = a[6],
        s[3] = a[9],
        a[3] = a[43],
        a[6] = a[40],
        a[9] = a[37],
        a[43] = a[48],
        a[40] = a[51],
        a[37] = a[54],
        a[48] = a[21],
        a[51] = a[24],
        a[54] = a[27],
        a[21] = s[1],
        a[24] = s[2],
        a[27] = s[3],
        s[1] = a[10],
        s[2] = a[11],
        a[10] = a[16],
        a[11] = a[13],
        a[16] = a[18],
        a[13] = a[17],
        a[18] = a[12],
        a[17] = a[15],
        a[12] = s[1],
        a[15] = s[2],
        s[1] = a[28],
        s[2] = a[29],
        a[28] = a[30],
        a[29] = a[33],
        a[30] = a[36],
        a[33] = a[35],
        a[36] = a[34],
        a[35] = a[31],
        a[34] = s[1],
        a[31] = s[2]
}
function rot() {
    s[1] = a[25],
        s[2] = a[26],
        s[3] = a[27],
        a[25] = a[16],
        a[26] = a[17],
        a[27] = a[18],
        a[16] = a[43],
        a[17] = a[44],
        a[18] = a[45],
        a[43] = a[34],
        a[44] = a[35],
        a[45] = a[36],
        a[34] = s[1],
        a[35] = s[2],
        a[36] = s[3],
        s[1] = a[46],
        s[2] = a[47],
        a[46] = a[52],
        a[47] = a[49],
        a[52] = a[54],
        a[49] = a[53],
        a[54] = a[48],
        a[53] = a[51],
        a[48] = s[1],
        a[51] = s[2]
}
function roti() {
    s[1] = a[25],
        s[2] = a[26],
        s[3] = a[27],
        a[25] = a[34],
        a[26] = a[35],
        a[27] = a[36],
        a[34] = a[43],
        a[35] = a[44],
        a[36] = a[45],
        a[43] = a[16],
        a[44] = a[17],
        a[45] = a[18],
        a[16] = s[1],
        a[17] = s[2],
        a[18] = s[3],
        s[1] = a[46],
        s[2] = a[47],
        a[46] = a[48],
        a[47] = a[51],
        a[48] = a[54],
        a[51] = a[53],
        a[54] = a[52],
        a[53] = a[49],
        a[52] = s[1],
        a[49] = s[2]
}
function fd() {
    s[1] = a[19],
        s[2] = a[20],
        s[3] = a[21],
        a[19] = a[28],
        a[20] = a[29],
        a[21] = a[30],
        a[28] = a[37],
        a[29] = a[38],
        a[30] = a[39],
        a[37] = a[10],
        a[38] = a[11],
        a[39] = a[12],
        a[10] = s[1],
        a[11] = s[2],
        a[12] = s[3],
        s[1] = a[22],
        s[2] = a[23],
        s[3] = a[24],
        a[22] = a[31],
        a[23] = a[32],
        a[24] = a[33],
        a[31] = a[40],
        a[32] = a[41],
        a[33] = a[42],
        a[40] = a[13],
        a[41] = a[14],
        a[42] = a[15],
        a[13] = s[1],
        a[14] = s[2],
        a[15] = s[3],
        s[1] = a[25],
        s[2] = a[26],
        s[3] = a[27],
        a[25] = a[34],
        a[26] = a[35],
        a[27] = a[36],
        a[34] = a[43],
        a[35] = a[44],
        a[36] = a[45],
        a[43] = a[16],
        a[44] = a[17],
        a[45] = a[18],
        a[16] = s[1],
        a[17] = s[2],
        a[18] = s[3],
        s[1] = a[1],
        s[2] = a[2],
        a[1] = a[7],
        a[2] = a[4],
        a[7] = a[9],
        a[4] = a[8],
        a[9] = a[3],
        a[8] = a[6],
        a[3] = s[1],
        a[6] = s[2],
        s[1] = a[46],
        s[2] = a[47],
        a[46] = a[48],
        a[47] = a[51],
        a[48] = a[54],
        a[51] = a[53],
        a[54] = a[52],
        a[53] = a[49],
        a[52] = s[1],
        a[49] = s[2]
}
function uu() {
    bor(),
        bor(),
        rot(),
        bor(),
        bor()
}
function ui() {
    bor(),
        bor(),
        roti(),
        bor(),
        bor()
}
function ff() {
    bor(),
        rot(),
        bor(),
        bor(),
        bor()
}
function fi() {
    bor(),
        roti(),
        bor(),
        bor(),
        bor()
}
function rr() {
    fd(),
        bor(),
        rot(),
        bor(),
        bor(),
        bor(),
        fd(),
        fd(),
        fd()
}
function ri() {
    fd(),
        bor(),
        roti(),
        bor(),
        bor(),
        bor(),
        fd(),
        fd(),
        fd()
}
function ll() {
    fd(),
        fd(),
        fd(),
        bor(),
        rot(),
        bor(),
        bor(),
        bor(),
        fd()
}
function li() {
    fd(),
        fd(),
        fd(),
        bor(),
        roti(),
        bor(),
        bor(),
        bor(),
        fd()
}
function dd() {
    rot()
}
function di() {
    roti()
}
function bb() {
    bor(),
        bor(),
        bor(),
        rot(),
        bor()
}
function bi() {
    bor(),
        bor(),
        bor(),
        roti(),
        bor()
}
function kicsibor() {
    s[1] = kics[1],
        s[2] = kics[4],
        s[3] = kics[7],
        kics[1] = kics[45],
        kics[4] = kics[42],
        kics[7] = kics[39],
        kics[45] = kics[46],
        kics[42] = kics[49],
        kics[39] = kics[52],
        kics[46] = kics[19],
        kics[49] = kics[22],
        kics[52] = kics[25],
        kics[19] = s[1],
        kics[22] = s[2],
        kics[25] = s[3],
        s[1] = kics[2],
        s[2] = kics[5],
        s[3] = kics[8],
        kics[2] = kics[44],
        kics[5] = kics[41],
        kics[8] = kics[38],
        kics[44] = kics[47],
        kics[41] = kics[50],
        kics[38] = kics[53],
        kics[47] = kics[20],
        kics[50] = kics[23],
        kics[53] = kics[26],
        kics[20] = s[1],
        kics[23] = s[2],
        kics[26] = s[3],
        s[1] = kics[3],
        s[2] = kics[6],
        s[3] = kics[9],
        kics[3] = kics[43],
        kics[6] = kics[40],
        kics[9] = kics[37],
        kics[43] = kics[48],
        kics[40] = kics[51],
        kics[37] = kics[54],
        kics[48] = kics[21],
        kics[51] = kics[24],
        kics[54] = kics[27],
        kics[21] = s[1],
        kics[24] = s[2],
        kics[27] = s[3],
        s[1] = kics[10],
        s[2] = kics[11],
        kics[10] = kics[16],
        kics[11] = kics[13],
        kics[16] = kics[18],
        kics[13] = kics[17],
        kics[18] = kics[12],
        kics[17] = kics[15],
        kics[12] = s[1],
        kics[15] = s[2],
        s[1] = kics[28],
        s[2] = kics[29],
        kics[28] = kics[30],
        kics[29] = kics[33],
        kics[30] = kics[36],
        kics[33] = kics[35],
        kics[36] = kics[34],
        kics[35] = kics[31],
        kics[34] = s[1],
        kics[31] = s[2]
}
function kicsirot() {
    s[1] = kics[25],
        s[2] = kics[26],
        s[3] = kics[27],
        kics[25] = kics[16],
        kics[26] = kics[17],
        kics[27] = kics[18],
        kics[16] = kics[43],
        kics[17] = kics[44],
        kics[18] = kics[45],
        kics[43] = kics[34],
        kics[44] = kics[35],
        kics[45] = kics[36],
        kics[34] = s[1],
        kics[35] = s[2],
        kics[36] = s[3],
        s[1] = kics[46],
        s[2] = kics[47],
        kics[46] = kics[52],
        kics[47] = kics[49],
        kics[52] = kics[54],
        kics[49] = kics[53],
        kics[54] = kics[48],
        kics[53] = kics[51],
        kics[48] = s[1],
        kics[51] = s[2]
}
function kicsiroti() {
    s[1] = kics[25],
        s[2] = kics[26],
        s[3] = kics[27],
        kics[25] = kics[34],
        kics[26] = kics[35],
        kics[27] = kics[36],
        kics[34] = kics[43],
        kics[35] = kics[44],
        kics[36] = kics[45],
        kics[43] = kics[16],
        kics[44] = kics[17],
        kics[45] = kics[18],
        kics[16] = s[1],
        kics[17] = s[2],
        kics[18] = s[3],
        s[1] = kics[46],
        s[2] = kics[47],
        kics[46] = kics[48],
        kics[47] = kics[51],
        kics[48] = kics[54],
        kics[51] = kics[53],
        kics[54] = kics[52],
        kics[53] = kics[49],
        kics[52] = s[1],
        kics[49] = s[2]
}
function kicsifd() {
    s[1] = kics[19],
        s[2] = kics[20],
        s[3] = kics[21],
        kics[19] = kics[28],
        kics[20] = kics[29],
        kics[21] = kics[30],
        kics[28] = kics[37],
        kics[29] = kics[38],
        kics[30] = kics[39],
        kics[37] = kics[10],
        kics[38] = kics[11],
        kics[39] = kics[12],
        kics[10] = s[1],
        kics[11] = s[2],
        kics[12] = s[3],
        s[1] = kics[22],
        s[2] = kics[23],
        s[3] = kics[24],
        kics[22] = kics[31],
        kics[23] = kics[32],
        kics[24] = kics[33],
        kics[31] = kics[40],
        kics[32] = kics[41],
        kics[33] = kics[42],
        kics[40] = kics[13],
        kics[41] = kics[14],
        kics[42] = kics[15],
        kics[13] = s[1],
        kics[14] = s[2],
        kics[15] = s[3],
        s[1] = kics[25],
        s[2] = kics[26],
        s[3] = kics[27],
        kics[25] = kics[34],
        kics[26] = kics[35],
        kics[27] = kics[36],
        kics[34] = kics[43],
        kics[35] = kics[44],
        kics[36] = kics[45],
        kics[43] = kics[16],
        kics[44] = kics[17],
        kics[45] = kics[18],
        kics[16] = s[1],
        kics[17] = s[2],
        kics[18] = s[3],
        s[1] = kics[1],
        s[2] = kics[2],
        kics[1] = kics[7],
        kics[2] = kics[4],
        kics[7] = kics[9],
        kics[4] = kics[8],
        kics[9] = kics[3],
        kics[8] = kics[6],
        kics[3] = s[1],
        kics[6] = s[2],
        s[1] = kics[46],
        s[2] = kics[47],
        kics[46] = kics[48],
        kics[47] = kics[51],
        kics[48] = kics[54],
        kics[51] = kics[53],
        kics[54] = kics[52],
        kics[53] = kics[49],
        kics[52] = s[1],
        kics[49] = s[2]
}
function kicsiuu() {
    kicsibor(),
        kicsibor(),
        kicsirot(),
        kicsibor(),
        kicsibor()
}
function kicsiui() {
    kicsibor(),
        kicsibor(),
        kicsiroti(),
        kicsibor(),
        kicsibor()
}
function kicsiff() {
    kicsibor(),
        kicsirot(),
        kicsibor(),
        kicsibor(),
        kicsibor()
}
function kicsifi() {
    kicsibor(),
        kicsiroti(),
        kicsibor(),
        kicsibor(),
        kicsibor()
}
function kicsirr() {
    kicsifd(),
        kicsibor(),
        kicsirot(),
        kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsifd(),
        kicsifd(),
        kicsifd()
}
function kicsiri() {
    kicsifd(),
        kicsibor(),
        kicsiroti(),
        kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsifd(),
        kicsifd(),
        kicsifd()
}
function kicsill() {
    kicsifd(),
        kicsifd(),
        kicsifd(),
        kicsibor(),
        kicsirot(),
        kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsifd()
}
function kicsili() {
    kicsifd(),
        kicsifd(),
        kicsifd(),
        kicsibor(),
        kicsiroti(),
        kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsifd()
}
function kicsidd() {
    kicsirot()
}
function kicsidi() {
    kicsiroti()
}
function kicsibb() {
    kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsirot(),
        kicsibor(),
        stp++ ,
        step[stp] = 9
}
function kicsibi() {
    kicsibor(),
        kicsibor(),
        kicsibor(),
        kicsiroti(),
        kicsibor(),
        stp++ ,
        step[stp] = 10
}
function sbsbor() {
    s[1] = sbs[1],
        s[2] = sbs[4],
        s[3] = sbs[7],
        sbs[1] = sbs[45],
        sbs[4] = sbs[42],
        sbs[7] = sbs[39],
        sbs[45] = sbs[46],
        sbs[42] = sbs[49],
        sbs[39] = sbs[52],
        sbs[46] = sbs[19],
        sbs[49] = sbs[22],
        sbs[52] = sbs[25],
        sbs[19] = s[1],
        sbs[22] = s[2],
        sbs[25] = s[3],
        s[1] = sbs[2],
        s[2] = sbs[5],
        s[3] = sbs[8],
        sbs[2] = sbs[44],
        sbs[5] = sbs[41],
        sbs[8] = sbs[38],
        sbs[44] = sbs[47],
        sbs[41] = sbs[50],
        sbs[38] = sbs[53],
        sbs[47] = sbs[20],
        sbs[50] = sbs[23],
        sbs[53] = sbs[26],
        sbs[20] = s[1],
        sbs[23] = s[2],
        sbs[26] = s[3],
        s[1] = sbs[3],
        s[2] = sbs[6],
        s[3] = sbs[9],
        sbs[3] = sbs[43],
        sbs[6] = sbs[40],
        sbs[9] = sbs[37],
        sbs[43] = sbs[48],
        sbs[40] = sbs[51],
        sbs[37] = sbs[54],
        sbs[48] = sbs[21],
        sbs[51] = sbs[24],
        sbs[54] = sbs[27],
        sbs[21] = s[1],
        sbs[24] = s[2],
        sbs[27] = s[3],
        s[1] = sbs[10],
        s[2] = sbs[11],
        sbs[10] = sbs[16],
        sbs[11] = sbs[13],
        sbs[16] = sbs[18],
        sbs[13] = sbs[17],
        sbs[18] = sbs[12],
        sbs[17] = sbs[15],
        sbs[12] = s[1],
        sbs[15] = s[2],
        s[1] = sbs[28],
        s[2] = sbs[29],
        sbs[28] = sbs[30],
        sbs[29] = sbs[33],
        sbs[30] = sbs[36],
        sbs[33] = sbs[35],
        sbs[36] = sbs[34],
        sbs[35] = sbs[31],
        sbs[34] = s[1],
        sbs[31] = s[2]
}
function sbsrot() {
    s[1] = sbs[25],
        s[2] = sbs[26],
        s[3] = sbs[27],
        sbs[25] = sbs[16],
        sbs[26] = sbs[17],
        sbs[27] = sbs[18],
        sbs[16] = sbs[43],
        sbs[17] = sbs[44],
        sbs[18] = sbs[45],
        sbs[43] = sbs[34],
        sbs[44] = sbs[35],
        sbs[45] = sbs[36],
        sbs[34] = s[1],
        sbs[35] = s[2],
        sbs[36] = s[3],
        s[1] = sbs[46],
        s[2] = sbs[47],
        sbs[46] = sbs[52],
        sbs[47] = sbs[49],
        sbs[52] = sbs[54],
        sbs[49] = sbs[53],
        sbs[54] = sbs[48],
        sbs[53] = sbs[51],
        sbs[48] = s[1],
        sbs[51] = s[2]
}
function sbsroti() {
    s[1] = sbs[25],
        s[2] = sbs[26],
        s[3] = sbs[27],
        sbs[25] = sbs[34],
        sbs[26] = sbs[35],
        sbs[27] = sbs[36],
        sbs[34] = sbs[43],
        sbs[35] = sbs[44],
        sbs[36] = sbs[45],
        sbs[43] = sbs[16],
        sbs[44] = sbs[17],
        sbs[45] = sbs[18],
        sbs[16] = s[1],
        sbs[17] = s[2],
        sbs[18] = s[3],
        s[1] = sbs[46],
        s[2] = sbs[47],
        sbs[46] = sbs[48],
        sbs[47] = sbs[51],
        sbs[48] = sbs[54],
        sbs[51] = sbs[53],
        sbs[54] = sbs[52],
        sbs[53] = sbs[49],
        sbs[52] = s[1],
        sbs[49] = s[2]
}
function sbsfd() {
    s[1] = sbs[19],
        s[2] = sbs[20],
        s[3] = sbs[21],
        sbs[19] = sbs[28],
        sbs[20] = sbs[29],
        sbs[21] = sbs[30],
        sbs[28] = sbs[37],
        sbs[29] = sbs[38],
        sbs[30] = sbs[39],
        sbs[37] = sbs[10],
        sbs[38] = sbs[11],
        sbs[39] = sbs[12],
        sbs[10] = s[1],
        sbs[11] = s[2],
        sbs[12] = s[3],
        s[1] = sbs[22],
        s[2] = sbs[23],
        s[3] = sbs[24],
        sbs[22] = sbs[31],
        sbs[23] = sbs[32],
        sbs[24] = sbs[33],
        sbs[31] = sbs[40],
        sbs[32] = sbs[41],
        sbs[33] = sbs[42],
        sbs[40] = sbs[13],
        sbs[41] = sbs[14],
        sbs[42] = sbs[15],
        sbs[13] = s[1],
        sbs[14] = s[2],
        sbs[15] = s[3],
        s[1] = sbs[25],
        s[2] = sbs[26],
        s[3] = sbs[27],
        sbs[25] = sbs[34],
        sbs[26] = sbs[35],
        sbs[27] = sbs[36],
        sbs[34] = sbs[43],
        sbs[35] = sbs[44],
        sbs[36] = sbs[45],
        sbs[43] = sbs[16],
        sbs[44] = sbs[17],
        sbs[45] = sbs[18],
        sbs[16] = s[1],
        sbs[17] = s[2],
        sbs[18] = s[3],
        s[1] = sbs[1],
        s[2] = sbs[2],
        sbs[1] = sbs[7],
        sbs[2] = sbs[4],
        sbs[7] = sbs[9],
        sbs[4] = sbs[8],
        sbs[9] = sbs[3],
        sbs[8] = sbs[6],
        sbs[3] = s[1],
        sbs[6] = s[2],
        s[1] = sbs[46],
        s[2] = sbs[47],
        sbs[46] = sbs[48],
        sbs[47] = sbs[51],
        sbs[48] = sbs[54],
        sbs[51] = sbs[53],
        sbs[54] = sbs[52],
        sbs[53] = sbs[49],
        sbs[52] = s[1],
        sbs[49] = s[2]
}
function sbsuu() {
    sbsbor(),
        sbsbor(),
        sbsrot(),
        sbsbor(),
        sbsbor()
}
function sbsui() {
    sbsbor(),
        sbsbor(),
        sbsroti(),
        sbsbor(),
        sbsbor()
}
function sbsff() {
    sbsbor(),
        sbsrot(),
        sbsbor(),
        sbsbor(),
        sbsbor()
}
function sbsfi() {
    sbsbor(),
        sbsroti(),
        sbsbor(),
        sbsbor(),
        sbsbor()
}
function sbsrr() {
    sbsfd(),
        sbsbor(),
        sbsrot(),
        sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsfd(),
        sbsfd(),
        sbsfd()
}
function sbsri() {
    sbsfd(),
        sbsbor(),
        sbsroti(),
        sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsfd(),
        sbsfd(),
        sbsfd()
}
function sbsll() {
    sbsfd(),
        sbsfd(),
        sbsfd(),
        sbsbor(),
        sbsrot(),
        sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsfd()
}
function sbsli() {
    sbsfd(),
        sbsfd(),
        sbsfd(),
        sbsbor(),
        sbsroti(),
        sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsfd()
}
function sbsdd() {
    sbsrot()
}
function sbsdi() {
    sbsroti()
}
function sbsbb() {
    sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsrot(),
        sbsbor(),
        stp++ ,
        step[stp] = 9
}
function sbsbi() {
    sbsbor(),
        sbsbor(),
        sbsbor(),
        sbsroti(),
        sbsbor(),
        stp++ ,
        step[stp] = 10
}
typeof Cube == _0xd590[270] || function () {
    window[_0xd590[271]] = {
        worker: new Worker(_0xd590[272]),
        tablesGenerated: !1,
        movesetToArray: function (e) {
            for (var x = e[_0xd590[27]](_0xd590[84]), c = [], t = 0; t < x[_0xd590[12]]; t++)
                c[_0xd590[274]](new Cube[_0xd590[273]](x[t]));
            return c
        },
        move: function (x) {
            this[_0xd590[275]] = x[_0xd590[276]](0, 1) || _0xd590[41];
            var c = x[_0xd590[276]](1, 2);
            c == _0xd590[26] ? (this[_0xd590[273]] = 1,
                this[_0xd590[277]] = 1) : c == _0xd590[250] ? (this[_0xd590[273]] = 1,
                    this[_0xd590[277]] = -1) : c == _0xd590[252] ? (this[_0xd590[273]] = 2,
                        this[_0xd590[277]] = 0) : (this[_0xd590[273]] = 1,
                            this[_0xd590[277]] = 1)
        },
        colors: [_0xd590[41], _0xd590[47], _0xd590[45], _0xd590[51], _0xd590[43], _0xd590[49]],
        facelets: [_0xd590[278], _0xd590[53], _0xd590[279], _0xd590[280], _0xd590[281], _0xd590[282], _0xd590[283], _0xd590[284], _0xd590[285], _0xd590[286], _0xd590[56], _0xd590[287], _0xd590[288], _0xd590[289], _0xd590[290], _0xd590[291], _0xd590[292], _0xd590[293], _0xd590[294], _0xd590[55], _0xd590[295], _0xd590[296], _0xd590[297], _0xd590[298], _0xd590[299], _0xd590[300], _0xd590[301], _0xd590[302], _0xd590[58], _0xd590[303], _0xd590[304], _0xd590[305], _0xd590[306], _0xd590[307], _0xd590[308], _0xd590[309], _0xd590[310], _0xd590[54], _0xd590[311], _0xd590[312], _0xd590[313], _0xd590[314], _0xd590[315], _0xd590[316], _0xd590[317], _0xd590[318], _0xd590[57], _0xd590[319], _0xd590[320], _0xd590[321], _0xd590[322], _0xd590[323], _0xd590[324], _0xd590[325]],
        corners: [_0xd590[326], _0xd590[327], _0xd590[328], _0xd590[329], _0xd590[330], _0xd590[331], _0xd590[332], _0xd590[333]],
        edges: [_0xd590[334], _0xd590[335], _0xd590[336], _0xd590[337], _0xd590[338], _0xd590[339], _0xd590[340], _0xd590[341], _0xd590[342], _0xd590[343], _0xd590[344], _0xd590[345]],
        colorIndexes: {
            U: 0,
            R: 1,
            F: 2,
            D: 3,
            L: 4,
            B: 5
        },
        cubeToArr: function (e) {
            for (var x = [], c = 0; 6 > c; c++) {
                x[c] = [];
                for (var t = 0; 3 > t; t++) {
                    x[c][t] = [];
                    for (var o = 0; 3 > o; o++)
                        x[c][t][o] = e[_0xd590[268]](9 * c + 3 * t + o)
                }
            }
            return x
        },
        arrToCube: function (e) {
            for (var x = _0xd590[26], c = 0; 6 > c; c++)
                for (var t = 0; 3 > t; t++)
                    for (var o = 0; 3 > o; o++)
                        x += e[c][t][o];
            return x
        },
        getAdjacentFacelets: function (e, x, c) {
            for (var t = Cube[_0xd590[346]][e][x][c], o = [], r = 0; 6 > r; r++)
                for (var l = 0; 3 > l; l++)
                    for (var _ = 0; 3 > _; _++)
                        (r != e || l != x || _ != c) && Cube[_0xd590[346]][r][l][_] == t && o[_0xd590[274]]([r, l, _]);
            return o
        },
        faceletToCubelet: [[[0, 1, 2], [3, 4, 5], [6, 7, 8]], [[8, 5, 2], [17, 14, 11], [26, 23, 20]], [[6, 7, 8], [15, 16, 17], [24, 25, 26]], [[24, 25, 26], [21, 22, 23], [18, 19, 20]], [[0, 3, 6], [9, 12, 15], [18, 21, 24]], [[2, 1, 0], [11, 10, 9], [20, 19, 18]]],
        orderColors: function () {
            return Array[_0xd590[352]][_0xd590[351]][_0xd590[350]](arguments)[_0xd590[349]](function (e, x) {
                if (Cube[_0xd590[348]][e] < Cube[_0xd590[348]][x])
                    return -1;
                return Cube[_0xd590[348]][e] > Cube[_0xd590[348]][x] ? 1 : 0
            })[_0xd590[347]](_0xd590[26])
        },
        autocompleteCube: function (e) {
            return Cube[_0xd590[355]](Cube[_0xd590[354]](Cube[_0xd590[353]](e)))
        },
        autocompleteArray: function (e) {
            var x = e[_0xd590[351]](), c;
            do
                c = x[_0xd590[351]](),
                    x = Cube[_0xd590[356]](x);
            while (Cube[_0xd590[355]](x) != Cube[_0xd590[355]](c)); do
                c = x[_0xd590[351]](),
                    x = Cube[_0xd590[357]](x);
            while (Cube[_0xd590[355]](x) != Cube[_0xd590[355]](c)); return x
        },
        autocompleteEdge: function (e) {
            for (var x = e[_0xd590[351]](), c = [], t = 0; 6 > t; t++)
                for (var o = 0; 3 > o; o++)
                    for (var l, r = 1 - o % 2; 3 > r; r += 2)
                        if (l = x[t][o][r],
                            l != _0xd590[358]) {
                            var _ = Cube[_0xd590[359]](t, o, r)[0]
                                , d = x[_[0]][_[1]][_[2]];
                            if (d != _0xd590[358]) {
                                var n = Cube[_0xd590[360]](l, d);
                                -1 == c[_0xd590[88]](n) && c[_0xd590[274]](n)
                            }
                        }
            for (var t = 0; 6 > t; t++)
                for (var o = 0; 3 > o; o++)
                    for (var l, r = 1 - o % 2; 3 > r; r += 2)
                        if (l = x[t][o][r],
                            l == _0xd590[358]) {
                            var _ = Cube[_0xd590[359]](t, o, r)[0]
                                , d = x[_[0]][_[1]][_[2]]
                                , n = Cube[_0xd590[360]](l, d);
                            if (d != _0xd590[358]) {
                                for (var u = [], p = 0; p < Cube[_0xd590[361]][_0xd590[12]]; p++) {
                                    var v = Cube[_0xd590[361]][p]
                                        , n = Cube[_0xd590[360]](d, v);
                                    -1 != Cube[_0xd590[362]][_0xd590[88]](n) && -1 == c[_0xd590[88]](n) && u[_0xd590[274]](v)
                                }
                                1 == u[_0xd590[12]] && (x[t][o][r] = u[0])
                            }
                        }
            return x
        },
        autocompleteCorner: function (e) {
            for (var x = e[_0xd590[351]](), c = [], t = 0; 6 > t; t++)
                for (var o = 0; 3 > o; o += 2)
                    for (var l, r = 0; 3 > r; r += 2)
                        if (l = x[t][o][r],
                            l != _0xd590[358]) {
                            var _ = Cube[_0xd590[359]](t, o, r)
                                , d = x[_[0][0]][_[0][1]][_[0][2]]
                                , n = x[_[1][0]][_[1][1]][_[1][2]];
                            if (d != _0xd590[358] && n != _0xd590[358]) {
                                var u = Cube[_0xd590[360]](l, d, n);
                                -1 == c[_0xd590[88]](u) && c[_0xd590[274]](u)
                            }
                        }
            for (var t = 0; 6 > t; t++)
                for (var o = 0; 3 > o; o += 2)
                    for (var l, r = 0; 3 > r; r += 2)
                        if (l = x[t][o][r],
                            l == _0xd590[358]) {
                            var _ = Cube[_0xd590[359]](t, o, r)
                                , d = x[_[0][0]][_[0][1]][_[0][2]]
                                , n = x[_[1][0]][_[1][1]][_[1][2]]
                                , u = Cube[_0xd590[360]](l, d, n);
                            if (d != _0xd590[358] && n != _0xd590[358]) {
                                for (var p = [], v = 0; v < Cube[_0xd590[361]][_0xd590[12]]; v++) {
                                    var b = Cube[_0xd590[361]][v]
                                        , u = Cube[_0xd590[360]](d, n, b);
                                    -1 != Cube[_0xd590[363]][_0xd590[88]](u) && -1 == c[_0xd590[88]](u) && p[_0xd590[274]](b)
                                }
                                1 == p[_0xd590[12]] && (x[t][o][r] = p[0])
                            }
                        }
            return x
        },
        reverseArray: function (e) {
            for (var x = Cube[_0xd590[366]](Cube[_0xd590[365]](e))[_0xd590[364]](), c = 0; c < x[_0xd590[12]]; c++)
                x[c][_0xd590[277]] = -1 * x[c][_0xd590[277]];
            return x
        },
        arrayToMoveset: function (e, x) {
            for (var o, c = _0xd590[26], t = 0; t < e[_0xd590[12]]; t++)
                o = e[t],
                    c += o[_0xd590[367]],
                    t != e[_0xd590[12]] - 1 && (c += x ? _0xd590[358] : _0xd590[84]);
            return c
        },
        validateMoveset: function (e) {
            return !!e[_0xd590[368]](/^([ULFRBD](['2]|))( ([ULFRBD](['2]|)))*$/)
        },
        reverseMoveset: function (e) {
            return Cube[_0xd590[365]](Cube[_0xd590[369]](Cube[_0xd590[366]](e)))
        },
        randomCube: function (e) {
            var x = function (c) {
                c[_0xd590[371]][_0xd590[370]] == _0xd590[33] && (e(c[_0xd590[371]][_0xd590[372]]),
                    Cube[_0xd590[375]][_0xd590[374]](_0xd590[373], x, !1))
            };
            Cube[_0xd590[375]][_0xd590[2]](_0xd590[373], x, !1),
                Cube[_0xd590[375]][_0xd590[29]]({
                    type: _0xd590[33]
                })
        },
        verifyCube: function (e, x) {
            var c = function (t) {
                t[_0xd590[371]][_0xd590[370]] == _0xd590[376] && t[_0xd590[371]][_0xd590[15]] == e && (x(Math[_0xd590[377]](t[_0xd590[371]][_0xd590[372]])),
                    Cube[_0xd590[375]][_0xd590[374]](_0xd590[373], c, !1))
            };
            Cube[_0xd590[375]][_0xd590[2]](_0xd590[373], c, !1),
                Cube[_0xd590[375]][_0xd590[29]]({
                    type: _0xd590[376],
                    cube: e
                })
        },
        solveCube: function (e, x, c, t, o, r, l) {
            if (!Cube[_0xd590[378]])
                throw new Error(_0xd590[379]);
            var _ = function (n) {
                if (n[_0xd590[371]][_0xd590[370]] == _0xd590[380] && n[_0xd590[371]][_0xd590[15]] == e) {
                    if (0 == n[_0xd590[371]][_0xd590[372]][_0xd590[88]](_0xd590[381]) && errorCallback)
                        errorCallback(parseInt(n[_0xd590[371]][_0xd590[372]][_0xd590[276]](6, 7)));
                    else {
                        var u = n[_0xd590[371]][_0xd590[372]][_0xd590[276]](0, n[_0xd590[371]][_0xd590[372]][_0xd590[12]] - 1);
                        t ? x(Cube[_0xd590[366]](u)) : x(u)
                    }
                    Cube[_0xd590[375]][_0xd590[374]](_0xd590[373], _, !1)
                }
            };
            Cube[_0xd590[375]][_0xd590[2]](_0xd590[373], _, !1);
            var d = {
                cube: e,
                maxDepth: o || 20,
                maxTime: r || 30,
                useSeparator: !!l,
                type: _0xd590[382]
            };
            Cube[_0xd590[375]][_0xd590[29]](d)
        },
        generateTables: function (e, x) {
            var c = function (t) {
                t[_0xd590[371]][_0xd590[370]] == _0xd590[383] && x ? x(t[_0xd590[371]][_0xd590[384]], t[_0xd590[371]][_0xd590[385]]) : t[_0xd590[371]][_0xd590[370]] == _0xd590[386] && (e(),
                    Cube[_0xd590[378]] = !0,
                    Cube[_0xd590[375]][_0xd590[374]](_0xd590[373], c, !1))
            };
            Cube[_0xd590[375]][_0xd590[2]](_0xd590[373], c, !1),
                Cube[_0xd590[375]][_0xd590[29]]({
                    type: _0xd590[28]
                })
        }
    },
        Object[_0xd590[387]](Cube[_0xd590[273]][_0xd590[352]], _0xd590[367], {
            get: function () {
                var e = this[_0xd590[275]];
                return -1 == this[_0xd590[277]] ? e += _0xd590[250] : 2 == this[_0xd590[273]] && (e += _0xd590[252]),
                    e
            },
            set: function (e) {
                var x = e[_0xd590[276]](0, 1)
                    , c = e[_0xd590[276]](1, 2)
                    , t = 0;
                c == _0xd590[26] ? (c = 1,
                    t = 1) : c == _0xd590[250] ? (c = 1,
                        t = -1) : c == _0xd590[252] && (c = 2,
                            t = 0);
                this[_0xd590[275]] = x,
                    this[_0xd590[273]] = c,
                    this[_0xd590[277]] = t
            }
        }),
        Object[_0xd590[387]](Cube[_0xd590[273]][_0xd590[352]], _0xd590[388], {
            value: function () {
                return this[_0xd590[367]]
            }
        })
}();
var cc, generateColorsString = function () {
    return _0xd590[389]
};
function getQueryString(e) {
    for (var x = {}, c = e[_0xd590[27]](_0xd590[390]), t = 0; t < c[_0xd590[12]]; t++) {
        var o = c[t][_0xd590[27]](_0xd590[391])
            , r = o[_0xd590[392]]()
            , l = o[_0xd590[347]](_0xd590[391]);
        l = !l || !(l[_0xd590[251]]() != _0xd590[393]) || l[_0xd590[251]]() != _0xd590[394] && unescape(l)[_0xd590[136]](/\+/g, _0xd590[84]);
        x[r] = l
    }
    return x
}
var maxtime = 30
    , maxmoves = 20
    , worker = new Worker(_0xd590[272]);
function typedToArray(e) {
    for (var x = [], c = 0; c < e[_0xd590[12]]; c++)
        x[_0xd590[274]](c);
    return x
}
var totalTime = 0
    , facelets = [_0xd590[278], _0xd590[53], _0xd590[279], _0xd590[280], _0xd590[281], _0xd590[282], _0xd590[283], _0xd590[284], _0xd590[285], _0xd590[286], _0xd590[56], _0xd590[287], _0xd590[288], _0xd590[289], _0xd590[290], _0xd590[291], _0xd590[292], _0xd590[293], _0xd590[294], _0xd590[55], _0xd590[295], _0xd590[296], _0xd590[297], _0xd590[298], _0xd590[299], _0xd590[300], _0xd590[301], _0xd590[302], _0xd590[58], _0xd590[303], _0xd590[304], _0xd590[305], _0xd590[306], _0xd590[307], _0xd590[308], _0xd590[309], _0xd590[310], _0xd590[54], _0xd590[311], _0xd590[312], _0xd590[313], _0xd590[314], _0xd590[315], _0xd590[316], _0xd590[317], _0xd590[318], _0xd590[57], _0xd590[319], _0xd590[320], _0xd590[321], _0xd590[322], _0xd590[323], _0xd590[324], _0xd590[325]]
    , colors = [_0xd590[41], _0xd590[43], _0xd590[45], _0xd590[47], _0xd590[49], _0xd590[51]]
    , colorNames = {
        U: _0xd590[395],
        R: _0xd590[396],
        F: _0xd590[397],
        L: _0xd590[398],
        D: _0xd590[399],
        B: _0xd590[400],
        _: _0xd590[401]
    }
    , times = {
        twistMove: 257,
        flipMove: 220,
        FRtoBR_Move: 1645,
        URFtoDLF_Move: 3189,
        URtoDF_Move: 2904,
        URtoUL_Move: 173,
        UBtoDF_Move: 185,
        MergeURtoULandUBtoDF: 2803,
        Slice_URFtoDLF_Parity_Prun: 3022,
        Slice_URtoDF_Parity_Prun: 2828,
        Slice_Twist_Prun: 2714,
        Slice_Flip_Prun: 2544
    };
worker[_0xd590[2]](_0xd590[373], function (e) {
    if (e[_0xd590[371]][_0xd590[370]] == _0xd590[373])
        warning(_0xd590[84], e[_0xd590[371]][_0xd590[402]]);
    else if (e[_0xd590[371]][_0xd590[370]] == _0xd590[386]) {
        document[_0xd590[61]](_0xd590[404])[_0xd590[403]] = _0xd590[405] + totalTime + _0xd590[406],
            document[_0xd590[61]](_0xd590[382])[_0xd590[407]] = !1,
            worker[_0xd590[29]]({
                type: _0xd590[382],
                cube: document[_0xd590[61]](_0xd590[15])[_0xd590[408]],
                maxDepth: megprobalKirakniEnnyiLepesben,
                maxTime: 30
            }),
            megprobalKirakniEnnyiLepesben = 24;
        var x = e[_0xd590[371]][_0xd590[409]];
        for (var c in x)
            0 == c[_0xd590[88]](_0xd590[410]) && (x[c] = typedToArray(x[c]))
    } else if (e[_0xd590[371]][_0xd590[370]] == _0xd590[376]) {
        if (0 == e[_0xd590[371]][_0xd590[372]])
            ;
        else {
            var t;
            switch (e[_0xd590[371]][_0xd590[372]]) {
                case -1:
                    t = mess[1];
                    break;
                case -2:
                    t = mess[2];
                    break;
                case -3:
                    t = mess[3];
                    break;
                case -4:
                    t = mess[4];
                    break;
                case -5:
                    t = mess[5];
                    break;
                case -6:
                    t = mess[6];
                    break;
                default:
                    t = mess[22];
            }
            warning(mess[8], e[_0xd590[371]][_0xd590[372]] + _0xd590[261] + t + _0xd590[411] + mess[14])
        }
    } else if (e[_0xd590[371]][_0xd590[370]] == _0xd590[33])
        document[_0xd590[61]](_0xd590[15])[_0xd590[408]] = e[_0xd590[371]][_0xd590[372]],
            setInput[_0xd590[412]](document[_0xd590[61]](_0xd590[15]));
    else if (e[_0xd590[371]][_0xd590[370]] == _0xd590[383]) {
        var o = document[_0xd590[414]](_0xd590[413]);
        totalTime += e[_0xd590[371]][_0xd590[385]],
            o[_0xd590[59]] = e[_0xd590[371]][_0xd590[384]] + _0xd590[415] + e[_0xd590[371]][_0xd590[385]] + _0xd590[406],
            document[_0xd590[61]](_0xd590[417])[_0xd590[416]](o),
            document[_0xd590[61]](_0xd590[404])[_0xd590[408]] += times[e[_0xd590[371]][_0xd590[384]]]
    } else if (e[_0xd590[371]][_0xd590[370]] == _0xd590[380])
        if (0 == e[_0xd590[371]][_0xd590[372]][_0xd590[88]](_0xd590[381])) {
            var t, r = parseInt(e[_0xd590[371]][_0xd590[372]][_0xd590[276]](6, 7));
            t = 1 === r ? mess[1] : 2 === r ? mess[2] : 3 === r ? mess[3] : 4 === r ? mess[4] : 5 === r ? mess[5] : 6 === r ? mess[6] : 7 === r ? _0xd590[418] + maxmoves + _0xd590[419] : 8 === r ? _0xd590[420] + maxtime + _0xd590[421] : mess[22],
                7 > r && (warning(mess[8], t + _0xd590[411] + mess[14]),
                    updateCube()),
                6 < r && (70 == megprobalKirakniEnnyiLepesben ? warning(_0xd590[422], _0xd590[423]) : (worker[_0xd590[29]]({
                    type: _0xd590[382],
                    cube: document[_0xd590[61]](_0xd590[15])[_0xd590[408]],
                    maxDepth: megprobalKirakniEnnyiLepesben,
                    maxTime: 60
                }),
                    megprobalKirakniEnnyiLepesben = 70))
        } else {
            var l = Cube[_0xd590[366]](e[_0xd590[371]][_0xd590[372]]);
            buildOutput(l),
                pushState()
        }
}, !1),
    worker[_0xd590[2]](_0xd590[424], function (e) {
        warning(_0xd590[381], e),
            e[_0xd590[138]]()
    }, !1);
function buildOutput(e) {
    var x = document[_0xd590[61]](_0xd590[380]);
    x[_0xd590[425]] = e,
        x[_0xd590[59]] = _0xd590[26];
    for (var t, c = 0; c < e[_0xd590[12]]; c++)
        t = document[_0xd590[414]](_0xd590[426]),
            t[_0xd590[59]] = e[c][_0xd590[367]],
            t[_0xd590[273]] = e[c],
            t[_0xd590[427]] = 0 == c ? _0xd590[428] : _0xd590[273],
            x[_0xd590[416]](t),
            e[c][_0xd590[429]] = t;
    stp = e[_0xd590[12]];
    for (var c = 0; c < e[_0xd590[12]]; c++)
        e[c][_0xd590[367]] == _0xd590[41] && (step[c + 1] = 1),
            e[c][_0xd590[367]] == _0xd590[42] && (step[c + 1] = 2),
            e[c][_0xd590[367]] == _0xd590[43] && (step[c + 1] = 3),
            e[c][_0xd590[367]] == _0xd590[44] && (step[c + 1] = 4),
            e[c][_0xd590[367]] == _0xd590[45] && (step[c + 1] = 5),
            e[c][_0xd590[367]] == _0xd590[46] && (step[c + 1] = 6),
            e[c][_0xd590[367]] == _0xd590[47] && (step[c + 1] = 7),
            e[c][_0xd590[367]] == _0xd590[48] && (step[c + 1] = 8),
            e[c][_0xd590[367]] == _0xd590[49] && (step[c + 1] = 9),
            e[c][_0xd590[367]] == _0xd590[50] && (step[c + 1] = 10),
            e[c][_0xd590[367]] == _0xd590[51] && (step[c + 1] = 11),
            e[c][_0xd590[367]] == _0xd590[52] && (step[c + 1] = 12),
            e[c][_0xd590[367]] == _0xd590[53] && (step[c + 1] = 13),
            e[c][_0xd590[367]] == _0xd590[54] && (step[c + 1] = 14),
            e[c][_0xd590[367]] == _0xd590[55] && (step[c + 1] = 15),
            e[c][_0xd590[367]] == _0xd590[56] && (step[c + 1] = 16),
            e[c][_0xd590[367]] == _0xd590[57] && (step[c + 1] = 17),
            e[c][_0xd590[367]] == _0xd590[58] && (step[c + 1] = 18);
    kiirarrayt(),
        eddigkiir(0),
        $(_0xd590[135])[_0xd590[67]](),
        $(_0xd590[142])[_0xd590[141]]({
            scrollTop: $($(_0xd590[430]))[_0xd590[140]]()[_0xd590[139]] - 20
        }, 500)
}
var currentColor = _0xd590[45];
function makeQueryString(e, x, c) {
    var t = c ? _0xd590[431] : _0xd590[26]
        , o = !1;
    for (var r in e)
        e[_0xd590[432]](r) && (x && !1 == e[r] || (o = !0,
            t += encodeURIComponent(r) + _0xd590[391] + encodeURIComponent(e[r]) + _0xd590[390]));
    return o ? t[_0xd590[276]](0, t[_0xd590[12]] - 1) : _0xd590[26]
}
function popState(e) {
    var x = e[_0xd590[433]];
    if (x) {
        var c = document[_0xd590[61]](_0xd590[15]);
        if (x[_0xd590[15]] && (x[_0xd590[15]] == _0xd590[434] ? cleanCube(!0) : x[_0xd590[15]] == _0xd590[435] ? clearFacelets(!0) : x[_0xd590[15]] == _0xd590[33] ? worker[_0xd590[29]]({
            type: _0xd590[33]
        }) : 54 == x[_0xd590[15]][_0xd590[12]] && (c[_0xd590[408]] = x[_0xd590[15]],
            setInput[_0xd590[412]](c))),
            x[_0xd590[380]]) {
            var t = x[_0xd590[380]][_0xd590[136]](/_/g, _0xd590[84]);
            if (Cube[_0xd590[436]](t)) {
                var o = Cube[_0xd590[366]](t);
                buildOutput(o)
            } else
                ;
        }
    }
}
window[_0xd590[2]](_0xd590[437], popState, !1);
function pushState() { }
var isRandom = !1;
function setCubeText() {
    isRandom = !1;
    for (var e = _0xd590[26], x = document[_0xd590[61]](_0xd590[15]), c = 0; c < facelets[_0xd590[12]]; c++) {
        if (document[_0xd590[61]](facelets[c])[_0xd590[159]] == _0xd590[26])
            return void (x[_0xd590[408]] = _0xd590[26]);
        e += document[_0xd590[61]](facelets[c])[_0xd590[159]]
    }
    !0 == document[_0xd590[61]](_0xd590[439])[_0xd590[438]] ? (e = Cube[_0xd590[440]](e),
        x[_0xd590[408]] = e,
        setInput()) : x[_0xd590[408]] = e;
    pushState()
}
function setInput() {
    isRandom = !1;
    var e = document[_0xd590[61]](_0xd590[15]);
    if (54 == e[_0xd590[408]][_0xd590[12]])
        for (var x = e[_0xd590[408]][_0xd590[27]](_0xd590[26]), c = 0; 54 > c; c++) {
            var t = facelets[c]
                , o = document[_0xd590[61]](t);
            o[_0xd590[159]] = x[c],
                o[_0xd590[442]][_0xd590[441]] = colorNames[x[c]]
        }
}
function clearFacelets(e) {
    isRandom = !1,
        document[_0xd590[61]](_0xd590[15])[_0xd590[408]] = _0xd590[443];
    for (var c, x = 0; x < facelets[_0xd590[12]]; x++)
        c = document[_0xd590[61]](facelets[x]),
            c[_0xd590[446]][_0xd590[445]](_0xd590[444]) || (c[_0xd590[159]] = _0xd590[358],
                c[_0xd590[442]][_0xd590[441]] = colorNames[_0xd590[358]]);
    !0 !== e && pushState()
}
function cleanCube(e) {
    isRandom = !1;
    for (var c, x = 0; x < facelets[_0xd590[12]]; x++)
        c = document[_0xd590[61]](facelets[x]),
            c[_0xd590[446]][_0xd590[445]](_0xd590[444]) || (c[_0xd590[159]] = facelets[x][_0xd590[276]](0, 1),
                c[_0xd590[442]][_0xd590[441]] = colorNames[c[_0xd590[159]]]);
    document[_0xd590[61]](_0xd590[15])[_0xd590[408]] = _0xd590[447],
        !0 !== e && pushState()
}
function setColor() {
    this[_0xd590[446]][_0xd590[445]](_0xd590[444]) ? (currentColor = this[_0xd590[159]],
        document[_0xd590[61]](_0xd590[448])[_0xd590[159]] = currentColor,
        document[_0xd590[61]](_0xd590[448])[_0xd590[442]][_0xd590[441]] = colorNames[currentColor]) : (this[_0xd590[159]] = currentColor,
            this[_0xd590[442]][_0xd590[441]] = colorNames[currentColor],
            setCubeText())
}
function calculateChanges(e) {
    var x = {
        from: [],
        to: []
    }, c, t, o, r, l = e[_0xd590[277]];
    e[_0xd590[275]] == _0xd590[41] ? (c = _0xd590[449],
        t = _0xd590[450],
        o = _0xd590[451],
        r = 2) : e[_0xd590[275]] == _0xd590[47] ? (c = _0xd590[450],
            t = _0xd590[451],
            o = _0xd590[449],
            r = 2,
            l *= -1) : e[_0xd590[275]] == _0xd590[45] ? (c = _0xd590[451],
                t = _0xd590[450],
                o = _0xd590[449],
                r = 0) : e[_0xd590[275]] == _0xd590[51] ? (c = _0xd590[449],
                    t = _0xd590[451],
                    o = _0xd590[450],
                    r = 0,
                    l *= -1) : e[_0xd590[275]] == _0xd590[43] ? (c = _0xd590[450],
                        t = _0xd590[449],
                        o = _0xd590[451],
                        r = 0) : e[_0xd590[275]] == _0xd590[49] && (c = _0xd590[451],
                            t = _0xd590[449],
                            o = _0xd590[450],
                            r = 2,
                            l *= -1);
    for (var p, _ = {
        x: [2, 5, 3, 4],
        y: [1, 5, 0, 4],
        z: [0, 2, 1, 3]
    }[c], d = 2 - l, n = x[_0xd590[452]] = [0, 1, 2, 3, 4, 5], u = 0; u < d; u++) {
        p = n[_0xd590[351]]();
        for (var v = 0; 4 > v; v++)
            n[_[v]] = p[_[(v + 1) % 4]]
    }
    for (var u = 0; 9 > u; u++) {
        var b = {}
            , m = {};
        b[c] = r,
            b[t] = u % 3,
            b[o] = 0 | u / 3,
            x[_0xd590[453]][_0xd590[274]](b),
            m[c] = r,
            0 == e[_0xd590[277]] ? (m[t] = 2 - u % 3,
                m[o] = 2 - (0 | u / 3)) : 1 == e[_0xd590[277]] ? (m[t] = 0 | u / 3,
                    m[o] = 2 - u % 3) : -1 == e[_0xd590[277]] && (m[t] = 2 - (0 | u / 3),
                        m[o] = u % 3);
        x[_0xd590[454]][_0xd590[274]](m)
    }
    return x
}
function setColorNames() {
    localStorage[_0xd590[455]] = JSON[_0xd590[456]](colorNames)
}
function getColorNames() {
    for (var e in colorNames = localStorage[_0xd590[455]] ? JSON[_0xd590[457]](localStorage[_0xd590[455]]) : {
        U: _0xd590[458],
        R: _0xd590[459],
        F: _0xd590[460],
        L: _0xd590[461],
        D: _0xd590[399],
        B: _0xd590[462],
        _: _0xd590[463]
    },
        colorNames) {
        var x = document[_0xd590[61]](e + _0xd590[464]);
        if (x) {
            x[_0xd590[408]] = colorNames[e];
            var c = document[_0xd590[466]](_0xd590[465]);
            c[_0xd590[468]](_0xd590[467], !0, !0),
                x[_0xd590[469]](c)
        }
    }
}
function resetColorNames() {
    localStorage[_0xd590[455]] = _0xd590[26],
        getColorNames(),
        setInput[_0xd590[412]](document[_0xd590[61]](_0xd590[15]))
}
function setColors() {
    colorNames[this[_0xd590[471]](_0xd590[470])] = this[_0xd590[408]],
        setInput[_0xd590[412]](document[_0xd590[61]](_0xd590[15])),
        setColorNames()
}
function setColorBlank() {
    currentColor = _0xd590[358],
        document[_0xd590[61]](_0xd590[448])[_0xd590[159]] = currentColor,
        document[_0xd590[61]](_0xd590[448])[_0xd590[442]][_0xd590[441]] = colorNames[currentColor]
}
document[_0xd590[2]](_0xd590[472], function () {
    document[_0xd590[61]](_0xd590[475])[_0xd590[2]](_0xd590[143], function () {
        worker[_0xd590[29]]({
            type: _0xd590[28]
        }),
            document[_0xd590[61]](_0xd590[383])[_0xd590[473]] = !1,
            document[_0xd590[61]](_0xd590[474])[_0xd590[473]] = !0
    }, !1),
        document[_0xd590[61]](_0xd590[476])[_0xd590[2]](_0xd590[143], function () {
            worker[_0xd590[29]]({
                type: _0xd590[33]
            }),
                isRandom = !0,
                pushState()
        }, !1),
        document[_0xd590[61]](_0xd590[478])[_0xd590[2]](_0xd590[467], function () {
            maxmoves = this[_0xd590[477]]
        }, !1),
        document[_0xd590[61]](_0xd590[479])[_0xd590[2]](_0xd590[467], function () {
            maxtime = this[_0xd590[477]]
        }, !1),
        document[_0xd590[61]](_0xd590[376])[_0xd590[2]](_0xd590[143], function () {
            worker[_0xd590[29]]({
                type: _0xd590[376],
                cube: document[_0xd590[61]](_0xd590[15])[_0xd590[408]]
            })
        }, !1),
        document[_0xd590[61]](_0xd590[382])[_0xd590[2]](_0xd590[143], function () {
            worker[_0xd590[29]]({
                type: _0xd590[382],
                cube: document[_0xd590[61]](_0xd590[15])[_0xd590[408]],
                maxDepth: maxmoves,
                maxTime: maxtime
            })
        }, !1);
    for (var e = document[_0xd590[481]](_0xd590[480]), x = 0; x < e[_0xd590[12]]; x++)
        e[x][_0xd590[2]](_0xd590[156], setColors, !1);
    document[_0xd590[61]](_0xd590[15])[_0xd590[2]](_0xd590[467], setInput, !1),
        document[_0xd590[61]](_0xd590[435])[_0xd590[2]](_0xd590[143], clearFacelets, !1),
        document[_0xd590[61]](_0xd590[434])[_0xd590[2]](_0xd590[143], cleanCube, !1);
    for (var t, c = document[_0xd590[61]](_0xd590[482]), x = 0; x < colors[_0xd590[12]]; x++)
        t = document[_0xd590[414]](_0xd590[483]),
            t[_0xd590[427]] = _0xd590[484],
            t[_0xd590[485]] = colors[x],
            c[_0xd590[416]](t);
    for (var t, x = 0; x < facelets[_0xd590[12]]; x++) {
        t = document[_0xd590[414]](_0xd590[483]),
            t[_0xd590[427]] = facelets[x][_0xd590[276]](1, 2) == _0xd590[486] ? _0xd590[487] : 0 == (parseInt(facelets[x][_0xd590[276]](1, 2)) - 1) % 3 && facelets[x][_0xd590[276]](1, 2) != _0xd590[488] ? _0xd590[489] : _0xd590[490],
            t[_0xd590[485]] = facelets[x],
            t[_0xd590[159]] = facelets[x][_0xd590[276]](0, 1),
            t[_0xd590[442]][_0xd590[441]] = colorNames[t[_0xd590[159]]],
            t[_0xd590[2]](_0xd590[143], setColor, !1);
        var o = document[_0xd590[61]](facelets[x][_0xd590[276]](0, 1));
        o[_0xd590[416]](t)
    }
    if (document[_0xd590[61]](_0xd590[448])[_0xd590[2]](_0xd590[143], setColorBlank, !1),
        window[_0xd590[137]][_0xd590[491]] != _0xd590[26]) {
        var r = getQueryString(window[_0xd590[137]][_0xd590[491]][_0xd590[276]](1))
            , l = {
                state: r
            };
        popState(l)
    } else {
        var l = {
            state: {
                cube: _0xd590[435]
            }
        };
        popState(l)
    }
    document[_0xd590[61]](_0xd590[448])[_0xd590[442]][_0xd590[441]] = colorNames[currentColor]
}, !1);
var mouseX = 0
    , mouseY = 0
    , poppedUp = 0
    , eltelt5mp = 0;
document[_0xd590[2]](_0xd590[492], function (e) {
    mouseX = e[_0xd590[493]],
        mouseY = e[_0xd590[494]]
}),
    jQuery(document)[_0xd590[172]](function () {
        0 < $(_0xd590[495])[_0xd590[12]] && 100 > mouseY && 0 == poppedUp && 1 == eltelt5mp && (jQuery(_0xd590[495])[_0xd590[133]](200),
            jQuery(_0xd590[496])[_0xd590[133]](200),
            document[_0xd590[61]](_0xd590[497])[_0xd590[59]] = _0xd590[498],
            document[_0xd590[61]](_0xd590[499])[_0xd590[59]] = document[_0xd590[61]](_0xd590[500])[_0xd590[59]],
            poppedUp++)
    }),
    $(document)[_0xd590[216]](function () {
        setTimeout(function () {
            eltelt5mp = 1
        }, 5e3),
            $(_0xd590[501])[_0xd590[143]](function () {
                $(_0xd590[495])[_0xd590[74]](),
                    $(_0xd590[496])[_0xd590[74]](200)
            })
    });
